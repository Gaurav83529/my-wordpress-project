<?php
get_header();

// Get author object
$author = get_queried_object();
$user_id = $author->ID;

// Get all user meta
$user_meta = get_user_meta($user_id);

// List of meta keys to exclude
$exclude_keys = [
    'rich_editing',
    'syntax_highlighting',
    'comment_shortcuts',
    'admin_color',
    'show_admin_bar_front',
    'gOP_capabilities',
    'yoast_wpseo_profile_updated',
    'last_update',
    'ur_user_status',
    'ur_first_access',
    'wc_last_active',
    'woocommerce_persistent_cart_1',
    'session_tokens',
    'dismissed_wp_pointers',
    'community-events-location',
    'wp_user_level',
    'wp_capabilities',
    'wp_dashboard_quick_press_last_post_id',
];

// Optional: any keys starting with internal prefixes
$excluded_prefixes = ['yoast_', 'wc_', '_', 'wp_'];
?>
<section class="authorMain">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="headingOther">
					<h2><?php echo esc_html($author->display_name); ?>'s Full Profile</h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="authorInner">
				<div class="table-responsive">
					<table class="table table-striped">
						<?php foreach ($user_meta as $key => $value): ?>
							<?php 
								if (empty($value[0])) continue;

								// Skip excluded keys
								if (in_array($key, $exclude_keys)) continue;

								// Skip keys with excluded prefixes
								foreach ($excluded_prefixes as $prefix) {
									if (stripos($key, $prefix) === 0) continue 2;
								}

								// Skip serialized/array values
								if (is_serialized($value[0]) || is_array($value[0])) continue;

								// Check if it's an image URL or attachment ID
								$is_image = preg_match('/\.(jpeg|jpg|png|gif|webp)$/i', $value[0]);
								
								// If it's an attachment ID, get the URL
								if (is_numeric($value[0])) {
									$image_url = wp_get_attachment_url($value[0]);
									$is_image = preg_match('/\.(jpeg|jpg|png|gif|webp)$/i', $image_url); // recheck if it's an image URL
								} else {
									$image_url = $value[0];
								}
							?>
							<tr>
								<td><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></td>
								<td>
									<?php if ($is_image): ?>
										<img src="<?php echo esc_url($image_url); ?>" style="max-width: 200px; border-radius: 8px;">
									<?php else: ?>
										<?php echo nl2br(esc_html($value[0])); ?>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</div>
			</div>
			</div>
		</div>
	</div>
</section>

<?php get_footer(); ?>
