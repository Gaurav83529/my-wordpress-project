<?php
// Load header
get_header();
?>
<div class="page-content">
    <?php
    if (is_page()) {
        the_title('<h1 class="page-title">', '</h1>');
    }
	echo "<div class='container'>";
    while ( have_posts() ) : the_post();
        the_content();
    endwhile;
	echo "</div>";
    ?>
</div>
<?php
get_footer();
?>