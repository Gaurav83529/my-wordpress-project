<section class="bannerMain">
<div class="circleBig"></div>
<?php
get_header();
?>
	<div class="bannerArea">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="bannerAreaLeft">
						<?php echo get_field('Slider_title'); ?>
						<?php echo get_field('Slider_short_description'); ?>
					</div>
				</div>
		
					
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="bannerAreaRight">
						<div class="row">
							<?php
							// Fetch the first 6 product categories
							$category_ids = array(52, 59, 54, 53, 113, 107); // Replace with your category IDs

                            // Fetch specific product categories by ID
                            $categories = get_terms([
                                'taxonomy'   => 'product_cat', // WooCommerce product categories
                                'include'    => $category_ids, // Fetch only these category IDs
                                'hide_empty' => false, // Include empty categories
                            ]);
                            usort($categories, function($a, $b) use ($category_ids) {
                                $pos_a = array_search($a->term_id, $category_ids); // Find position of $a in $category_ids
                                $pos_b = array_search($b->term_id, $category_ids); // Find position of $b in $category_ids
                                return $pos_a - $pos_b;  // Compare their positions for sorting
                            });
							// echo"<pre>";print_r($categories);die;
							// Check if categories exist
							if (!empty($categories) && !is_wp_error($categories)) {
							foreach ($categories as $category) {
							// Get the category thumbnail (if available)
							$category_icon_image = get_term_meta($category->term_id, 'category_icon_image', true);
							$image_url = $category_icon_image ? $category_icon_image : get_template_directory_uri() . '/images/default.png';
							// Fallback image

							// Generate dynamic category links and content
							?>
							<div class="col-md-4 col-sm-12 col-xs-12 <?php echo $category->term_id; ?>">
							<a href="/sub-categories/?cat_id=<?php echo $category->term_id; ?>">
								<div class="bannerAreaRightInner">
									
										<div class="bannerImage">
											<span class="anime"></span>
											<figure>
												<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($category->name); ?>" class="img-fluid" />
											</figure>
										</div>
									
									<h4><?php echo esc_html($category->name); // Display category name ?></h4>
								</div>
							</a>
							</div>

							<?php
								}
							} else {
								echo '<p>No categories found.</p>';
							}
							?>
							<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="btnServices">
								<a href="<?php echo esc_url(home_url('/categories/')); ?>" class="btn btnTheme">
									<?php echo esc_html(get_field('Slider_change_button_name')); // Dynamic button name ?>
								</a>
							</div>
							</div>
						</div>
						</div>
				</div>
				
			</div>
		</div>
	</div>
</section>

<!-- START amzingServiceMain -->
<section class="amzingServiceMain">
    <div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="headingOther">
					<h5><?php the_field('service_steps_title'); ?></h5>
					<h2><?php the_field('service_steps_short_description'); ?></h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-3 gx-5">
				<div class="amzingServiceInner">
					<figure>
						<img src="<?php echo esc_url(get_field('service_steps')['icon1']); ?>" alt="shedule" />
					</figure>
					<h4><?php the_field('service_steps_title1'); ?></h4>
					<p><?php the_field('service_steps_desc1'); ?></p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-3 gx-5">
				  <div class="amzingServiceInner">
					  <figure>
						<img src="<?php echo esc_url(get_field('service_steps')['icon2']); ?>" alt="Calander" />
					</figure>
					<h4><?php the_field('service_steps_title2'); ?></h4>
					<p><?php the_field('service_steps_desc2'); ?></p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-3 gx-5">
				<div class="amzingServiceInner">
					<figure>
						<img src="<?php echo esc_url(get_field('service_steps')['icon3']); ?>" alt="House Care" />
					</figure>
					<h4><?php the_field('service_steps_title3'); ?></h4>
					<p><?php the_field('service_steps_desc3'); ?></p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-3 gx-5">
				<div class="amzingServiceInner">
					<figure>
						<img src="<?php echo esc_url(get_field('service_steps')['icon4']); ?>" alt="Calander" />
					</figure>
					<h4><?php the_field('service_steps_title4'); ?></h4>
					<p><?php the_field('service_steps_desc4'); ?></p>
				</div>
			</div>
		</div>
	
    </div>
</section>
<!-- END amzingServiceMain -->

<!-- START bookedServicesMain -->
<section class="bookedServicesMain">
    <div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="headingOther">
					<h5><?php the_field('service_slider_heading'); ?></h5>
					<h2><?php the_field('short_description'); ?></h2>
				</div>
			</div>
		</div>

        <div class="owl-carousel b-service-owl-slider">
            <?php
            // Get all product categories
            $categories = get_terms(array(
                'taxonomy'   => 'product_cat', // The taxonomy for product categories
                'orderby'    => 'name',        // Order categories by name
                'hide_empty' => false,         // Show empty categories as well
                'parent'     => 0,
                'exclude'    => array(23),
            ));

            if (!empty($categories) && !is_wp_error($categories)) {
                foreach ($categories as $category) {
                    $category_name = $category->name;
                    $category_image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                    $category_link = get_permalink(get_page_by_path('sub-categories')) . '?cat_id=' . $category->term_id;
                    $category_image_url = $category_image_id
                        ? wp_get_attachment_url($category_image_id)
                        : get_template_directory_uri() . '/images/default.png';
            ?>
                    <div class="item"> <!-- Each category becomes its own slide -->
                        <div class="inner-booked-service">
                            <a href="<?php echo esc_url($category_link); ?>">
                                <img src="<?php echo esc_url($category_image_url); ?>" alt="<?php echo esc_attr($category_name); ?>" class="img-fluid" />
                            </a>
                            <h4><?php echo esc_html($category_name); ?></h4>
                            <div class="price-book-now">
                                <a href="<?php echo esc_url($category_link); ?>" class="btn btn-primary explore">Explore 
                                    <img src="/wp-content/uploads/2025/03/arrow_white.png">
                                </a>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p>No categories found.</p>';
            }
            ?>
        </div>

    </div>
</section>
<!-- END bookedServicesMain -->


<!-- START successfulyAwardsMain -->
<section class="successfulyAwardsMain">
    <div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="headingOther">
					 <?php the_field('success_services_long_description'); ?> 
				</div>
			</div>
		</div>
	
		
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 counter-number">
                <div class="counter-box colored">
                    <div class="counter-plus">
                        <span class="counter"><?php the_field('success_services_countup_count1'); ?></span> +
                    </div>
                    <p><?php the_field('success_services_countup_title1'); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 counter-number">
                <div class="counter-box colored">
                    <div class="counter-plus">
                        <span class="counter"><?php the_field('success_services_countup_count2'); ?></span> +
                    </div>
                    <p><?php the_field('success_services_countup_title2'); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 counter-number">
                <div class="counter-box colored">
                    <div class="counter-plus">
                        <span class="counter"><?php the_field('success_services_countup_count3'); ?></span> +
                    </div>
                    <p><?php the_field('success_services_countup_title3'); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 counter-number">
                <div class="counter-box colored">
                    <div class="counter-plus">
                        <span class="counter"><?php the_field('success_services_countup_count4'); ?></span> +
                    </div>
                    <p><?php the_field('success_services_countup_title4'); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END successfulyAwardsMain -->


<!-- START howWeStartedMain -->
<section class="howWeStartedMain">
    <div class="container">	
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
				<div class="howWeStartedLeft">
					<?php the_field('start_section_heading'); ?>
					<?php the_field('start_section_short_description'); ?>
					<p><?php the_field('start_section_long_description'); ?></p>
					<a class="btn btnTheme" href="/about-us/"><?php the_field('start_section_button_name'); ?></a>
				</div>
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12 howWeImage">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <img src="<?php echo esc_url(get_field('start_section')['image1']); ?>" class=" img-fluid" />
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <img class="howWeImage_2" src="<?php echo esc_url(get_field('start_section')['image2']); ?>" class=" img-fluid" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- START howWeStartedMain -->



<section class="testimonials">
	 <div class="testimonials_1">
		<img src="/wp-content/uploads/2025/02/feature-shape.webp" alt="Image">
	</div>  
    <div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="headingOther">
					<h5><?php the_field('testimonial_header_heading') ?></h5>
					<h2><?php the_field('testimonial_header_short_description') ?></h2>
				</div>
			</div>
		</div>
	

        <div class="owl-carousel testimonial-owl-slider">
            <?php
            // Query WP Customer Reviews
            $ReviewArr = array(
                'post_type' => 'wpcr3_review',
                'posts_per_page' => 10,
                'post_status' => 'publish'
            );
            $GetReviews = new WP_Query($ReviewArr);

            if ($GetReviews->have_posts()) :
                while ($GetReviews->have_posts()) : $GetReviews->the_post();
                    $reviewer_name = get_post_meta(get_the_ID(), 'wpcr3_review_name', true);
                    $reviewer_rating = get_post_meta(get_the_ID(), 'wpcr3_review_rating', true);
            ?>
                    <div class="item">
                        <div class="inner-testimonials">
                            <?php
$reviewer_image = get_field('reviewer_image');
if ($reviewer_image) {
    echo '<img src="' . esc_url($reviewer_image) . '" class="img-fluid" alt="Reviewer Image" />';
} else {
    echo '<img src="';?><?php echo get_template_directory_uri(); ?>/images/user-profile-icon-vector-avatar.webp'<?php echo'" class="img-fluid" alt="Default Reviewer Image" />';
}
?>
                            <h4><?php echo esc_html($reviewer_name); ?></h4>
                            <?php the_content(); ?>
                            <ul class="rating-star">
                                <?php for ($i = 0; $i < 5; $i++) : ?>
                                    <li>
                                        <i class="fa fa-star<?php echo ($i < $reviewer_rating) ? '' : '-o'; ?>" aria-hidden="true"></i>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </div>
                    </div>
            <?php
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>
    </div>
</section>
<?php
get_footer(); // Includes footer.php
?>
<script>
    $(document).ready(function() {
        $('.owl-carousel.testimonial-owl-slider').owlCarousel({
            margin: 8,
            dots: false,
            center: true,
            loop: true,
            autoplay: true,
            nav: true,
            navText: ["<img src='<?php echo get_template_directory_uri(); ?>/images/left-icon.png'/>", "<img src='<?php echo get_template_directory_uri(); ?>/images/right-icon.png'/>"],
            responsive: {
                0: {
                    items: 1,
                    margin: 10
                },

                575: {
                    items: 2,
                    margin: 10
                },

                768: {
                    items: 2,
                    margin: 10
                },
                992: {
                    items: 3,
                    margin: 11
                }
            }
        })

        $('.owl-carousel.b-service-owl-slider').owlCarousel({
            margin: 8,
            dots: false,
            //center: true,
            loop: true,
            autoplay: true,
            nav: true,
            navText: ["<img src='<?php echo get_template_directory_uri(); ?>/images/left-icon.png'/>", "<img src='<?php echo get_template_directory_uri(); ?>/images/right-icon.png'/>"],
            responsive: {
                0: {
                    items: 1,
                    margin: 10
                },

                575: {
                    items: 2,
                    margin: 10
                },

                768: {
                    items: 3,
                    margin: 10
                },
                992: {
                    items: 4,
                    margin: 11
                }
            }
        })
    })
</script>
<script>
    $(document).ready(function() {
        $('.counter').each(function() {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).text()
            }, {
                duration: 4000,
                easing: 'swing',
                step: function(now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });

    });
</script>