<?php
global $woocommerce;

if ( $user_orders ) {
    ?>
    <form id="order-filter" method="POST" class="dokan-form-inline">
        <?php if ( dokan_get_option( 'order_status_change', 'dokan_selling', 'on' ) === 'on' ) { ?>
            <div class="dokan-form-group">
                <label for="bulk-order-action-selector" class="screen-reader-text"><?php esc_html_e( 'Select bulk action', 'dokan-lite' ); ?></label>
                <select name="status" id="bulk-order-action-selector" class="dokan-form-control chosen">
                    <?php foreach ( $bulk_order_statuses as $key => $value ) { ?>
                        <option class="bulk-order-status" value="<?php echo esc_attr( $key ); ?>"><?php echo esc_attr( $value ); ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="dokan-form-group">
                <?php wp_nonce_field( 'bulk_order_status_change', 'security' ); ?>
                <input type="submit" name="bulk_order_status_change" id="bulk-order-action" class="dokan-btn dokan-btn-theme" value="<?php esc_attr_e( 'Apply', 'dokan-lite' ); ?>">
            </div>
        <?php } ?>
        <table class="dokan-table dokan-table-striped">
            <thead>
                <tr>
                    <th id="cb" class="manage-column column-cb check-column"><input id="cb-select-all" class="dokan-checkbox" type="checkbox"></th>
                    <th><?php esc_html_e( 'Order', 'dokan-lite' ); ?></th>
                    <th><?php esc_html_e( 'Order Total', 'dokan-lite' ); ?></th>
					   <th><?php echo esc_html( 'Start Date', 'dokan-lite' ); ?></th>
                    <th><?php esc_html_e( 'Earning', 'dokan-lite' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'dokan-lite' ); ?></th>
                    <th><?php esc_html_e( 'Customer', 'dokan-lite' ); ?></th>
                    <th><?php esc_html_e( 'Date', 'dokan-lite' ); ?></th>
                 
                    <?php if ( function_exists( 'dokan_get_order_shipment_current_status' ) && 'on' === $allow_shipment && $wc_shipping_enabled ) : ?>
                        <th><?php esc_html_e( 'Shipment', 'dokan-lite' ); ?></th>
                    <?php endif; ?>
                    <?php do_action( 'dokan_order_listing_header_before_action_column' ); ?>
                    <?php if ( current_user_can( 'dokan_manage_order' ) ) { ?>
                        <th width="17%"><?php esc_html_e( 'Action', 'dokan-lite' ); ?></th>
                    <?php } ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $user_orders as $order ) : ?>
                    <tr>
                        <th class="dokan-order-select check-column">
                            <input class="cb-select-items dokan-checkbox" type="checkbox" name="bulk_orders[]" value="<?php echo esc_attr( $order->get_id() ); ?>">
                        </th>
                        <td class="dokan-order-id column-primary" data-title="<?php esc_attr_e( 'Order', 'dokan-lite' ); ?>">
                            <?php echo '<a href="' . esc_url( wp_nonce_url( add_query_arg( [ 'order_id' => $order->get_id() ], dokan_get_navigation_url( 'orders' ) ), 'dokan_view_order' ) ) . '"><strong>' . sprintf( esc_html__( 'Order %s', 'dokan-lite' ), esc_attr( $order->get_order_number() ) ) . '</strong></a>'; ?>
                            <button type="button" class="toggle-row"></button>
                        </td>
                        <td data-title="<?php esc_attr_e( 'Order Total', 'dokan-lite' ); ?>">
                            <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                        </td>
                        <td data-title="<?php esc_attr_e( 'Earning', 'dokan-lite' ); ?>">
                            <?php echo wp_kses_post( wc_price( dokan()->commission->get_earning_by_order( $order ) ) ); ?>
                        </td>
                        <td data-title="<?php esc_attr_e( 'Status', 'dokan-lite' ); ?>">
                            <span class="dokan-label dokan-label-<?php echo esc_attr( dokan_get_order_status_class( $order->get_status() ) ); ?>">
                                <?php echo esc_html( dokan_get_order_status_translated( $order->get_status() ) ); ?>
                            </span>
                        </td>
                        <td data-title="<?php esc_attr_e( 'Customer', 'dokan-lite' ); ?>">
                            <?php echo esc_html( $order->get_formatted_billing_full_name() ?: __( 'Guest', 'dokan-lite' ) ); ?>
                        </td>
                        <td data-title="<?php esc_attr_e( 'Date', 'dokan-lite' ); ?>">
                            <?php
                            $date_created = $order->get_date_created();
                            if ( $date_created ) {
                                $timestamp = $date_created->getTimestamp();
                                echo '<abbr title="' . esc_attr( dokan_format_date( $timestamp ) ) . '">' . esc_html( human_time_diff( $timestamp, time() ) ) . ' ' . esc_html__( 'ago', 'dokan-lite' ) . '</abbr>';
                            } else {
                                echo esc_html__( 'Unpublished', 'dokan-lite' );
                            }
                            ?>
                        </td>
                        <td data-title="<?php esc_html_e( 'Start Date' ); ?>">
                            <?php
                            // Assuming you're storing the custom start date in order meta
                            $start_date = get_post_meta( $order->get_id(), '_custom_start_date', true );
                            echo $start_date ? esc_html( date( 'Y-m-d', strtotime( $start_date ) ) ) : esc_html__( 'N/A', 'dokan-lite' );
                            ?>
                        </td>
                        <?php if ( function_exists( 'dokan_get_order_shipment_current_status' ) && 'on' === $allow_shipment && $wc_shipping_enabled ) : ?>
                            <td data-title="<?php esc_attr_e( 'Shipping Status', 'dokan-lite' ); ?>">
                                <?php echo wp_kses_post( dokan_get_order_shipment_current_status( $order->get_id() ) ); ?>
                            </td>
                        <?php endif; ?>
                        <?php do_action( 'dokan_order_listing_row_before_action_field', $order ); ?>
                        <?php if ( current_user_can( 'dokan_manage_order' ) ) : ?>
                            <td data-title="<?php esc_attr_e( 'Action', 'dokan-lite' ); ?>">
                                <?php
                                $actions = [];

                                if ( dokan_get_option( 'order_status_change', 'dokan_selling', 'on' ) === 'on' ) {
                                    if ( in_array( $order->get_status(), [ 'pending', 'on-hold' ], true ) ) {
                                        $actions['processing'] = [
                                            'url' => wp_nonce_url( admin_url( 'admin-ajax.php?action=dokan-mark-order-processing&order_id=' . $order->get_id() ), 'dokan-mark-order-processing' ),
                                            'name' => __( 'Processing', 'dokan-lite' ),
                                            'icon' => '<i class="far fa-clock"></i>',
                                        ];
                                    }

                                    if ( in_array( $order->get_status(), [ 'pending', 'on-hold', 'processing' ], true ) ) {
                                        $actions['complete'] = [
                                            'url' => wp_nonce_url( admin_url( 'admin-ajax.php?action=dokan-mark-order-complete&order_id=' . $order->get_id() ), 'dokan-mark-order-complete' ),
                                            'name' => __( 'Complete', 'dokan-lite' ),
                                            'icon' => '<i class="fas fa-check"></i>',
                                        ];
                                    }
                                }

                                $actions['view'] = [
                                    'url' => wp_nonce_url( add_query_arg( [ 'order_id' => $order->get_id() ], dokan_get_navigation_url( 'orders' ) ), 'dokan_view_order' ),
                                    'name' => __( 'View', 'dokan-lite' ),
                                    'icon' => '<i class="far fa-eye"></i>',
                                ];

                                $actions = apply_filters( 'woocommerce_admin_order_actions', $actions, $order );

                                foreach ( $actions as $action ) {
                                    printf(
                                        '<a class="dokan-btn dokan-btn-default dokan-btn-sm tips" href="%s" title="%s">%s</a> ',
                                        esc_url( $action['url'] ),
                                        esc_attr( $action['name'] ),
                                        wp_kses_post( $action['icon'] )
                                    );
                                }
                                ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </form>
    <?php
} else {
    echo '<div class="dokan-alert dokan-alert-info">' . esc_html__( 'No orders found!', 'dokan-lite' ) . '</div>';
}
?>
