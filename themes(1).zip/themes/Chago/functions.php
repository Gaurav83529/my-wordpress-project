<?php
add_action('init', function() {
    if (!session_id()) {
        session_start();
    }
});

use RestMyApis\Services\HelperService;
function custom_enqueue_scripts_header()
{
    wp_enqueue_script('jquery-cdn', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js', array(), null, true);
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), null, true);
    wp_enqueue_script('bootstrap-bundle', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array('jquery'), null, true);

    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/js/owl.carousel.js', array('jquery'), null, true);

    wp_enqueue_script('custom-otp-script', get_template_directory_uri() . '/js/custom-otp.js', array('jquery'), rand(1000, 9999), true);

	wp_localize_script('custom-otp-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
	 
	wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array('jquery'), null, true);
	
}
add_action('wp_enqueue_scripts', 'custom_enqueue_scripts_header');

add_action('rest_api_init', function () {
	register_rest_route( 'my-api/v1', '/verify_otp_set', [
		'methods' => 'POST',
		'callback' => 'verify_msg91_otp' ,
		'permission_callback' => '__return_true',
	]);
});	
function mytheme_setup()
{
    // Add support for featured images
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'mytheme_setup');

function custom_widgets_init()
{
    // Footer widget areas
    register_sidebar(array(
        'name'          => __('Footer Column 1', 'Chago'),
        'id'            => 'footer-1',
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '',
        'after_title'   => '',
        'description'   => __('Widgets in this area will be shown in the first column of the footer.', 'Chago'),
    ));

    register_sidebar(array(
        'name'          => __('Footer Column 2', 'Chago'),
        'id'            => 'footer-2',
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '',
        'after_title'   => '',
        'description'   => __('Widgets in this area will be shown in the second column of the footer.', 'Chago'),
    ));

    register_sidebar(array(
        'name'          => __('Footer Column 3', 'Chago'),
        'id'            => 'footer-3',
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '',
        'after_title'   => '',
        'description'   => __('Widgets in this area will be shown in the third column of the footer.', 'Chago'),
    ));
	register_sidebar(array(
    'name'          => __('Footer Column 4 (Social Links)', 'Chago'),
    'id'            => 'footer-4',
    'before_widget' => '',
    'after_widget'  => '',
    'before_title'  => '',
    'after_title'   => '',
    'description'   => __('Widgets in this area will be shown in the fourth column of the footer for social links.', 'Chago'),
));


    register_sidebar(array(
        'name'          => __('Copyright Widget', 'Chago'),
        'id'            => 'copyright-widget',
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '',
        'after_title'   => '',
        'description'   => __('Widgets in this area will be shown in the copyright section of the footer.', 'Chago'),
    ));
    register_sidebar(array(
        'name'          => __('Footer Contact Us', 'Chago'),
        'id'            => 'footer-contact',
        'before_widget' => '<div class="footer-contact-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
        'description'   => __('Widgets in this area will display Contact Us details in the footer.', 'Chago'),
    ));
}
add_action('widgets_init', 'custom_widgets_init');

function customize_social_links($wp_customize)
{
    $wp_customize->add_section('social_links_section', array(
        'title' => __('Social Links', 'Chago'),
        'priority' => 30,
    ));

    $social_networks = ['Facebook', 'Twitter', 'Instagram', 'LinkedIn', 'WhatsApp', 'YouTube'];

    foreach ($social_networks as $network) {
        $wp_customize->add_setting(strtolower($network) . '_link', array(
            'default' => '',
            'sanitize_callback' => 'esc_url',
        ));
        $wp_customize->add_control(strtolower($network) . '_link', array(
            'label' => __($network . ' URL', 'Chago'),
            'section' => 'social_links_section',
            'type' => 'url',
        ));
    }
}
add_action('customize_register', 'customize_social_links');

function custom_set_role_based_on_form_id($form_data, $form_id)
{
    // Define roles based on form IDs
    $role_by_form = [
        '472' => 'subscriber',
    ];

    // Check if the form ID exists in our role array
    if (array_key_exists($form_id, $role_by_form)) {
        //$user = new WP_User($user_id);
        $user = get_user_by('email', $form_data['user_email']->value);

        $user_id = $user->ID;
        // Set the user role
        $user->set_role($role_by_form[$form_id]);

        // Log success
        error_log("User role set to: " . $role_by_form[$form_id] . " for User ID: $user_id");
    } else {
        // Log if form ID not found
        error_log("No role found for Form ID: $form_id");
    }
}
add_action('user_registration_after_register_user_action', 'custom_set_role_based_on_form_id', 10, 2);

function add_state_dropdown_script()
{
?>
    <script type="text/javascript">
        function convertStateInputToDropdown() {
            // List of Indian states
            var stateList = [
                "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
                "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
                "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
                "Sikkim", "Tamil Nadu", "Telangana", "Uttar Pradesh", "Uttarakhand",
                "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
                "Lakshadweep", "Delhi", "Puducherry", "Jammu and Kashmir", "Ladakh"
            ];

            // Get the input field by its ID
            var inputField = document.getElementById("input_box_1623050759");

            if (inputField) {
                // Create a dropdown element
                var select = document.createElement("select");
                select.id = inputField.id;
                select.name = inputField.name;

                // Create a default "Select State" option
                var defaultOption = document.createElement("option");
                defaultOption.value = "";
                defaultOption.text = "Select State";
                select.appendChild(defaultOption);

                // Populate the dropdown with state options
                stateList.forEach(function(state) {
                    var option = document.createElement("option");
                    option.value = state;
                    option.text = state;
                    select.appendChild(option);
                });

                // Replace the text input field with the new dropdown
                inputField.parentNode.replaceChild(select, inputField);
            }
        }

        // Execute the function once the document is ready
        document.addEventListener("DOMContentLoaded", function() {
            convertStateInputToDropdown();
        });
    </script>
    <?php
}
add_action('wp_footer', 'add_state_dropdown_script');

function add_custom_js_for_user_registration()
{
    if (is_page('user-registration')) { // Adjust the page check if needed for your page
    ?>
        <script type="text/javascript">
            document.addEventListener("DOMContentLoaded", function() {
                // Select the visible date field (using the correct class for your case)
                const dobFieldVisible = document.querySelector('.ur-flatpickr-field'); // Visible field with class ur-flatpickr-field

                if (dobFieldVisible) {
                    console.log("Date field found:", dobFieldVisible);

                    // Get today's date in YYYY-MM-DD format
                    const today = new Date();
                    const formattedDate = today.toISOString().split('T')[0]; // Format: YYYY-MM-DD
                    console.log("Today's date:", formattedDate);

                    // Set the 'max' attribute on the visible field
                    dobFieldVisible.setAttribute("data-max-date", formattedDate);
                    console.log("Max date set for the visible field:", formattedDate);

                    // Initialize Flatpickr on the visible date field
                    if (typeof flatpickr !== 'undefined' && !dobFieldVisible._flatpickr) {
                        flatpickr(dobFieldVisible, {
                            maxDate: formattedDate, // Set max date to today
                            dateFormat: "Y-m-d",
                            //disableMobile: true,     
                            onReady: function() {
                                console.log("Flatpickr is ready with max date.");
                            },
                            onChange: function(selectedDates, dateStr, instance) {
                                console.log("Date changed:", dateStr);

                            }
                        });
                        console.log("Flatpickr initialized with max date.");
                    }
                } else {
                    console.log("Date field not found.");
                }
            });
        </script>
    <?php
    }
}
add_action('wp_enqueue_scripts', 'add_custom_js_for_user_registration');

function custom_login_redirect($user_login, $user)
{ 
    $roles = $user->roles;
   // echo "<pre>"; print_r($roles);
	if (is_user_logged_in()) {
		if (in_array('administrator', $roles)) {
			wp_redirect(admin_url('/'));
			exit;
		} elseif (in_array('manager', $roles)) {
			wp_redirect(home_url('/wp-admin'));
			exit;
		} elseif (in_array('subscriber', $roles)) {
			wp_redirect(home_url('/'));
			exit;
		} elseif (in_array('services_provider', $roles)) {
			wp_redirect(home_url('/service-provider-dashboard/'));
			//wp_redirect(home_url('/dashboard'));
			exit;
		} else {
			wp_redirect(home_url());
			exit;
		}
	}
}
 add_action('wp_login', 'custom_login_redirect', 10, 2);
remove_filter('authenticate', 'wc_login_authenticate', 20);

// Redirect user to homepage after logout (prevent 'Are you sure you want to log out?' message)
function redirect_after_logout()
{
    wp_redirect(home_url()); // Redirect to the homepage
    exit();
}
add_action('wp_logout', 'redirect_after_logout');

// Redirect logged-in users away from the login page
function redirect_logged_in_users_from_login_page()
{
    if (is_user_logged_in() && is_page('login')) { // 'login' is your custom login page slug
        wp_redirect(home_url()); // Redirect to the homepage
        exit;
    }
}
add_action('template_redirect', 'redirect_logged_in_users_from_login_page');

function prevent_login_page_cache_for_all_users()
{
    if (is_page('login')) { // Adjust to your custom login page slug
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}
add_action('template_redirect', 'prevent_login_page_cache_for_all_users');

function hide_administrators($query)
{
    if (is_admin()) {
        $screen = get_current_screen();
        $current_user = wp_get_current_user();
        if (in_array('manager', (array) $current_user->roles)) {
            $query->set('role__not_in', array('administrator'));
        }
    }
}
add_action('pre_get_users', 'hide_administrators');

function rename_dokan_submenu()
{
    global $submenu;

    if (isset($submenu['dokan'])) {
        foreach ($submenu['dokan'] as &$item) {
            if ($item[0] === 'Vendors') {
                $item[0] = 'Service Providers';
                break;
            }
        }
    }
}
add_action('admin_menu', 'rename_dokan_submenu', 999);

function enqueue_iziModal_assets()
{
    wp_enqueue_style('iziModal-css', 'https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.0/css/iziModal.min.css');
    wp_enqueue_script('iziModal-js', 'https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.0/js/iziModal.min.js', ['jquery'], '1.6.0', true);

    wp_enqueue_style('vendor-dashboard', plugins_url('/dokan-lite/assets/css/vue-vendor.css'), [], '1.0');
    wp_enqueue_style('vue-bootstrap', plugins_url('/dokan-lite/assets/css/vue-bootstrap.css'), [], '1.0');
    wp_enqueue_style('vue-frontend', plugins_url('/dokan-lite/assets/css/vue-frontend.css'), [], '1.0');
}
add_action('wp_enqueue_scripts', 'enqueue_iziModal_assets');

// // Hook into Dokan product approval
// add_action('dokan_product_status_published', 'assign_bookly_service_to_product', 10, 2);

// function assign_bookly_service_to_product($product_id, $user_id) {
//     // Get the product object
//     $product = wc_get_product($product_id);

//     // Ensure the product is a valid WooCommerce product
//     if (!$product || !$product->get_id()) {
//         return;
//     }
//     // Here we assume you want to assign a service based on product category or some custom field.
//     // You can customize this logic to fit your needs (for example, based on category, tags, etc.)

//     $product_categories = $product->get_category_ids(); // Get product categories
//     $product_name = $product->get_name(); // Product name can be used to set service name
//     $service_name = 'Service for ' . $product_name; // Example service name

//     // Get the staff ID associated with the user (service provider)
//     global $wpdb;
//     $staff_id = $wpdb->get_var(
//         $wpdb->prepare("SELECT id FROM gOP_bookly_staff WHERE wp_user_id = %d", $user_id)
//     );

//     if ($staff_id) {
//         // Check if a service already exists for the staff provider
//         $existing_service = $wpdb->get_var(
//             $wpdb->prepare("SELECT id FROM gOP_bookly_services WHERE staff_id = %d AND title = %s", $staff_id, $service_name)
//         );

//         if (!$existing_service) {
//             // Create a new Bookly service
//             $wpdb->insert(
//                 'gOP_bookly_services', 
//                 array(
//                     'staff_id' => $staff_id, 
//                     'title' => $service_name,
//                     'duration' => 60, // Set service duration in minutes (customize as needed)
//                     'price' => $product->get_price(), // You can use the product price for the service price
//                     'description' => 'Service linked to the product: ' . $product_name
//                 ),
//                 array('%d', '%s', '%d', '%f', '%s')
//             );
//         }
//     }
// }

add_action('save_post', 'sync_product_to_bookly_services', 10, 3);
function sync_product_to_bookly_services($post_id, $post, $update)
{
    // Exit early if it's an autosave or revision
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    // Ensure it's a WooCommerce product
    if ($post->post_type !== 'product') {
        return;
    }

    global $wpdb;

    // Get product details
    $product = wc_get_product($post_id);

    if (!$product) return;

    $service_name = $product->get_name();
    $service_price = $product->get_price();
	
    $terms = get_the_terms($post_id, 'product_cat');

    $parent_category_id = null;

	if (!empty($terms) && is_array($terms)) {
		foreach ($terms as $term) {
			if ($term->parent == 0) {
				$parent_category_id = $term->term_id;
				break;
			}
		}
	}
	
    if (!$parent_category_id) {
        error_log("No parent category found for product ID {$post_id}");
        return;
    }

    // Check if a Bookly service already exists for this product
    $bookly_services_table = $wpdb->prefix . 'bookly_services';
    $existing_service = $wpdb->get_row(
        $wpdb->prepare("SELECT id FROM {$bookly_services_table} WHERE wc_product_id = %d", $post_id)
    );
	
    if (!$existing_service) {
        // Create a new Bookly service
        $cart_info = "Date: {appointment_date} Time: {appointment_time} Service: {service_name}";
        $wpdb->insert($bookly_services_table, array(
            'title' => $service_name,
            'wc_product_id' => $post_id,
            'wc_cart_info' => $cart_info,
            'wc_cart_info_name' => $service_name,
            'price' => $service_price,
        ));
        $service_id = $wpdb->insert_id;
        error_log("Service '{$service_name}' created in Bookly for product ID {$post_id}.");
	} else {
		$cart_info = "Date: {appointment_date} Time: {appointment_time} Service: {service_name}";

		$wpdb->update(
			$bookly_services_table,
			array(
				'title' => $service_name, 
				'wc_cart_info' => $cart_info, 
				'wc_cart_info_name' => $service_name,
				'price' => $service_price,
			),
			array('id' => $existing_service->id ), 
			array('%s', '%s', '%s', '%f'),
			array('%d')
		);
		$service_id = $existing_service->id;

		error_log("Service '{$service_name}' updated in Bookly for product ID {$post_id}.");
	}
	/*$service_providers = get_users(array(
		'role'   => 'services_provider', 
		'fields' => array('ID')
	));
	
	if (empty($service_providers)) {
        error_log("No service providers found");
        return;
    }*/

    // Find staff members with matching `selected_category_id` in user meta
    $users = get_users(array(
        'meta_key' => 'selected_category_id',
        'meta_value' => $parent_category_id,
    ));
	

    if (empty($users)) {
        error_log("No staff members found with selected_category_id = {$parent_category_id}.");
        return;
    }

    // Assign the service to matched staff members
    $staff_services_table = $wpdb->prefix . 'bookly_staff_services';
	//print_r($staff_services_table);die;
    foreach ($users as $user) {
        // Get the Bookly staff ID associated with the WP user ID
        $staff_result = $wpdb->get_row(
            $wpdb->prepare("SELECT id FROM {$wpdb->prefix}bookly_staff WHERE wp_user_id = %d", $user->ID)
        );
		
        if ($staff_result) {
            $staff_id = $staff_result->id;

            // Check if the staff is already assigned this service
            $already_assigned = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM {$staff_services_table} WHERE staff_id = %d AND service_id = %d",
                    $staff_id,
                    $service_id
                )
            );

            if (!$already_assigned) {
                // Assign the service to the staff member
                $wpdb->insert($staff_services_table, array(
                    'staff_id' => $staff_id,
                    'service_id' => $service_id,
                    'price' => $service_price,
                ));
                error_log("Service ID {$service_id} assigned to Staff ID {$staff_id}.");
            } else {
				$wpdb->update(
					$staff_services_table,
					array(
						'price' => $service_price, 
					),
					array(
						'id' => $already_assigned->id, 
					),
					array('%f'),
					array('%d')
				);
				error_log("Service ID {$service_id} price updated for Staff ID {$staff_id}.");
			}
        } else {
            error_log("No Bookly staff found for WP user ID {$user->ID}.");
        }
    }
}

//custom fields in service provider profile 
// Add custom fields to the WordPress user profile page (Admin Only)
function add_service_provider_fields_to_profile($user)
{
    // Only show for administrators
    if (current_user_can('administrator')) {
    ?>
        <h3><?php _e('Service Provider Information', 'textdomain'); ?></h3>
        <table class="form-table">
            <!-- Specialization Field -->
            <tr>
                <th><label><?php _e('Specialization', 'textdomain'); ?></label></th>
                <td>
                    <?php
                    $selected_category_id = get_user_meta($user->ID, 'selected_category_id', true);

                    if ($selected_category_id) {
                        $term = get_term($selected_category_id, 'product_cat');
                        if (!is_wp_error($term) && $term) {
                            echo esc_html($term->name);
                        } else {
                            echo 'Category not found.';
                        }
                    } else {
                        echo 'No specialization selected.';
                    }
                    ?>
                </td>
            </tr>


            <!-- Vehicle Availability Field -->
            <tr>
                <th><label for="vehicle_availability"><?php _e('Vehicle Availability', 'textdomain'); ?></label></th>
                <td>
                    <select name="vehicle_availability" id="vehicle_availability" class="regular-text">
                        <option value="yes" <?php selected(get_user_meta($user->ID, 'vehicle_availability', true), 'yes'); ?>>Yes</option>
                        <option value="no" <?php selected(get_user_meta($user->ID, 'vehicle_availability', true), 'no'); ?>>No</option>
                    </select>
                </td>
            </tr>

            <!-- Address Field -->
            <tr>
                <th><label for="address"><?php _e('Address', 'textdomain'); ?></label></th>
                <td>
                    <?php
                    $full_address = get_user_meta($user->ID, 'address', true);
                    ?>
                    <textarea name="address" id="address" rows="5" class="regular-text"><?php echo esc_textarea($full_address); ?></textarea>
                    <p class="description">This is the full address saved during registration.</p>
                </td>
            </tr>

            <!-- Account Holder's Name Field -->
            <tr>
                <th><label for="account_name"><?php _e('Account Holder\'s Name', 'textdomain'); ?></label></th>
                <td>
                    <input type="text" name="account_name" id="account_name"
                        value="<?php echo esc_attr(get_user_meta($user->ID, 'account_name', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <!-- Account Number Field -->
            <tr>
                <th><label for="account_number"><?php _e('Account Number', 'textdomain'); ?></label></th>
                <td>
                    <input type="text" name="account_number" id="account_number"
                        value="<?php echo esc_attr(get_user_meta($user->ID, 'account_number', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <!--Phone Number -->
            <tr>
                <th><label for="phone"><?php _e('Phone Number', 'textdomain'); ?></label></th>
                <td>
                    <input type="text" name="phone" id="phone"
                        value="<?php echo esc_attr(get_user_meta($user->ID, 'phone', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <!-- Profile Image Field -->
            <tr>
                <th><label for="profile_image"><?php _e('Profile Image', 'textdomain'); ?></label></th>
                <td>
                    <input type="file" name="profile_image" id="profile_image" class="regular-text">
                    <?php
                    $profile_image_url = get_user_meta($user->ID, 'profile_image', true);
                    if ($profile_image_url) {
                        echo '<p><img src="' . esc_url($profile_image_url) . '" width="150" /></p>';
                    }
                    ?>
                </td>
            </tr>
           <!-- Aadhaar Front Image Field -->
            <tr>
                <th><label for="adhaar_front_image"><?php _e('Aadhaar Front Image', 'textdomain'); ?></label></th>
                <td>
                    <input type="file" name="adhaar_front_image" id="adhaar_front_image">
                    <?php
                    $adhaar_front_image_url = get_user_meta($user->ID, 'adhaar_front_image', true);
                    if ($adhaar_front_image_url) {
                        echo '<p><img src="' . esc_url($adhaar_front_image_url) . '" width="150" /></p>';
                    }
                    ?>
                </td>
            </tr>

        <!-- Aadhaar Back Image Field -->
        <tr>
            <th><label for="adhaar_back_image"><?php _e('Aadhaar Back Image', 'textdomain'); ?></label></th>
            <td>
                <input type="file" name="adhaar_back_image" id="adhaar_back_image">
                <?php
                $adhaar_back_image_url = get_user_meta($user->ID, 'adhaar_back_image', true);
                if ($adhaar_back_image_url) {
                    echo '<p><img src="' . esc_url($adhaar_back_image_url) . '" width="150" /></p>';
                }
                ?>
            </td>
        </tr>

        <!-- Labour Card Image Field -->
        <tr>
            <th><label for="labour_card_image"><?php _e('Labour Card Image', 'textdomain'); ?></label></th>
            <td>
                <input type="file" name="labour_card_image" id="labour_card_image">
                <?php
                $labour_card_image_url = get_user_meta($user->ID, 'labour_card', true);
                if ($labour_card_image_url) {
                    echo '<p><img src="' . esc_url($labour_card_image_url) . '" width="150" /></p>';
                }
                ?>
            </td>
        </tr>
        </table>
    <?php
    }
}
add_action('show_user_profile', 'add_service_provider_fields_to_profile');
add_action('edit_user_profile', 'add_service_provider_fields_to_profile');
function save_service_provider_fields($user_id)
{
    // Only allow admins to update these fields
    if (!current_user_can('administrator')) {
        return;
    }

    // Text fields and select
    update_user_meta($user_id, 'vehicle_availability', sanitize_text_field($_POST['vehicle_availability']));
    update_user_meta($user_id, 'address', sanitize_textarea_field($_POST['address']));
    update_user_meta($user_id, 'account_name', sanitize_text_field($_POST['account_name']));
    update_user_meta($user_id, 'account_number', sanitize_text_field($_POST['account_number']));
    update_user_meta($user_id, 'phone', sanitize_text_field($_POST['phone']));

    // Handle file uploads
    $file_fields = [
        'profile_image',
        'adhaar_front_image',
        'adhaar_back_image',
        'labour_card_image'
    ];

    foreach ($file_fields as $field) {
        if (!empty($_FILES[$field]['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            $uploaded = media_handle_upload($field, 0);
            if (!is_wp_error($uploaded)) {
                $url = wp_get_attachment_url($uploaded);
                update_user_meta($user_id, $field, esc_url_raw($url));
            }
        }
    }
}
add_action('personal_options_update', 'save_service_provider_fields');
add_action('edit_user_profile_update', 'save_service_provider_fields');


//Add Bookly Calendar to Dokan menu
add_filter('dokan_get_dashboard_nav', 'add_bookly_calendar_to_dokan_menu', 10, 1);
function add_bookly_calendar_to_dokan_menu($menus)
{
    $menus['bookly-calendar'] = array(
        'title'      => __('Booking Calendar', 'Chago'),
        'icon'       => '<i class="fas fa-calendar"></i>',
        'url'        => dokan_get_navigation_url('bookly-calendar'),
        'position'   => 51,
        'permission' => 'read',
    );
    return $menus;
}
add_filter('dokan_query_var_filter', 'add_bookly_calendar_query_var');
function add_bookly_calendar_query_var($query_vars)
{
    $query_vars[] = 'bookly-calendar'; // Match the menu item key
    return $query_vars;
}
add_action('dokan_load_custom_template', 'load_bookly_calendar_content');

function load_bookly_calendar_content($query_vars)
{
    if (isset($query_vars['bookly-calendar'])) {
        // Start Dokan Dashboard Wrapper
    ?>
        <div class="dokan-dashboard-wrap">
            <?php
            /**
             * dokan_dashboard_content_before hook
             * This hook adds the sidebar menu.
             */
            do_action('dokan_dashboard_content_before');
            ?>

            <div class="dokan-dashboard-content">
                <?php
                /**
                 * dokan_dashboard_content_inside_before hook
                 */
                do_action('dokan_dashboard_content_inside_before');
                ?>
                <div class="container">
                    <ul class="tabs">
                        <li class="tab-link active" data-tab="tab-1">Staff Calendar</li>
                        <li class="tab-link" data-tab="tab-2">Staff Schedule</li>
                        <li class="tab-link" data-tab="tab-3">Staff Days Off</li>
                        <li class="tab-link" data-tab="tab-4">Staff Appointments</li>
                    </ul>

                    <!-- Tab Content -->
                    <div id="tab-1" class="tab-content active">
                        <?php echo do_shortcode('[bookly-staff-calendar]'); ?>
                    </div>
                    <div id="tab-2" class="tab-content">
                        <?php echo do_shortcode('[bookly-staff-schedule]'); ?>
                    </div>
                    <div id="tab-3" class="tab-content">
                        <?php echo do_shortcode('[bookly-staff-days-off]'); ?>
                    </div>
                    <div id="tab-4" class="tab-content">
                        <?php echo do_shortcode('[bookly-staff-appointments]'); ?>
                    </div>
                </div>

                <script>
                    document.querySelectorAll('.tab-link').forEach(function(tab) {
                        tab.addEventListener('click', function() {
                            document.querySelectorAll('.tab-link').forEach(function(tab) {
                                tab.classList.remove('active');
                            });
                            document.querySelectorAll('.tab-content').forEach(function(content) {
                                content.classList.remove('active');
                            });

                            tab.classList.add('active');
                            const tabContent = document.getElementById(tab.getAttribute('data-tab'));
                            tabContent.classList.add('active');
                        });
                    });
                </script>
                <style>
                    .tabs {
                        list-style-type: none;
                        margin: 0;
                        padding: 0;
                        display: flex;
                    }

                    .tab-link {
                        padding: 10px 20px;
                        cursor: pointer;
                        background-color: #f1f1f1;
                        border: 1px solid #ddd;
                        margin-right: 5px;
                        transition: background-color 0.3s ease;
                    }

                    .tab-link.active {
                        background-color: #4CAF50;
                        color: white;
                    }

                    .tab-content {
                        display: none;
                        padding: 20px;
                        background-color: #f9f9f9;
                        border: 1px solid #ddd;
                    }

                    .tab-content.active {
                        display: block;
                    }

                    .container {
                        margin-top: 20px;
                    }
                </style>

                <?php
                /**
                 * dokan_dashboard_content_inside_after hook
                 */
                do_action('dokan_dashboard_content_inside_after');
                ?>
            </div>

            <?php
            /**
             * dokan_dashboard_content_after hook
             */
            do_action('dokan_dashboard_content_after');
            ?>
        </div>
    <?php
    }
}

add_action('dokan_process_product_meta', 'save_product_category_hidden_field_to_dokan_product', 10, 1);
function save_product_category_hidden_field_to_dokan_product($post_id)
{
    if (isset($_POST['product_category_hidden'])) {
        update_post_meta($post_id, 'product_category_hidden', sanitize_text_field($_POST['product_category_hidden']));
    }
}

// Add custom number field to the WooCommerce product data panel for specific categories
add_action('woocommerce_product_options_general_product_data', 'add_custom_product_number_field');

function add_custom_product_number_field()
{
    global $post;

    // Get product categories
    $product_categories = wp_get_post_terms($post->ID, 'product_cat', array('fields' => 'slugs'));

    // Define the categories where this field should appear
    $allowed_categories = array('commercial-tolet-services', 'residential-tolet-services');

    // Check if the product belongs to the allowed categories
    if (array_intersect($allowed_categories, $product_categories)) {
        woocommerce_wp_text_input(
            array(
                'id'          => '_product_area', // Meta key
                'label'       => __('Area in sq/ft', 'Chago'),
                'placeholder' => __('Enter product area', 'Chago'),
                'type'        => 'number', // Set input type to number
                'desc_tip'    => 'true',
                'description' => __('This field is used to specify the product area as a number.', 'Chago'),
                'custom_attributes' => array(
                    'step' => '1', // Increment step
                    'min'  => '0'  // Minimum value
                ),
            )
        );
    }
}

// Save custom number field data
add_action('woocommerce_process_product_meta', 'save_custom_product_number_field');

function save_custom_product_number_field($post_id)
{
    // Save data only if the field is present in the POST data
    if (isset($_POST['_product_area'])) {
        $product_area = $_POST['_product_area']; // Sanitize as integer
        update_post_meta($post_id, '_product_area', $product_area);
    }
}

//fetch bookly services for service provider registration
function get_bookly_services()
{
    global $wpdb;
    $services = $wpdb->get_results("SELECT id, title FROM {$wpdb->prefix}bookly_services", ARRAY_A);
    return $services;
}
add_action('wp_ajax_filter_services', 'filter_services');
add_action('wp_ajax_nopriv_filter_services', 'filter_services');

function filter_services()
{
    include 'filter-services.php';
}

add_action('update_user_meta', 'handle_user_status_change', 10, 4);

function handle_user_status_change($meta_id, $user_id, $meta_key, $meta_value)
{
    if ($meta_key === 'ur_user_status') {
        // Get the old value of this meta key
        $old_value = get_user_meta($user_id, $meta_key, true);

        // Check if the status has changed to '1' (approved)
        if ($old_value !== $meta_value && (int) $meta_value === 1) {
            // Perform your custom logic for approval here
            //error_log("User ID $user_id is now approved.");

            global $wpdb;
            // Get user data from WordPress
            $user_info = get_userdata($user_id);

            if ($user_info) {
                // Check if the user has the 'service_provider' role
                if (in_array('services_provider', $user_info->roles)) {

                    // Retrieve the user's full name, email, and phone (using user_meta if needed)
                    $name = $user_info->first_name . ' ' . $user_info->last_name;  // Assuming first and last name are used for the full name
                    $email = $user_info->user_email;
                    $phone = get_user_meta($user_id, 'phone', true); // Adjust based on the field you use for phone number
                    $category_id = get_user_meta($user_id, 'selected_category_id', true);

                    // Define the table where staff data is stored in Bookly
                    $table_staff = $wpdb->prefix . 'bookly_staff';

                    // Check if the user is already a staff member
                    $existing_staff = $wpdb->get_var(
                        $wpdb->prepare("SELECT COUNT(*) FROM $table_staff WHERE wp_user_id = %d", $user_id)
                    );

                    if ($existing_staff == 0) {
                        // Insert the user into the Bookly staff table
                        $wpdb->insert($table_staff, array(
                            'wp_user_id' => $user_id,   // Link to the WordPress user
                            'full_name'  => $name,      // The full name from the form
                            'email'      => $email,     // The email from the form
                            'phone'      => $phone,     // The phone number from the form
                        ));
                        $staff_id = $wpdb->insert_id; // Retrieve the new staff ID

                        // Add calendar token logic
                        if (class_exists('Bookly\Lib\Entities\Staff')) {
                            $staff = new Bookly\Lib\Entities\Staff();
                            $staff->load($staff_id); // Load the newly created staff entry
                            $staff->save();          // Save to trigger calendar token generation
                        }
                    }

                    // Fetch WooCommerce products based on the selected category
                    $args = array(
                        'post_type' => 'product',
                        'posts_per_page' => -1,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'product_cat',
                                'field'    => 'id',
                                'terms'    => $category_id,
                                'operator' => 'IN',
                            ),
                        ),
                    );

                    $query = new WP_Query($args);

                    if ($query->have_posts()) {
                        while ($query->have_posts()) {
                            $query->the_post();

                            // Get the WooCommerce product ID
                            $product_id = get_the_ID();

                            // Fetch Bookly service ID
                            $bookly_service = $wpdb->get_row(
                                $wpdb->prepare(
                                    "SELECT * FROM {$wpdb->prefix}bookly_services WHERE wc_product_id = %d",
                                    $product_id
                                )
                            );

                            if ($bookly_service) {
                                $bookly_service_id = $bookly_service->id;
                                $bookly_service_price = $bookly_service->price;

                                // Retrieve the staff ID for the created user
                                $staff = $wpdb->get_row(
                                    $wpdb->prepare(
                                        "SELECT * FROM {$wpdb->prefix}bookly_staff WHERE wp_user_id = %d",
                                        $user_id
                                    )
                                );

                                if ($staff) {
                                    $staff_user_id = $staff->id;

                                    // Assign the service to the staff
                                    $table_services = $wpdb->prefix . 'bookly_staff_services';
                                    $existing_service = $wpdb->get_row(
                                        $wpdb->prepare(
                                            "SELECT * FROM $table_services WHERE staff_id = %d AND service_id = %d",
                                            $staff_user_id,
                                            $bookly_service_id
                                        )
                                    );

                                    if (!$existing_service) {
                                        $wpdb->insert($table_services, array(
                                            'staff_id'   => $staff_user_id,
                                            'service_id' => $bookly_service_id,
                                            'price' => $bookly_service_price,
                                        ));
                                    }
                                    if ($staff_user_id) {
                                        assign_daily_slots($staff_user_id);
                                    }
                                }
                            }
                        }
                    }

                    wp_reset_postdata();
                }
            }
        }
    }
}

function assign_daily_slots($staff_user_id)
{
    global $wpdb;
    $table_schedule = $wpdb->prefix . 'bookly_staff_schedule_items';
    $daily_slots = array(
        array('day_index' => 1, 'start_time' => null, 'end_time' => null),
        array('day_index' => 2, 'start_time' => '08:00:00', 'end_time' => '18:00:00'),
        array('day_index' => 3, 'start_time' => '08:00:00', 'end_time' => '18:00:00'),
        array('day_index' => 4, 'start_time' => '08:00:00', 'end_time' => '18:00:00'),
        array('day_index' => 5, 'start_time' => '08:00:00', 'end_time' => '18:00:00'),
        array('day_index' => 6, 'start_time' => '08:00:00', 'end_time' => '18:00:00'),
        array('day_index' => 7, 'start_time' => null, 'end_time' => null),
    );
    foreach ($daily_slots as $slot) {
        $wpdb->insert(
            $table_schedule,
            array(
                'staff_id'   => $staff_user_id, // Use the dynamic staff ID
                'location_id' => null,      // Assuming no location is specified (NULL)
                'day_index'  => $slot['day_index'],
                'start_time' => $slot['start_time'],
                'end_time'   => $slot['end_time'],
            )
        );
    }
}
function assign_product_service_price_to_staff(){
    
}

// latitude longitude of the user 
function store_coordinates_in_session()
{
    // Check if the latitude and longitude are set in the POST data
    if (isset($_POST['lat']) && isset($_POST['lon'])) {
        // Sanitize the input to make sure it's a valid floating-point number
        $latitude = filter_var($_POST['lat'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $longitude = filter_var($_POST['lon'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        // Explicitly cast to float to ensure proper type
        $latitude = floatval($latitude);
        $longitude = floatval($longitude);
        if (is_user_logged_in()) {

            $user_id = get_current_user_id();
            setcookie('user_lat', $latitude, time() + 3600, '/');
            setcookie('user_lon', $longitude, time() + 3600, '/');
            update_user_meta($user_id, 'user_lat', $latitude);
            update_user_meta($user_id, 'user_lon', $longitude);
            $location_transient = array(
                'user_lat' => $latitude,
                'user_lon' => $longitude,
            );
            //set_transient('user_location_transient', $location_transient, 3600);
            // echo json_encode([
            // 	'message' => 'Coordinates stored successfully.',
            // 	'data' => [
            // 		'lat' => $latitude,
            // 		'lon' => $longitude
            // 	]
            // ]);
            $transient_key = 'user_' . $user_id . '_location_transient';
            //$transient_key = 'user_guest_location_transient_' . session_id();
            set_transient($transient_key, $location_transient, 3600);

            echo json_encode([
                'message' => 'Coordinates stored successfully.',
                'data' => [
                    'lat' => $latitude,
                    'lon' => $longitude
                ]
            ]);

            exit;
        } else {
            $location_transient = array(
                'user_lat' => $latitude,
                'user_lon' => $longitude,
            );
            // set_transient('user_location_transient', $location_transient, 3600);
            $transient_key = 'user_guest_location_transient_' . session_id();
            // error_log('trasient');
            // error_log($transient_key);
            set_transient($transient_key, $location_transient, 3600);
            setcookie('user_lat', $latitude, time() + 3600 * 24 * 30, '/');
            setcookie('user_lon', $longitude, time() + 3600 * 24 * 30, '/');
            echo json_encode([
                'message' => 'Coordinates for non-logged in user stored in cookies successfully.',
                'data' => [
                    'lat' => $latitude,
                    'lon' => $longitude
                ]
            ]);
            exit;
        }
    } else {
        // Handle the case where the coordinates are not provided
        echo json_encode([
            'message' => 'Coordinates not provided.'
        ]);
        exit;
    }
}
add_action('wp_ajax_store_coordinates', 'store_coordinates_in_session');
add_action('wp_ajax_nopriv_store_coordinates', 'store_coordinates_in_session');

// Function to check if staff is available at a specific time

function get_nearest_service_provider($product_id, $user_latitude, $user_longitude, $time_slot, $user_selected_staff)
{
    $category_ids1 = array();
    //print_r($user_latitude);echo ' ';
    //print_r($user_longitude);
    // Step 2: Get the product categories
    $product_categories1 = wp_get_post_terms($product_id, 'product_cat');
    if (!empty($product_categories1)) {
        foreach ($product_categories1 as $category) {
            // Get parent category ID, if it has a parent
            $parent_id = $category->parent ? $category->parent : $category->term_id;
            $category_ids1[] = $parent_id; // Store the parent category ID
        }
    }
    $category_ids1 = array_unique($category_ids1);

    if (empty($category_ids1)) {
        return []; // No categories assigned
    }

    // Step 3: Query for all service providers based on the category
    $args = array(
        'role' => 'services_provider', // Assuming you have a role for service providers
        'meta_query' => array(
            array(
                'key' => 'selected_category_id', // Assuming you store the category in this meta field
                'value' => $category_ids1,
                'compare' => 'IN',
            ),
            array(
                'key' => 'provider_latitude', // Assuming you store the latitude in this meta field
                'compare' => 'EXISTS',
            ),
            array(
                'key' => 'provider_longitude', // Assuming you store the longitude in this meta field
                'compare' => 'EXISTS',
            ),
        ),
    );

    $service_providers = get_users($args);
    $provider_distance_list = array();

    // Step 4: Calculate the nearest service provider
    foreach ($service_providers as $provider) {
        $provider_latitude = get_user_meta($provider->ID, 'provider_latitude', true);
        $provider_longitude = get_user_meta($provider->ID, 'provider_longitude', true);

        if ($provider_latitude && $provider_longitude) {
            // Step 5: Calculate the distance using the Haversine formula
            $distance = haversine_distance($user_latitude, $user_longitude, $provider_latitude, $provider_longitude);

            // List providers within km
            if ($distance <= 100) {
                $provider_distance_list[] = array(
                    'provider' => $provider->ID,
                    'distance' => $distance,
                );
            }
        }
    }

    if (!empty($provider_distance_list)) {
        usort($provider_distance_list, function ($a, $b) {
            return $a['distance'] <=> $b['distance'];
        });
    }
    // later add a wc notice maybe if there are no providers nearby
    //echo '<pre>'; print_r($provider_distance_list); echo '</pre>';
    foreach ($provider_distance_list as $value) {
        $staff_id = $value['provider'];
        global $wpdb;
        $staff_id = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM gOP_bookly_staff WHERE wp_user_id = %d", $staff_id)

        );
        if ($staff_id === $user_selected_staff) {
            return $staff_id;
        } else {
            $is_staff_available = is_staff_available_at_time($staff_id, $time_slot);
        }
        if ($is_staff_available) {
            return $staff_id;
        }
    }
    return null;
}

function haversine_distance($lat1, $lon1, $lat2, $lon2)
{
    $earth_radius = 6371; // Radius of the Earth in km

    // Convert latitude and longitude from degrees to radians
    $lat1 = deg2rad($lat1);
    $lon1 = deg2rad($lon1);
    $lat2 = deg2rad($lat2);
    $lon2 = deg2rad($lon2);

    // Haversine formula
    $dlat = $lat2 - $lat1;
    $dlon = $lon2 - $lon1;
    $a = sin($dlat / 2) * sin($dlat / 2) +
        cos($lat1) * cos($lat2) *
        sin($dlon / 2) * sin($dlon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    return $earth_radius * $c; // Distance in km
}

function is_staff_available_at_time($staff_id, $time_slot)
{
    global $wpdb;

    // Convert the time slot to MySQL-compatible format
    $time_slot = date('Y-m-d H:i:s', strtotime($time_slot));
    // print_r('staff --'.$staff_id);
    // Query to check if the staff member has an appointment at the given time
    $sql = "
        SELECT COUNT(*) 
        FROM {$wpdb->prefix}bookly_appointments 
        WHERE staff_id = %d 
        AND start_date = %d
    ";
    $query = $wpdb->prepare($sql, $staff_id, $time_slot);
    $appointment_count = $wpdb->get_var($query);

    return $appointment_count == 0;
}


add_action('woocommerce_thankyou', 'fetch_bookly_appointments_data', 10, 1);

function fetch_bookly_appointments_data($order_id)
{
    if (!$order_id) {
        return;
    }
     // Check if the function has already run for this order
     if (get_post_meta($order_id, '_appointment_processed', true)) {
        // If the flag exists, do not execute the function again
        return;
    }
    global $wpdb;

    // Get the WooCommerce order object
    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }
    $product_ids = array();

    // Loop through each item in the order
    foreach ($order->get_items() as $item) {
        $product_ids[] = $item->get_product_id(); // Get product ID
    }

    // Output product IDs 

    $product_id = implode(', ', $product_ids);
    $user_id = $order->get_user_id();
    if (is_user_logged_in()) {
        $transient_key = 'user_' . $user_id . '_location_transient';
        $location_data = get_transient($transient_key);

        if (false !== $location_data) {
            // Transient exists and has not expired
            // error_log('The value of the transient is logged in: ');
            // print_r($location_data);
            $user_latitude  =   $location_data['user_lat'];
            $user_longitude =   $location_data['user_lon'];
        } else {

            $transient_key = 'user_guest_location_transient_' . session_id();
            $location_data = get_transient($transient_key);
            //echo 'The value of the transient is-non logged in: ';
            //print_r($location_data);
            $user_latitude  =   $location_data['user_lat'];
            $user_longitude =   $location_data['user_lon'];
        }
        //fetch-logged in users longitude and latitude from user meta
        // 		$user_latitude = get_user_meta($user_id, 'user_lat', true);
        // 		$user_longitude = get_user_meta($user_id, 'user_lon', true);

        //$user_latitude = floatval($user_latitude);
        //$user_longitude = floatval($user_longitude);
    } else {
        //fetch non- loggedin user's latitude and longitude from transient
        $transient_key = 'user_guest_location_transient_' . session_id();
        $location_data = get_transient($transient_key);
        if (false !== $location_data) {
            // Transient exists and has not expired
            //echo 'The value of the transient is non: ' . $location_data;
        } else {
            // Transient does not exist or has expired
           error_log('The transient does not exist or has expired.');
        }
        if ($location_data !== false) {
            $user_latitude  =   $location_data['user_lat'];
            $user_longitude =   $location_data['user_lon'];
        } else {
            error_log('no location found transient');
        }
    }

    // Fetch the customer email from the order
    $customer_email = $order->get_billing_email();

    // Query the gOP_bookly_appointments table

    $gOP_bookly_customers = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id 
         FROM gOP_bookly_customers 
         WHERE wp_user_id = %d",
            $user_id
        )
    );
    error_log('gOP_bookly_customers:');
    error_log(print_r($gOP_bookly_customers,true));
    $last_appointments = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT appointment_id 
         FROM gOP_bookly_customer_appointments 
         WHERE customer_id = %d 
         ORDER BY id DESC 
         LIMIT 1",
            $gOP_bookly_customers[0]->id
        )
    );
// error_log('last_appointments:');
//     error_log(print_r($last_appointments,true));
    // Check if the result is not empty
    if (!empty($last_appointments)) {
        // Get the first result (since you are limiting it to 1)
        $last_appointment = $last_appointments[0];
        $gOP_bookly_appointments = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * 
         FROM gOP_bookly_appointments
         WHERE id = %d
         ",
                $last_appointment->appointment_id
            )

        );
    //     error_log('gOP_bookly_appointments:');
    // error_log(print_r($last_appointments,true));
        if (!empty($gOP_bookly_appointments)) {
            // Access the first result
            $appointment = $gOP_bookly_appointments[0];

            // Get the start_date
            $time_slot = $appointment->start_date;
            $user_selected_staff = $appointment->staff_id;
            $appointment_id = $appointment->id;
        }
    }

    // 	echo 'user selected staff: ';
    // 	print_r($user_selected_staff);
    // 	echo '<br>';
    // 	echo 'product id: ';
    // 	print_r($product_id);
    // 	echo '<br>';
    // 	echo 'latitude: ';
    // 	print_r($user_latitude);
    // 	echo '<br>';
    // 	echo 'longitude: ';
    // 	print_r($user_longitude);
    // 	echo '<br>';
    // 	echo 'time slot to check:  ';
    // 	print_r($time_slot);
    // 	echo '<br>';

    $nearest_selected_staff = get_nearest_service_provider($product_id, $user_latitude, $user_longitude, $time_slot, $user_selected_staff);

    if (isset($nearest_selected_staff)) {
        echo "Selected staff ID: " . $nearest_selected_staff;
    } else {
        
        // later add wp_notice later
        
        echo "No nearby staff available for the given time slot.";
    }
    if ($user_selected_staff != $nearest_selected_staff) {
        // echo 'appointment id: ';print_r($appointment_id);echo '<br>';
        global $wpdb;
        $update_staff_id = $wpdb->query(
            $wpdb->prepare(
                "UPDATE gOP_bookly_appointments
    SET staff_id = %d WHERE id = %d",
                $nearest_selected_staff,
                $appointment_id
            )
        );
        if ($update_staff_id) {
            echo '<br>';
            echo 'nearest staff id assigned success';
        }
    } else {
        echo '<br>';
        echo "same";
    }
    // Set the flag in order meta to indicate this has already been processed
    update_post_meta($order_id, '_appointment_processed', true);
}

//<---WPCR average reviews-->>
function display_wpcr_average_and_total_reviews()
{
    $product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
    global $wpdb;
    // Get all ratings for the post
    $query  = $wpdb->prepare(
        "SELECT post_id 
    FROM {$wpdb->postmeta} 
    WHERE meta_value = %s 
    AND meta_key = %s",
        $product_id,
        'wpcr3_review_post'
    );
    $review_ratings = [];
    $total_reviews = 0;
    $sum_reviews = 0;
    $rating_meta = $wpdb->get_col($query);
    foreach ($rating_meta as $single_rating_meta) {
        $rating_query = $wpdb->prepare(
            "SELECT meta_value
        FROM {$wpdb->postmeta}
        WHERE post_id = %d
        AND meta_key = %s ",
            $single_rating_meta,
            'wpcr3_review_rating'
        );
        $single_rating = $wpdb->get_var($rating_query);
        $total_reviews++;
        $sum_reviews += $single_rating;
    }

    if ($total_reviews > 0) {
        $average = $sum_reviews / $total_reviews;
        // If total reviews are greater than 0, format the review count
        if ($total_reviews >= 1000) {
            $total_reviews = number_format($total_reviews / 1000, 1) . 'K';
        }

        // Return the average rating and total reviews
        echo '<br/><small>★ ' . number_format($average, 1) . ' (' . $total_reviews . ' reviews)</small>';
    } else {
        echo '<br/>No reviews yet';
    }
}

// Shortcode to display average rating and total reviews
add_shortcode('wpcr_average_and_total_reviews', function ($atts) {
    // Default is to use the current post ID
    $atts = shortcode_atts(['post_id' => get_the_ID()], $atts, 'wpcr_average_and_total_reviews');

    return display_wpcr_average_and_total_reviews($atts['post_id']);
});

// Add image upload field to the add category page
add_action('product_cat_add_form_fields', 'add_product_category_icon_image_field', 10, 2);
function add_product_category_icon_image_field($taxonomy)
{ ?>
    <div class="form-field">
        <label for="category-icon-image">Category Icon</label>
        <input type="button" class="button upload-icon-image-button" value="Upload/Add Image">
        <input type="hidden" name="category_icon_image" id="category-icon-image" value="">
        <div id="category-icon-preview" style="margin-top: 10px;"></div>
        <p>Add an icon image for this category.</p>
    </div>
    <script>
        jQuery(document).ready(function($) {
            let mediaUploader;
            $('.upload-icon-image-button').click(function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: 'Select Icon Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#category-icon-image').val(attachment.url);
                    $('#category-icon-preview').html('<img src="' + attachment.url + '" style="max-width: 100px;">');
                });
                mediaUploader.open();
            });
        });
    </script>
<?php }

// Add image upload field to the edit category page
add_action('product_cat_edit_form_fields', 'edit_product_category_icon_image_field', 10, 2);
function edit_product_category_icon_image_field($term, $taxonomy)
{
    $icon_image = get_term_meta($term->term_id, 'category_icon_image', true); ?>
    <tr class="form-field">
        <th scope="row"><label for="category-icon-image">Category Icon</label></th>
        <td>
            <input type="button" class="button upload-icon-image-button" value="Upload/Add Image">
            <input type="hidden" name="category_icon_image" id="category-icon-image" value="<?php echo esc_attr($icon_image); ?>">
            <div id="category-icon-preview" style="margin-top: 10px;">
                <?php if ($icon_image) { ?>
                    <img src="<?php echo esc_url($icon_image); ?>" style="max-width: 100px;">
                <?php } ?>
            </div>
            <p class="description">Add an icon image for this category.</p>
        </td>
    </tr>
    <script>
        jQuery(document).ready(function($) {
            let mediaUploader;
            $('.upload-icon-image-button').click(function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: 'Select Icon Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#category-icon-image').val(attachment.url);
                    $('#category-icon-preview').html('<img src="' + attachment.url + '" style="max-width: 100px;">');
                });
                mediaUploader.open();
            });
        });
    </script>
<?php }

// Save the icon image when the category is saved
add_action('created_product_cat', 'save_product_category_icon_image', 10, 2);
add_action('edited_product_cat', 'save_product_category_icon_image', 10, 2);
function save_product_category_icon_image($term_id, $taxonomy)
{
    if (isset($_POST['category_icon_image']) && !empty($_POST['category_icon_image'])) {
        update_term_meta($term_id, 'category_icon_image', esc_url_raw($_POST['category_icon_image']));
    } else {
        delete_term_meta($term_id, 'category_icon_image');
    }
}


// <-------------location fetch api mappls---->
function fetch_mappls_token()
{
    $cache_time = 12 * HOUR_IN_SECONDS;
    $cached_token = get_transient('mappls_access_token');
    if ($cached_token) {
        return $cached_token;
    }

    // Fetch a new token
    $client_id = '96dHZVzsAuv5BofNjzNMnUoHOs6uQfLEa0bgF979V7B1Q8Sk_nlpzZc9mghY4fHY5kBHsIGVn17Skymz6c9i32T5GkXVWn3u';
    $client_secret = 'lrFxI-iSEg-ISx0Lv-5fKCFQy-tgm7Qcq2K7NOMvSRKKqpxhV7Fd9BT7F2frU42NIRA13jsb60J4g9Q8l2EaIr_VU5ghyWH-1GQL9NOYU0Y=';
    $token_url = 'https://outpost.mapmyindia.com/api/security/oauth/token';
    $token_data = [
        'grant_type' => 'client_credentials',
        'client_id' => $client_id,
        'client_secret' => $client_secret
    ];

    $response = wp_remote_post($token_url, [
        'body' => $token_data
    ]);

    if (is_wp_error($response)) {
        return false; // Handle error
    }

    $token_body = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($token_body['access_token'])) {
        return false; // Handle error
    }

    // Cache the token with its expiration time
    $access_token = $token_body['access_token'];
    $expires_in = isset($token_body['expires_in']) ? (int)$token_body['expires_in'] : $cache_time;
    set_transient('mappls_access_token', $access_token, $expires_in - 120);

    return $access_token;
}

add_action('wp_ajax_fetch_autosuggestions', 'fetch_autosuggestions');
add_action('wp_ajax_nopriv_fetch_autosuggestions', 'fetch_autosuggestions');
function fetch_autosuggestions() { 
    global $wpdb;

    // Verify the query parameter
    if (empty($_GET['query'])) {
        wp_send_json_error(['message' => 'Query is missing']);
        return;
    }

    // Set CORS headers
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");

    $query = sanitize_text_field($_GET['query']);
    $access_token = fetch_mappls_token();

    if (!isset($access_token)) {
        wp_send_json_error(['message' => 'Failed to retrieve access token']);
        return;
    }
    
   

    // Prepare the search query
     $clean_text = trim($_GET['query'], "\"\\");
    $api_search = $wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}mapmyindiaapi` WHERE `placeAddress` LIKE %s",
        '%' . $clean_text . '%'
    );

    // Execute the query
    $api_results = $wpdb->get_results($api_search, ARRAY_A);
    

    // If there are results, return them
    if (!empty($api_results)) {
        /*echo "<pre>";
        print_r($api_results);
        echo "</pre>";*/
     wp_send_json_success($api_results);
    } else {
        // If no results, insert a new record
        
    

    // Make the Autosuggest API call to Mappls
    $autosuggest_url = 'https://atlas.mappls.com/api/places/search/json?query=' . urlencode($query);
    $autosuggest_response = wp_remote_get($autosuggest_url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $access_token
        ]
    ]);

    if (is_wp_error($autosuggest_response)) {
        wp_send_json_error(['message' => 'Failed to fetch suggestions']);
        return;
    }

    $suggestions = json_decode(wp_remote_retrieve_body($autosuggest_response), true);

    if (!isset($suggestions['suggestedLocations'])) {
        wp_send_json_error(['message' => 'Invalid suggestions response']);
        return;
    }
    //print_r($suggestions['suggestedLocations']); die;
foreach($suggestions['suggestedLocations'] as $suggestion){
	
		$insert_search = $wpdb->prepare(
            "INSERT INTO `{$wpdb->prefix}mapmyindiaapi` (`placeAddress`) VALUES (%s)",
            $suggestion['placeAddress']
        );
		$wpdb->query($insert_search);
	}
    // Return the suggestions
    wp_send_json_success($suggestions['suggestedLocations']);
	
	

        
	}
}


add_action('wp_ajax_fetch_location_from_lat_lon', 'fetch_location_from_lat_lon'); // For logged-in users
add_action('wp_ajax_nopriv_fetch_location_from_lat_lon', 'fetch_location_from_lat_lon'); // For non-logged-in users

function fetch_location_from_lat_lon()
{
    if (!empty($_GET['lat']) && !empty($_GET['lon'])) {
        $lat = sanitize_text_field($_GET['lat']);
        $lon = sanitize_text_field($_GET['lon']);
        $access_token = fetch_mappls_token();
        if (!isset($access_token)) {
            wp_send_json_error(['message' => 'Failed to retrieve access token']);
            return;
        }

        //$processed_query = str_replace(' ', ',', trim($query));
        // Make the Autosuggest API call
        $autosuggest_url = 'https://apis.mappls.com/advancedmaps/v1/fd4b6fb189aa4528df8950ecf5692bb8/rev_geocode?lat=' . $lat . '&lng=' . $lon . '&region=IND';
        $autosuggest_response = wp_remote_get($autosuggest_url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token
            ]
        ]);

        if (is_wp_error($autosuggest_response)) {
            wp_send_json_error(['message' => 'Failed to fetch suggestions']);
            return;
        }

        $suggestions = json_decode(wp_remote_retrieve_body($autosuggest_response), true);
    if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $formatted_address = $suggestions['results'][0];

        // Construct the formatted address
        $user_live_addr = $formatted_address['subLocality'] . " " . $formatted_address['locality'] . " " . $formatted_address['city'];
//error_log(print_r($formatted_address, true));
        $_SESSION['user_address'] = $user_live_addr;
        $_SESSION['formatted_address'] = $formatted_address;
        setcookie('user_address' , $user_live_addr, time()+3600, '/');
        if (!isset($suggestions['results'])) {
            wp_send_json_error(['message' => 'Invalid suggestions response']);
            return;
        }

        // Return the suggestions
        wp_send_json_success($suggestions['results']);
    }
}

function fetch_coordinates_from_address() {
    if (isset($_POST['address_query'])) {
        $address_query = sanitize_text_field($_POST['address_query']);
        error_log('here is the address query');
    error_log($address_query);
    
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
        $_SESSION['user_address'] = $address_query;
        $user_address = $_SESSION['user_address'];
    }
    }
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
        
    }
    // Retrieve the address from the session
    if (!isset($_SESSION['user_address']) || empty($_SESSION['user_address'])) {
        wp_send_json_error(['message' => 'Address not found in session']);
        return;
    }
    $query = sanitize_text_field($_SESSION['user_address']);
    // error_log('here is the  query');
    // error_log($query);

    // Fetch Mappls access token
    $access_token = fetch_mappls_token();
    if (empty($access_token)) {
        wp_send_json_error(['message' => 'Failed to retrieve access token']);
        return;
    }

    // Prepare the Geocode API URL
    $geocode_url = 'https://atlas.mappls.com/api/places/geocode?address=' . urlencode($query);

    // Make the API call
    $response = wp_remote_get($geocode_url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $access_token
        ]
    ]);

    // Handle API errors
    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'Failed to fetch geocode response']);
        return;
    }

    // Decode the API response
    $response_body = wp_remote_retrieve_body($response);
    
    $data = json_decode($response_body, true);
    error_log(print_r($data, true));
    $data['copResults']['latitude'] = 30.7101759;
    $data['copResults']['longitude'] = 76.690869;
    // Validate latitude and longitude in the response
    if (isset($data['copResults']['latitude']) && isset($data['copResults']['longitude'])) {
        $latitude = $data['copResults']['latitude'];
        $longitude = $data['copResults']['longitude'];
    //set cooridnates value in the location transient 
    
if (is_user_logged_in()) {

    $user_id = get_current_user_id();
    $transient_key = 'user_' . $user_id . '_location_transient';
    $location_transient = array(
                'user_lat' => $latitude,
                'user_lon' => $longitude,
            );
    //$transient_key = 'user_guest_location_transient_' . session_id();
    set_transient($transient_key, $location_transient, 3600);
}
else {
    $transient_key = 'user_guest_location_transient_' . session_id();
    $location_transient = array(
                'user_lat' => $latitude,
                'user_lon' => $longitude,
            );
    set_transient($transient_key, $location_transient, 3600);
    
}
            
        // Return the coordinates
        wp_send_json_success([
            'lat' => $latitude,
            'lon' => $longitude
        ]);
    } else {
        wp_send_json_error(['message' => 'Invalid response: Missing coordinates']);
    }
}

add_action('wp_ajax_fetch_coordinates_from_address', 'fetch_coordinates_from_address'); // For logged-in users
add_action('wp_ajax_nopriv_fetch_coordinates_from_address', 'fetch_coordinates_from_address'); // For non-logged-in users

function handle_remove_from_wishlist()
{
    if (isset($_POST['remove_from_wishlist']) && is_user_logged_in()) {

        if (isset($_POST['remove_wishlist_nonce']) && wp_verify_nonce($_POST['remove_wishlist_nonce'], 'remove_from_wishlist')) {

            $product_id = intval($_POST['product_id']);

            $user_id = get_current_user_id();

            $wishlist = YITH_WCWL_Wishlists()->get_wishlists();

            foreach ($wishlist as $list) {
                // If wishlist ID matches, attempt to remove the product
                if ($list->get_user_id() == $user_id) {
                    // Use the plugin's remove_item method
                    $args = array(
                        'product_id'  => $product_id,
                        'wishlist_id' => $list->get_id(),
                        'user_id'     => $user_id,
                    );
                    YITH_WCWL_Wishlists()->remove_item($args);

                    // Trigger the action after removing the product
                    do_action('yith_wcwl_removing_from_wishlist', $product_id);
                    break;
                }
            }

            // Redirect to the same page to prevent resubmission
            wp_redirect(add_query_arg('wishlist_updated', 'true', get_permalink()));
            exit; // Always call exit after redirect to prevent further processing
        }
    }
}
add_action('template_redirect', 'handle_remove_from_wishlist');



// Hook to autofill checkout address fields from session data
// add_filter('woocommerce_checkout_get_value', 'autofill_checkout_address_from_session', 10, 2);

// function autofill_checkout_address_from_session($value, $input_name) {
//     // Check if session data exists for address fields (array)
// if (!session_id()) {
//         session_start();
//     }
//     if (isset($_SESSION['formatted_address']) && is_array($_SESSION['formatted_address'])) {
//         $user_address = $_SESSION['formatted_address'];
//       //echo '<pre>'; print_r($user_address); die;

//         // Map the array keys to the corresponding WooCommerce checkout fields
//         switch ($input_name) {
//             case 'billing_address_1':
//                 return isset($user_address['house_number']) ? $user_address['house_number'] : ''; // House number
//             case 'billing_address_2':
//                 return isset($user_address['subLocality']) ? $user_address['subLocality'].' '.$user_address['locality'] : ''; // Sub locality
//             case 'billing_city':
//                 return isset($user_address['city']) ? $user_address['city'] : ''; // City
//             case 'select2-billing_state-container':
//               return isset($user_address['state']) ? $user_address['state'] : '';
//             case 'billing_postcode':
//                 return isset($user_address['pincode']) ? $user_address['pincode'] : ''; // Postcode
//             // Add more cases if needed for other fields
//         }
//     }
//     return $value; // Return original value if no session data or no match
// }
function custom_checkout_js_by_path() {
    // Check if we are on the checkout page by its path
    if (strpos($_SERVER['REQUEST_URI'], 'checkoutw') !== false) {
        ?>
     <script type="text/javascript">
    function autofill_checkout_address() {
        <?php error_log(print_r($_SESSION['formatted_address'],true));?>
        var state_mapping = {
            "Andhra Pradesh": "AP",
            "Arunachal Pradesh": "AR",
            "Assam": "AS",
            "Bihar": "BR",
            "Chhattisgarh": "CT",
            "Goa": "GA",
            "Gujarat": "GJ",
            "Haryana": "HR",
            "Himachal Pradesh": "HP",
            "Jammu and Kashmir": "JK",
            "Jharkhand": "JH",
            "Karnataka": "KA",
            "Kerala": "KL",
            "Ladakh": "LA",
            "Madhya Pradesh": "MP",
            "Maharashtra": "MH",
            "Manipur": "MN",
            "Meghalaya": "ML",
            "Mizoram": "MZ",
            "Nagaland": "NL",
            "Odisha": "OR",
            "Punjab": "PB",
            "Rajasthan": "RJ",
            "Sikkim": "SK",
            "Tamil Nadu": "TN",
            "Telangana": "TS",
            "Tripura": "TR",
            "Uttarakhand": "UK",
            "Uttar Pradesh": "UP",
            "West Bengal": "WB",
            "Andaman and Nicobar Islands": "AN",
            "Chandigarh": "CH",
            "Dadra and Nagar Haveli": "DN",
            "Daman and Diu": "DD",
            "Delhi": "DL",
            "Lakshadeep": "LD",
            "Pondicherry (Puducherry)": "PY"
        };

        // Fetch the session data and fill the address fields
        var user_address = <?php echo json_encode($_SESSION['formatted_address']); ?>;

        // Check if user_address data exists
        if (user_address) {
            // Autofill the fields based on session data
// Check and set houseNumber independently
var houseNumber = user_address.houseNumber || '';
if (houseNumber.includes('undefined') || houseNumber.includes('Unnamed Road')) {
    houseNumber = ''; // Clear if invalid
}

// Check and set street independently
var street = user_address.street || '';
if (street.includes('undefined') || street.includes('Unnamed Road')) {
    street = ''; // Clear if invalid
}

// Combine houseNumber and street (if valid)
var houseNumberAndStreet = houseNumber + (houseNumber && street ? ' ' : '') + street;

// Set the billing address field
$('#billing_address_1').val(houseNumberAndStreet).trigger('change');

            $('#billing_address_2').val(user_address.subLocality+' '+user_address.locality || '').trigger('change');  // Sub locality
            $('#billing_city').val(user_address.city || '').trigger('change');  // City
            $('#billing_state').val(state_mapping[user_address.state] || '').trigger('change');  // State
            $('#billing_postcode').val(user_address.pincode || '').trigger('change');  // Postcode

            // Add more fields if needed
            // Trigger change event for select2 state dropdown
            $('#billing_state').trigger('change');
        }
    }
    window.autofill_checkout_address = autofill_checkout_address;

    // Make sure the function is called when the page is ready
    jQuery(document).ready(function($) {
        autofill_checkout_address(); // Call the function to autofill the fields on page load
    });
</script>

        <?php
    }
}
add_action('wp_footer', 'custom_checkout_js_by_path');

function custom_checkout_js() {
    if (strpos($_SERVER['REQUEST_URI'], 'checkoutw') !== false) {
        ?>  
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Function to get values from the checkout form fields
            function get_checkout_data() {
                var house_number = $('#billing_address_1').val();
                var subLocality = $('#billing_address_2').val();
                var city = $('#billing_city').val();
                // var state_full = $('#billing_state').val();
                var state_full = $('#billing_state option:selected').text();
                var postcode = $('#billing_postcode').val();

                // Build the address query string
                var address_query = house_number + ' ' + subLocality + ' ' + city + ' ' + state_full + ' ' + postcode;
                return address_query;
            }
        
            // On checkout form submit, make a geocode API query
            $('form.checkout').on('submit', async function(event) {
                event.preventDefault();  // Prevent the default form submission

                var address_query = get_checkout_data();
                if (address_query) {
                    try {
                        // Send the geocode request to WordPress AJAX handler using fetch API
                        const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            },
                            body: new URLSearchParams({
                                action: 'fetch_coordinates_from_address',
                                address_query: address_query
                            })
                        });

                        const data = await response.json();
                        if (data.success) {
                            // console.log('hey:');
                            console.log('data:', data);
                            var lat = data.data.lat;
                            var lon = data.data.lon;
                            console.log('Latitude:', lat, 'Longitude:', lon);
                            // Optionally, you can store the lat/lon in hidden fields or use them as needed

                            // After the geocode response, allow the checkout to proceed
                           // $('form.checkout')[0].submit();  // Submit the form
                        } else {
                            console.log('Error: ' + data.data.message);
                        }
                    } catch (error) {
                        console.log('Error fetching geocode data: ' + error.message);
                    }
                } else {
                    alert('Please provide a complete address.');
                }
            });
        });
        </script>
        <?php
    }
}
add_action('wp_footer', 'custom_checkout_js');

function set_formatted_address(){

if (isset($_COOKIE['user_address'])) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    $user_address = trim($_COOKIE['user_address']);
    $addressParts = array_map('trim', explode(',', $user_address));
    $requiredCount = 7;
    $missingFields = $requiredCount - count($addressParts);

    // Add empty strings at the beginning if necessary
    if ($missingFields > 0) {
        for ($i = 0; $i < $missingFields; $i++) {
            array_unshift($addressParts, '');
        }
    }

    // Map the parts to meaningful keys
    $addressArray = [
        'houseNumber' => $addressParts[0],
        'street' => $addressParts[1],
        'SubLocality' => $addressParts[2],
        'locality' => $addressParts[3],
        'city' => $addressParts[4],
        'state' => $addressParts[5],
        'pincode' => $addressParts[6],
    ];

    // Store the address array in session
    $_SESSION['formatted_address'] = $addressArray;

    // echo '<pre>';print_r($_SESSION['formatted_address']);echo '</pre>';
}
}
add_action('wp_ajax_set_formatted_address', 'set_formatted_address'); // For logged-in users
add_action('wp_ajax_set_formatted_address', 'set_formatted_address'); // For non-logged-in users

		function limit_cart_to_one_product($cart_item_key, $product_id, $quantity, $variation_id, $variation) {

			$cart = WC()->cart;

			foreach ($cart->get_cart() as $key => $item) {
				if ($key !== $cart_item_key) {
					$cart->remove_cart_item($key);
				}
			}
		}
			add_action('woocommerce_add_to_cart', 'limit_cart_to_one_product', 10, 5);

			add_action('woocommerce_after_checkout_validation', 'custom_phone_validation', 10, 2);

		function custom_phone_validation($fields, $errors) {
			// Get the phone number from the checkout form
			$phone = isset($fields['billing_phone']) ? $fields['billing_phone'] : '';

			// Define a regex pattern for validation (e.g., only numbers, 10-15 digits)
			$pattern = '/^\d{10}$/';

			// Check if the phone number matches the pattern
			if (!preg_match($pattern, $phone)) {
				// Add an error message
				$errors->add('validation', __('Please enter a valid phone number (10 digits).', 'woocommerce'));
			}
		}
		function custom_user_registration_js() {
				// Check if the current URL contains 'user-registration/'
				if (strpos($_SERVER['REQUEST_URI'], 'user-registration') !== false) {
					?>
					<script type="text/javascript">
			document.addEventListener("DOMContentLoaded", function() {
				const form = document.querySelector('[data-form-id="472"]');
				const phoneInput = document.getElementById('number_box_1735538731');
				if (form && phoneInput) {
					// Restrict input to digits only and limit to 10 digits
					phoneInput.addEventListener('input', function(e) {
						phoneInput.value = phoneInput.value.replace(/\D/g, '').slice(0, 10);
					});
					form.addEventListener('submit', function(e) {
						const phoneValue = phoneInput.value.trim();
						if (!/^\d{10}$/.test(phoneValue)) {
							e.preventDefault();
							alert('Please enter a valid 10-digit phone number.');
							phoneInput.focus();
						}
					});
				} else {
					console.error('Form or phone input field not found.');
				}
			});

					</script>
					<?php
				}
		}
add_action('wp_footer', 'custom_user_registration_js');
/*
function get_available_slots_for_service_via_ajax($service_id, $selected_date, $csrf_token) {
    // Define the form ID related to the service (you can set it dynamically)
    $form_id = '678253dc66dcb'; // Example form ID, you should replace it with the actual form ID for the service

    // Prepare the request URL to make an AJAX call to admin-ajax.php
    $url = admin_url('admin-ajax.php');

    // Prepare the request parameters
    $params = array(
        'action'       => 'bookly_render_time',  // The action to trigger the Bookly service rendering
        'form_id'      => $form_id,                 // The form ID
        'selected_date' => $selected_date,          // The selected date for available slots
        'service_id'   => $service_id,              // The service ID for which you want the slots
        'csrf_token'   => $csrf_token,             // CSRF token for security
        'time_zone'    => 'Asia/Kolkata',           // You can adjust the timezone accordingly
        'time_zone_offset' => '-330'                // Time zone offset (in minutes)
    );

    // Make the AJAX request
    $response = wp_remote_get(add_query_arg($params, $url));

    // Check if the request was successful
    if (is_wp_error($response)) {
        return new WP_Error('request_failed', 'Failed to fetch available slots');
    }

    // Get and return the available time slots data
    $body = wp_remote_retrieve_body($response);
    return json_decode($body); // Assuming the response is JSON formatted
}

// Register a custom REST route for fetching available slots
add_action('rest_api_init', function () {
    register_rest_route('bookly/v1', '/available-time-slots/', [
        'methods' => 'GET',
        'callback' => 'get_bookly_available_slots',
    ]);
});

function get_bookly_available_slots(WP_REST_Request $request) {
    // Get parameters from the API request
    $service_id = $request->get_param('service_id');
    $selected_date = $request->get_param('selected_date');
    $csrf_token = $request->get_param('csrf_token');

    // Ensure the required parameters are provided
    if (!$service_id || !$selected_date || !$csrf_token) {
        return new WP_REST_Response('Missing required parameters', 400);
    }

    // Call the function to fetch available slots for the given service and date
    $available_slots = get_available_slots_for_service_via_ajax($service_id, $selected_date, $csrf_token);

    // If the response is an error, return the error response
    if (is_wp_error($available_slots)) {
        return new WP_REST_Response('Failed to fetch available slots.', 400);
    }

    // Return the available slots data
    return new WP_REST_Response($available_slots, 200);
}*/
	function get_eloc_from_address_mapmyindia($address) {
		$token = fetch_mappls_token();
		$url = 'https://atlas.mapmyindia.com/api/places/geocode?address=' . urlencode($address);

		// Set up headers for MapMyIndia API
		$headers = array(
			'Authorization' => 'Bearer ' . $token,
		);

		// Use WordPress HTTP API to make the request
		$response = wp_remote_get($url, array('headers' => $headers));

		// Check for errors
		if (is_wp_error($response)) {
			return 'Error: Unable to fetch location data';
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);

		// Check the response for the `eloc`
		if (isset($data['copResults']['eLoc'])) {
			return $data['copResults']['eLoc']; // Return the eloc value
		} else {
			return 'Error: Unable to fetch eLoc';
		}
	}
	add_filter('check_ajax_referer', '__return_true');
/*
add_action('bookly_service_added', 'assign_random_service_provider', 10, 1);

function assign_random_service_provider($service_id) {
    global $wpdb;

    // Table names (adjust them as per your database prefix)
    $staff_table = 'gOP_bookly_staff'; // Staff table
    $staff_services_table = 'gOP_bookly_staff_services'; // Staff-services table

    // Fetch all service providers
    $service_providers = $wpdb->get_results("SELECT id, full_name FROM `$staff_table`");

    if (!empty($service_providers)) {
        // Select a random provider
        $random_provider = $service_providers[array_rand($service_providers)];

        // Assign the provider to the service
        $result = $wpdb->insert(
            $staff_services_table, // Staff-services table
            [
                'staff_id' => $random_provider->id,
                'service_id' => $service_id,
            ],
            ['%d', '%d']
        );

        // Debug and error handling
        if ($result === false) {
            error_log('Database error while assigning provider: ' . $wpdb->last_error);
        } else {
            error_log('Assigned provider ID ' . $random_provider->id . ' to service ID ' . $service_id);
        }
    } else {
        error_log('No service providers found in the database.');
    }
}
function assign_random_provider_to_service($service_id) {
    global $wpdb;
//echo "<pre>"; print_r($service_id);die;
    $service_id = $wpdb->get_var("SELECT id FROM gOP_bookly_services ORDER BY id DESC LIMIT 1");
    $staff_id = $wpdb->get_var("SELECT id FROM gOP_bookly_staff ORDER BY RAND() LIMIT 1");
	
	if ($service_id && $staff_id) {
    // Insert into gOP_bookly_staff_services table
    $wpdb->insert(
        'gOP_bookly_staff_services',
        array(
            'staff_id'   => $staff_id,
            'service_id' => $service_id,
        ),
        array('%d', '%d')
    );

}
else {
    echo "Error: No staff or service found.";
}
	
   
}

// Hook into the service creation event
add_action('bookly_service_created', 'assign_random_provider_to_service', 10, 1);*/
function assign_random_provider_to_service($service_id) {
    global $wpdb;

    // Check if service_id is valid
    if (!$service_id) {
        echo "Error: Invalid service ID.";
        return;
    }

    // Fetch a random staff member from gOP_bookly_staff
    $staff_id = $wpdb->get_var("SELECT id FROM gOP_bookly_staff ORDER BY RAND() LIMIT 1");

    if ($staff_id) {
        // Insert the staff-service relation into gOP_bookly_staff_services
        $wpdb->insert(
            'gOP_bookly_staff_services',
            array(
                'staff_id'   => $staff_id,
                'service_id' => $service_id,
            ),
            array('%d', '%d')
        );
    } else {
        echo "Error: No staff found.";
    }
}

// Hook into the service creation event (ensure this hook exists in Bookly)
add_action('bookly_service_created', 'assign_random_provider_to_service', 10, 1);
/*
function handle_search_products_services() {
    if (isset($_GET['query'])) {
        $query = sanitize_text_field($_GET['query']);
        
        // Query products (You can adjust this part based on your custom post types or categories)
        $args = array(
            'post_type' => 'product', // You can change this to your custom post type, e.g., 'service'
            'posts_per_page' => 5,
            's' => $query // WordPress built-in search
        );

        $query_results = new WP_Query($args);

        if ($query_results->have_posts()) {
            while ($query_results->have_posts()) {
                $query_results->the_post();
                echo '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
            }
        } else {
            echo '<li>No results found</li>';
        }

        wp_reset_postdata();
    }

    die(); // Always die to avoid unnecessary output
}

add_action('wp_ajax_search_products_services', 'handle_search_products_services');
add_action('wp_ajax_nopriv_search_products_services', 'handle_search_products_services');
*/
function custom_product_search( $query ) {
    if ( $query->is_search() && !is_admin() ) {
        // Only search in products
        $query->set( 'post_type', 'product' ); // For WooCommerce products
        $query->set( 'posts_per_page', 10 ); // Limit the number of products shown
    }
    return $query;
}
add_filter( 'pre_get_posts', 'custom_product_search' );
// Remove quantity field from product pages
// add_filter('woocommerce_is_sold_individually', '__return_true');

// Set quantity to 1 when adding to cart
/*add_filter('woocommerce_add_to_cart_quantity', function($quantity) {
    return 1;
});*/

// Hide quantity input field on product pages
/*add_action('woocommerce_before_add_to_cart_button', function() {
    echo '<style>.quantity { display: none; }</style>';
});*/

function custom_dokan_menu( $urls ) {
    $urls['view-orders'] = array(
        'title'      => __( 'View Orders', 'dokan-lite' ),
        'icon'       => '<i class="dashicons dashicons-list-view"></i>',
        'url'        => dokan_get_navigation_url( 'orders' ),
        'pos'        => 25,
    );
    return $urls;
}
add_filter( 'dokan_get_dashboard_nav', 'custom_dokan_menu' );


function send_msg91_otp() {
    if (!isset($_POST['phone']) || empty($_POST['phone'])) {
        wp_send_json(['status' => 'error', 'message' => 'Phone number or email is required']);
        wp_die();
    }

    $identifier = sanitize_text_field($_POST['phone']);
    $otp = rand(1000, 9999); // Generate random OTP
    $user_id = checkUserId($identifier);

    if (!$user_id) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to create or retrieve user']);
        wp_die();
    }
    update_user_meta($user_id, 'otp_code', $otp);
    update_user_meta($user_id, 'otp_expiry', time() + 300); // 5-minute expiry
    if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
        send_email_otp($identifier, $otp);
    } else {
        // Store phone number in user meta
        update_user_meta($user_id, 'phone_number', $identifier);
        
        // Send OTP for phone number
        send_phone_otp($identifier, $otp);
    }

    // Save OTP and expiry in user meta
   

    wp_send_json(['status' => 'success', 'message' => 'OTP sent successfully']);
    wp_die();
}

// Hook to AJAX for frontend calls
add_action('wp_ajax_send_otp', 'send_msg91_otp');
add_action('wp_ajax_nopriv_send_otp', 'send_msg91_otp');


function resend_msg91_otp() {
    if (!isset($_POST['phone']) || empty($_POST['phone'])) {
        wp_send_json(['status' => 'error', 'message' => 'Phone number or email is required']);
        wp_die();
    }

    $identifier = sanitize_text_field($_POST['phone']);
    $otp = rand(1000, 9999); // Generate random OTP
    $user_id = checkUserId($identifier);

    if (!$user_id) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to create or retrieve user']);
        wp_die();
    }

    if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
		$otp = get_user_meta($user_id, 'otp_code', true);		

        send_email_otp($identifier, $otp);
    } else {
        
        resend_phone_otp($identifier);
    }

   

    wp_send_json(['status' => 'success', 'message' => 'OTP sent successfully']);
    wp_die();
}

// Hook to AJAX for frontend calls
add_action('wp_ajax_resend_otp', 'resend_msg91_otp');
add_action('wp_ajax_nopriv_resend_otp', 'resend_msg91_otp');

function resend_otp_app($identifier) {
    if (empty($identifier)) {
        wp_send_json(['status' => 'error', 'message' => 'Phone number or email is required']);
        wp_die();
    }

    $identifier = sanitize_text_field($identifier);
    $otp = rand(1000, 9999); // Generate random OTP
    $user_id = checkUserId($identifier);

    if (!$user_id) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to create or retrieve user']);
        wp_die();
    }

    if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
		$otp = get_user_meta($user_id, 'otp_code', true);		

        send_email_otp($identifier, $otp);
    } else {
        
        resend_phone_otp($identifier);
    }

   

    wp_send_json(['status' => 'success', 'message' => 'OTP sent successfully']);
    wp_die();
}

// Function to send OTP via Email
function send_email_otp($email, $otp) {
    $subject = "Your OTP for Login";
    $message = "Your OTP for login is: <strong>$otp</strong>";
    $headers = ['Content-Type: text/html; charset=UTF-8'];

    $mail_sent = wp_mail($email, $subject, $message, $headers);

    if (!$mail_sent) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to send OTP via email']);
        wp_die();
    }
	else{
		 wp_send_json(['status' => 'success', 'message' => 'OTP sent successfully']);
		wp_die();
	}
}

// Function to send OTP via MSG91 SMS API
function send_phone_otp($phone, $otp) {
    $msg91_key = defined('WC_MSG91_Key') ? WC_MSG91_Key : '';
    $msg91_sender_id = defined('WC_MSG91_SENDER_ID') ? WC_MSG91_SENDER_ID : '';
    $msg91_template_id = defined('WC_MSG91_TEMPLATE_ID') ? WC_MSG91_TEMPLATE_ID : '';

    if (empty($msg91_key) || empty($msg91_sender_id) || empty($msg91_template_id)) {
        wp_send_json(['status' => 'error', 'message' => 'MSG91 API credentials are missing']);
        wp_die();
    }

    // API URL
	// echo "aasdfeeff";die;
    $url = "https://control.msg91.com/api/v5/otp?otp_expiry=5&template_id=".$msg91_template_id."&mobile=+91".$phone."&authkey=".$msg91_key."&realTimeResponse=yes";

    $args = [
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode(['OTP' => $otp]),
        'method' => 'POST',
    ];

    $response = wp_remote_post($url, $args);

    if (is_wp_error($response)) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to send OTP via SMS']);
        //wp_die();
    }else{
		 wp_send_json(['status' => 'success', 'message' => 'OTP sent successfully']);
		//wp_die();
	}
}
function resend_phone_otp($phone) {
    $msg91_key = defined('WC_MSG91_Key') ? WC_MSG91_Key : '';
    $msg91_sender_id = defined('WC_MSG91_SENDER_ID') ? WC_MSG91_SENDER_ID : '';
    $msg91_template_id = defined('WC_MSG91_TEMPLATE_ID') ? WC_MSG91_TEMPLATE_ID : '';

    if (empty($msg91_key) || empty($msg91_sender_id) || empty($msg91_template_id)) {
        wp_send_json(['status' => 'error', 'message' => 'MSG91 API credentials are missing']);
        wp_die();
    }

    // API URL
  
	$url = "https://control.msg91.com/api/v5/otp/retry?mobile=+91".$phone."&authkey=".$msg91_key."&retrytype=text";


    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to send OTP via SMS']);
        wp_die();
    }
}

// Function to check or create user
function checkUserId($identifier) {
    if (is_email($identifier)) {
        $user = get_user_by('email', $identifier);
    } 
    else {
        $users = get_users([
            'meta_key'   => 'user_registration_phone', 
            'meta_value' => $identifier,
            'number'     => 1, // Limit to one user
        ]);

        $user = !empty($users) ? $users[0] : false;
    }


    if ($user) {
        return $user->ID; // Return existing user ID
    }
	return false;
/*
    // If user doesn't exist, create a new one
    $user_data = [
        'user_login' => $identifier,
        'user_pass'  => wp_generate_password(),
        'role'       => 'subscriber'
    ];

    if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
        $user_data['user_email'] = $identifier;
    }

    $user_id = wp_insert_user($user_data);

    return !is_wp_error($user_id) ? $user_id : false;*/
}

function verify_msg91_otp() {
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Headers: *");
    if (!isset($_POST['phone']) || !isset($_POST['otp'])) {
        wp_send_json(['status' => 'error', 'message' => 'Phone and OTP are required']);
        wp_die();
    }
    $identifier = sanitize_text_field($_POST['phone']);
    $otp = sanitize_text_field($_POST['otp']);
	$user_id = checkUserId($identifier);
	
    if (!$user_id) {
        wp_send_json(['status' => 'error', 'message' => 'Failed to create or retrieve user']);
        wp_die();
    }
    $stored_otp = get_user_meta($user_id, 'otp_code', true);
    $otp_expiry = get_user_meta($user_id, 'otp_expiry', true);
    // echo $stored_otp ."!=". $otp;die;
    if ($stored_otp != $otp) {
        wp_send_json(['status' => 'error', 'message' => 'Invalid OTP']);
        wp_die();
    }

    if (time() > $otp_expiry) {
        wp_send_json(['status' => 'error', 'message' => 'OTP has expired']);
        wp_die();
    }

    // OTP is valid; log in the user
    wp_set_auth_cookie($user_id);

    // Delete OTP after login
    delete_user_meta($user_id, 'otp_code');
    delete_user_meta($user_id, 'otp_expiry');
	$user_details = HelperService::get_user_details($user_id);
	$token = HelperService::generate_jwt_token( $user_id );
	$user_details = array_merge(['token' => $token],$user_details);		
    wp_send_json(['status' => true, 'message' => 'Login successful', 'data' => $user_details]);
    wp_die();
}

add_action('wp_ajax_verify_otp', 'verify_msg91_otp');
add_action('wp_ajax_nopriv_verify_otp', 'verify_msg91_otp');


 

function otp_login_form() {
    ob_start();
    ?>
    <div id="otp-login-container">
        <div id="messages"></div>
        <div id="request-section">
            <label for="html"><strong>Enter your Register Email or Phone Number</strong></label><br>

            <input type="text" id="phone" placeholder="Enter Email/Mobile Number" required>
               
            <div id="error-message" class="error-message" style="color: red; font-size: 14px; margin-top: 10px;"></div>
            <button id="sendOtp">Request OTP</button>
        </div>
        <div id="otp-section" style="display: none;">
            <label>Please enter the otp sent to <br><b id="inputNumber"></b></label>
            <div id="otp-inputs">
                <input type="text" class="otp-input" maxlength="1">
                <input type="text" class="otp-input" maxlength="1">
                <input type="text" class="otp-input" maxlength="1">
                <input type="text" class="otp-input" maxlength="1">
            </div>
			 <div class="error-message" style="color: red; font-size: 14px; margin-top: 10px;"></div>
            <button id="verifyOtp">Verify OTP</button>
            <label>Not received your code? <span id="resend_code">Resend code</span></label>
        </div>
        
        <div id="register-section" style="margin-top: 20px;">
            <p>Don't have an account yet? <a href="/user-registration">Register</a></p>
        </div>
       
    </div>

    <style>
        #otp-inputs {
            display: flex;
            gap: 10px;
        }

        .otp-input {
            width: 40px;
            height: 40px;
            font-size: 20px;
            text-align: center;
        }

        #register-section {
            text-align: center;
            margin-top: 20px;
        }
        
        #registerBtn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #registerBtn:hover {
            background-color: #45a049;
        }
    </style>
    <?php
}

add_shortcode('otp_login_form', 'otp_login_form');

function custom_existing_account_message($message, $user_email) {
    // Set your custom login URL
    $custom_login_url = site_url('/login/');

    // Modify the message with the new login link
    $custom_message = sprintf(
        'An account is already registered with your email address. <a href="%s">Please log in here.</a>',
        esc_url($custom_login_url)
    );

    return $custom_message;
}
add_filter('woocommerce_registration_error_email_exists', 'custom_existing_account_message', 10, 2);


add_action('woocommerce_single_product_summary', function () {
    global $wpdb;

    $product_id = get_the_ID();
    $service_id = get_post_meta($product_id, 'bookly_service_id', true);

    if (empty($service_id)) {
        echo '<p style="color: red; font-weight: bold;">Bookly service ID not found in product meta.</p>';
        return;
    }

    // Debugging output
    echo "<p style='color: blue;'>Service ID: " . esc_html($service_id) . "</p>";

    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}bookly_staff_services WHERE service_id = %d",
        $service_id
    ));

    if ($count == 0) {
        echo '<p style="color: red; font-weight: bold;">No service provider available.</p>';
    }
}, 35);

function add_custom_button_below_ur_login() {
	if (!is_user_logged_in()) {
        ?>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            let loginForm = $('.user-registration-form-login');
            if (loginForm.length) {
               let buttonHtml = '<div style="text-align: center; font-weight: bold; margin-top: 10px;">OR</div>' + 
                    '<a href="<?php echo esc_url(home_url('/login-with-otp/')); ?>" class="ur-custom-button">Login with OTP</a>' +
                    '</p>'+
					'<span>Don\'t have an account yet? <a href="/user-registration">Register </a></span>';
                loginForm.append(buttonHtml);
            }
        });
    </script>
    <style>
        .ur-custom-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0073aa;
            color: #fff;
            text-decoration: none;
            border-radius: 4px; 
            font-size: 14px;
            transition: background 0.3s;
        }
        .ur-custom-button:hover {
            background-color: #005a87;
        }
    </style>
    <?php
	}
}
add_action('wp_footer', 'add_custom_button_below_ur_login');

add_filter('wp_mail_failed', function ($error) {
    error_log(print_r($error, true));
});




function custom_wc_reset_password_email($user_login) {
    $user = get_user_by('login', $user_login);
    
    if (!$user) {
        return; // User not found
    }

	$reset_key = wp_generate_password(20, false);
	update_user_meta($user->ID, 'password_reset_key', $reset_key);
  
    
    $reset_link = site_url("wp-login.php?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login));

    // Email subject
    $subject = "Reset Your Password - " . get_bloginfo('name');

    // Email body
    $message = "Hello " . $user->display_name . ",\n\n";
    $message .= "Someone has requested a password reset for your account.\n";
    $message .= "If this was you, click the link below to reset your password:\n\n";
    $message .= $reset_link . "\n\n";
    $message .= "If you did not request this, you can ignore this email.\n\n";
    $message .= "Thanks,\n" . get_bloginfo('name');

    // Headers
    $headers = array('Content-Type: text/plain; charset=UTF-8');
	
    // Send email
    // wp_mail($user->user_email, $subject, $message, $headers);
	// die;
	if (wp_mail($user->user_email, $subject, $message, $headers)) {
        return ['status' => 'success', 'message' => 'Reset link sent to email.', 'reset_link' => $reset_link];
    } else {
        return ['status' => 'error', 'message' => 'Failed to send email.'];
    }
}

// Hook into WooCommerce reset password process
// add_action('retrieve_password', 'custom_wc_reset_password_email');


function custom_replace_lost_password_link() {
    ?>
    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
            let lostPasswordLinks = document.querySelectorAll("a[href*='my-account/lost-password']");
            lostPasswordLinks.forEach(link => {
                link.href = "<?php echo esc_url(site_url('/wp-login.php?action=lostpassword')); ?>";
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'custom_replace_lost_password_link');

			function custom_login_template() {
				get_header();  // Load theme header
			}
			add_action('login_head', 'custom_login_template');

			function custom_login_footer() {
				get_footer();  // Load theme footer
			}
			add_action('login_footer', 'custom_login_footer');
			
			function custom_override_checkout_fields( $fields ) {
				$fields['billing']['billing_last_name']['required'] = false; // Make Last Name optional
				return $fields;
			}
			add_filter( 'woocommerce_checkout_fields', 'custom_override_checkout_fields' );
				
		add_filter('woocommerce_checkout_get_value', 'populate_checkout_user_meta', 10, 2);
		function populate_checkout_user_meta($value, $input) {
			// If it's the first name field
			if ($input === 'billing_first_name') {
				$user_id = get_current_user_id();
				if ($user_id) {
					$first_name = get_user_meta($user_id, 'first_name', true); // Fetch first name
					return $first_name ? $first_name : $value; // Return first name if available, else return current value
				}
			}

			// If it's the phone number field
			if ($input === 'billing_phone') {
				$user_id = get_current_user_id();
				if ($user_id) {
					$phone = get_user_meta($user_id, 'user_registration_phone', true); // Fetch phone number
					return $phone ? $phone : $value; // Return phone number if available, else return current value
				}
			}

			return $value; // For other fields, return their current value
		}
	
	// Add custom code to pre-populate name and phone on the book service page
	add_action('wp_footer', 'prepopulate_name_and_phone_on_book_service_page');
	function prepopulate_name_and_phone_on_book_service_page() {
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			
			$user_phone = get_user_meta($user_id, 'user_registration_phone', true); // Assuming phone is stored here

			// Only proceed if we have both a name and phone
			if ($user_phone) {
				?>
				<script type="text/javascript">
					document.addEventListener('bookly_session_save', function() {
						// Pre-populate the fields
						var phoneField = document.querySelector('.bookly-js-user-phone-input'); // Change the ID if needed
						
						if (phoneField) {
							phoneField.value = "<?php echo esc_js($user_phone); ?>"; // Set the phone number in the field
						}

					
					});
				</script>
				<?php
			}
		}
	}
	

		function auto_check_declaration_checkbox_jquery() { ?>
			<script>
				jQuery(document).ready(function ($) {
					$('input[name="user_registration_privacy_policy_1623078743"]').prop('checked', true);
				});
			</script>
		<?php }
	add_action('wp_footer', 'auto_check_declaration_checkbox_jquery');

		function update_user_register_phone($user_id) {
			if (current_user_can('edit_users')) {
				if (isset($_POST['register_phone'])) {
					update_user_meta($user_id, 'register_phone', sanitize_text_field($_POST['register_phone']));
				}
			}
		}
	add_action('profile_update', 'update_user_register_phone');

	add_action('woocommerce_order_status_changed', 'send_custom_order_email', 10, 4);

function send_custom_order_email($order_id, $old_status, $new_status, $order) {
    if (!$order_id || $new_status !== 'processing') return;

    global $wpdb;
    
    // Get order details
    $order = wc_get_order($order_id);
    $customer_email = $order->get_billing_email();
    $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

    // Get Bookly customer ID using the email
    $customer_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id 
             FROM {$wpdb->prefix}bookly_customers 
             WHERE email = %s 
             LIMIT 1",
            $customer_email
        )
    );

    if (!$customer_id) return;

    // Get the last appointment related to this customer
    $appointment = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT appointment_id 
             FROM {$wpdb->prefix}bookly_customer_appointments 
             WHERE customer_id = %d 
             ORDER BY id DESC 
             LIMIT 1",
            $customer_id
        )
    );

    if (empty($appointment)) return;

    $appointment_id = $appointment[0]->appointment_id;

    // Get appointment details
    $appointment_data = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT start_date, staff_id 
             FROM {$wpdb->prefix}bookly_appointments 
             WHERE id = %d",
            $appointment_id
        )
    );

    if (!$appointment_data) return;

    $staff_id = $appointment_data->staff_id;

    // Get staff details
    $staff_data = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT full_name, email, phone, attachment_id 
             FROM {$wpdb->prefix}bookly_staff 
             WHERE id = %d",
            $staff_id
        )
    );

    if (!$staff_data) return;

    // Get the image URL from attachment ID
    $attachment_id = $staff_data->attachment_id;
    $image_url = wp_get_attachment_url($attachment_id);

    if (!$image_url) {
        $image_url = 'https://chago.in/wp-content/uploads/2025/02/profile.png'; // Fallback image
    }

    // Get product names
    $products = [];
    foreach ($order->get_items() as $item) {
        $products[] = $item->get_name();
    }
    $product_list = implode(', ', $products);

    // Appointment date formatted
    $appointment_time = date('F j, Y, g:i a', strtotime($appointment_data->start_date));

    // Email subject and body
    $subject = "📅 Your {$product_list} Appointment Confirmation (Order #{$order_id})";
    $message = "<p>Hello <strong>{$customer_name}</strong>,</p>";
    $message .= "<p>Your appointment for <strong>{$product_list}</strong> has been confirmed.</p>";
    $message .= "<p><strong>Staff Member:</strong> {$staff_data->full_name}</p>";
    $message .= "<p><strong>Email:</strong> {$staff_data->email}</p>";
    $message .= "<p><strong>Phone:</strong> {$staff_data->phone}</p>";
    $message .= "<p><strong>Date:</strong> {$appointment_time}</p>";
    $message .= "<p><strong>Staff Image:</strong><br><img src='{$image_url}' alt='Staff Image' width='150' style='border-radius: 10px; margin-top: 10px;'></p>";
    $message .= "<p>Thank you for booking with us!</p>";

    // Email headers
    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: Chago <support@chago.in>'
    ];

    // Send email to customer
    wp_mail($customer_email, $subject, $message, $headers);

    // ------------------------
    // Send SMS to Staff
    // ------------------------

    // Check if staff phone number exists
    $staff_phone = $staff_data->phone;
    if (!empty($staff_phone)) {
		 error_log("Your  phone number found is: {$staff_data->phone}");
        $sms_message = "📅 New Appointment: {$product_list} has been booked for {$appointment_time} with {$customer_name}. Please prepare for the session.";

        // Send SMS to staff using MSG91 or your preferred SMS service
        send_message_via_sms($staff_phone, $sms_message);
    } else {
        error_log("No phone number found for staff: {$staff_data->full_name}");
    }

    // ------------------------
    // Send FCM Notifications
    // ------------------------

    // Load your helper class
    $helperService = new RestMyApis\Services\HelperService();

    // Get WooCommerce user by email
    $user = get_user_by('email', $customer_email);
    $customer_fcm_tokens = $user ? get_user_meta($user->ID, 'device_login_tokens', true) : [];

    // Get Bookly staff user by email (ensure this email exists in wp_users)
    $staff_user = get_user_by('email', $staff_data->email);
    $staff_fcm_tokens = $staff_user ? get_user_meta($staff_user->ID, 'device_login_tokens', true) : [];

    // Customer message
    $customer_msg = "✅ Your appointment for {$product_list} has been confirmed on {$appointment_time} with {$staff_data->full_name}.";

    // Staff message
    $staff_msg = "📢 You have been assigned a new appointment for {$product_list} on {$appointment_time}. Customer: {$customer_name}.";

    // Send push notification to customer if FCM tokens exist
    if (!empty($customer_fcm_tokens)) {
        foreach ($customer_fcm_tokens as $fcm_token) {
            $helperService->sendPushNotification([$fcm_token], $customer_msg);
            error_log("FCM sent to customer ID {$user->ID}");
        }
    } else {
        error_log("No customer FCM tokens found.");
    }

    // Send push notification to staff if FCM tokens exist
    if (!empty($staff_fcm_tokens)) {
        foreach ($staff_fcm_tokens as $fcm_token) {
            $helperService->sendPushNotification([$fcm_token], $staff_msg);
            error_log("FCM sent to staff user: {$staff_data->email}");
        }
    } else {
        error_log("No staff FCM tokens found.");
    }
}




// Helper function to send custom message via SMS (Msg91)
function send_message_via_sms($phone, $message) {
    $msg91_key = defined('WC_MSG91_Key') ? WC_MSG91_Key : '';
    $msg91_sender_id = defined('WC_MSG91_SENDER_ID') ? WC_MSG91_SENDER_ID : '';
    $msg91_template_id = defined('WC_MSG91_TEMPLATE_ID') ? WC_MSG91_TEMPLATE_ID : '';

    if (empty($msg91_key) || empty($msg91_sender_id) || empty($msg91_template_id)) {
        error_log('MSG91 API credentials are missing');
        return ['status' => 'error', 'message' => 'MSG91 API credentials are missing'];
    }

    // Prepare the API URL for sending the SMS
    $url = "https://control.msg91.com/api/v5/otp?template_id=" . $msg91_template_id . "&mobile=+91" . $phone . "&authkey=" . $msg91_key . "&realTimeResponse=yes";

    $args = [
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode(['message' => $message]),
        'method' => 'POST',
    ];

    $response = wp_remote_post($url, $args);

    // Check if the request failed
    if (is_wp_error($response)) {
        error_log('Failed to send message via SMS: ' . $response->get_error_message());
        return ['status' => 'error', 'message' => 'Failed to send message via SMS'];
    }

    // Check the response body for errors or success
    $response_body = wp_remote_retrieve_body($response);
    error_log('MSG91 Response: ' . $response_body);

    // If the response body contains an error message, log it
    if (strpos($response_body, 'error') !== false) {
        error_log('Error in response: ' . $response_body);
        return ['status' => 'error', 'message' => 'Error in sending SMS'];
    }

    return ['status' => 'success', 'message' => 'Message sent successfully'];
}

// Function to send SMS using MSG91 API
function send_sms($phone_number, $message) {
    $api_url = "https://api.msg91.com/api/sendhttp.php"; // MSG91 API URL

    // Ensure that the phone number has the correct format (e.g., +91 followed by 10-digit number)
    if (substr($phone_number, 0, 1) !== '+') {
        $phone_number = '+91' . $phone_number; // Assuming the number is provided without the country code.
    }

    // Set up the parameters for the request
    $params = array(
        'authkey' => '441459AHRXYNEQ67b9c26cP1', // Your MSG91 API Key (make sure it's an SMS key, not OTP)
        'mobiles' => $phone_number, // Phone number to send SMS to
        'message' => $message, // Message you want to send
        'sender' => 'CHAGO', // Your sender ID (this can be customized)
        'route' => '4', // Default route for promotional messages (change to '1' for transactional messages if necessary)
        'country' => '91', // Country code for India (change if needed)
    );

    // Build the query string and make the GET request
    $url = $api_url . '?' . http_build_query($params);
    
    // Use file_get_contents to send the request to the MSG91 API
    $response = file_get_contents($url); 
    
    // Log the response to check if the message was successfully sent
    error_log("MSG91 Response: " . $response);

    // Return the API response (for debugging purposes)
    return $response;
}








function add_bookly_placeholders() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            console.log("✅ Custom script loaded!");

            function addPlaceholders() {
                if ($(".bookly-js-first-name, .bookly-js-last-name, .bookly-js-user-email").length > 0) {
                    console.log("📌 Bookly details step detected!");
                    $(".bookly-js-first-name").attr("placeholder", "Enter your first name");
                    $(".bookly-js-last-name").attr("placeholder", "Enter your last name");
                    $(".bookly-js-user-email").attr("placeholder", "Enter your email address");
                    console.log("✅ Placeholders added successfully!");
                } else {
                    console.log("⚠️ Bookly fields not found.");
                }
            }

            // Wait for `.bookly-details-step` to be available
            let checkBooklyDetailsStep = setInterval(function() {
                if ($(".bookly-details-step").length > 0) {
                    console.log("✅ `.bookly-details-step` detected! Applying placeholders...");
                    clearInterval(checkBooklyDetailsStep);
                    setTimeout(addPlaceholders, 1000); // Wait extra time for fields to load
                }
            }, 500);
        });
    </script>
    <?php
}
add_action('wp_footer', 'add_bookly_placeholders');




//Service Provider Dashboard
add_shortcode('service_provider_dashboard', 'service_provider_dashboard_shortcode');

function service_provider_dashboard_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>You must be logged in to view your dashboard.</p>';
    }

    $user_id = get_current_user_id();
    
    global $wpdb;
    $staff_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}bookly_staff WHERE wp_user_id = %d",
            $user_id
        )
    );

    // Form Submission Logic
    $upload_errors = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['service_provider_nonce']) && wp_verify_nonce($_POST['service_provider_nonce'], 'update_service_provider_profile')) {

        // Phone Number Validation (Must be exactly 10 digits)
        if (isset($_POST['phone_number']) && !preg_match('/^\d{10}$/', $_POST['phone_number'])) {
            $upload_errors['phone_number'] = 'Please enter a valid 10-digit phone number.';
        }

        // File upload handling and other fields
        if (empty($upload_errors)) {
            wp_update_user([
                'ID' => $user_id,
                'display_name' => sanitize_text_field($_POST['display_name']),
                'user_email' => sanitize_email($_POST['user_email'])
            ]);

            // Update phone number and other user meta data
            update_user_meta($user_id, 'phone_number', sanitize_text_field($_POST['phone_number']));
            update_user_meta($user_id, 'selected_category_id', sanitize_text_field($_POST['selected_category_id']));
            update_user_meta($user_id, 'house_area', sanitize_text_field($_POST['house_area']));
            update_user_meta($user_id, 'gali_sector', sanitize_text_field($_POST['gali_sector']));
            update_user_meta($user_id, 'city', sanitize_text_field($_POST['city']));
            update_user_meta($user_id, 'pin_code', sanitize_text_field($_POST['pin_code']));

            // Handle file uploads
            $files = ['profile_image', 'adhaar_front_image', 'adhaar_back_image', 'labour_card'];
            foreach ($files as $field) {
                $file_url = upload_file($field);
                if ($file_url) {
                    update_user_meta($user_id, $field, esc_url_raw($file_url));
                }
            }
        }

        if (empty($upload_errors)) {
            echo '<p>Your profile has been updated successfully!</p>';
        } else {
            foreach ($upload_errors as $error) {
                echo "<p class='error'>$error</p>";
            }
        }
    }

    ob_start();
    ?>

    <section class="serviceProviderMain">
        <div class="container">
            <div class="service-provider-dashboard">
                <div class="dashboard-tabs">
                    <div data-tab="profile">Profile</div>
                    <div data-tab="documents">Documents</div>
                    <div data-tab="address">Address</div>
                    <div data-tab="specializations">Specializations</div>
                    <div data-tab="orders">Orders</div>
                </div>
 <?php
    
    $user_meta = get_user_meta($user_id);
    if (isset($_POST['update_profile']) && wp_verify_nonce($_POST['profile_password_nonce'], 'update_profile_and_password')) {
        $user_id = get_current_user_id();

        // Update profile info
        if (!empty($_POST['display_name'])) {
            wp_update_user([
                'ID' => $user_id,
                'display_name' => sanitize_text_field($_POST['display_name']),
            ]);
        }

        if (!empty($_POST['user_email']) && is_email($_POST['user_email'])) {
            wp_update_user([
                'ID' => $user_id,
                'user_email' => sanitize_email($_POST['user_email']),
            ]);
        }

        if (!empty($_POST['phone_number'])) {
            update_user_meta($user_id, 'phone_number', sanitize_text_field($_POST['phone_number']));
        }

        // Handle profile image (optional logic here)

        // Handle password change
        $current_password = $_POST['current_password'] ?? '';
        $new_password     = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if ($current_password || $new_password || $confirm_password) {
            $user = wp_get_current_user();

            if (!wp_check_password($current_password, $user->user_pass, $user->ID)) {
                echo '<p style="color:red;">Current password is incorrect.</p>';
            } elseif ($new_password !== $confirm_password) {
                echo '<p style="color:red;">New passwords do not match.</p>';
            } elseif (strlen($new_password) < 6) {
                echo '<p style="color:red;">New password must be at least 6 characters.</p>';
            } else {
                wp_set_password($new_password, $user_id);
                wp_logout(); // Log out for security
                echo '<p style="color:green;">Password changed! Please <a href="' . wp_login_url() . '">log in</a> again.</p>';
            }
        }
    }
$user = wp_get_current_user();
?>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('update_service_provider_profile', 'service_provider_nonce'); ?>

                <!-- Profile Tab -->
                        <div class="dashboard-tab-content" id="tab-profile">
                            <h3>Profile Info</h3>
                            <p><strong>Staff ID - <?php echo $staff_id; ?></strong></p>
                            <label>Name: <input type="text" name="display_name" value="<?php echo esc_attr($user->display_name); ?>"></label>
                            <label>Email: <input type="email" name="user_email" value="<?php echo esc_attr($user->user_email); ?>"></label>
                            <label>Phone: <input type="text" name="phone_number" maxlength="10" value="<?php echo esc_attr($user_meta['phone_number'][0] ?? ''); ?>"></label>
                            <label>Profile Image: <input type="file" name="profile_image"></label>
                            <?php if (!empty($user_meta['profile_image'][0])): ?>
                                <div class="doc-preview">
                                    <img src="<?php echo esc_url($user_meta['profile_image'][0]); ?>" alt="Profile Image">
                                </div>
                            <?php endif; ?>
    <a class="change-psw" href="service-provider-password-change/">Click here to change password</a>
                            
                        </div>


                    <!-- Documents Tab -->
                    <div class="dashboard-tab-content" id="tab-documents">
                        <h3>Upload Documents</h3>
                        <label>Aadhaar Front <input type="file" name="adhaar_front_image"></label>
                        <?php if (!empty($user_meta['adhaar_front_image'][0])): ?>
                            <div class="doc-preview"><img src="<?php echo esc_url($user_meta['adhaar_front_image'][0]); ?>" alt="Aadhaar Front"></div>
                        <?php endif; ?>
                        <label>Aadhaar Back <input type="file" name="adhaar_back_image"></label>
                        <?php if (!empty($user_meta['adhaar_back_image'][0])): ?>
                            <div class="doc-preview"><img src="<?php echo esc_url($user_meta['adhaar_back_image'][0]); ?>" alt="Aadhaar Back"></div>
                        <?php endif; ?>
                        <label>Labour Card (Optional) <input type="file" name="labour_card"></label>
                        <?php if (!empty($user_meta['labour_card'][0])): ?>
                            <div class="doc-preview"><img src="<?php echo esc_url($user_meta['labour_card'][0]); ?>" alt="Labour Card"></div>
                        <?php endif; ?>
                    </div>

                    <!-- Address Tab -->
                    <div class="dashboard-tab-content" id="tab-address">
                        <h3>Address Info</h3>
                        <label>House Area: <input type="text" name="house_area" value="<?php echo esc_attr($user_meta['house_area'][0] ?? ''); ?>"></label>
                        <label>Gali/Sector: <input type="text" name="gali_sector" value="<?php echo esc_attr($user_meta['gali_sector'][0] ?? ''); ?>"></label>
                        <label>City: <input type="text" name="city" value="<?php echo esc_attr($user_meta['city'][0] ?? ''); ?>"></label>
                        <label>Pin Code: <input type="text" name="pin_code" value="<?php echo esc_attr($user_meta['pin_code'][0] ?? ''); ?>"></label>
                    </div>

                   <!-- Specializations Tab -->
					<div class="dashboard-tab-content" id="tab-specializations">
						<h3>Select Specialization</h3>
						<?php
						// Fetch all product categories (including subcategories)
						$terms = get_terms([
							'taxonomy'   => 'product_cat',  // Fetch product categories
							'hide_empty' => false,          // Show even empty categories
							 'parent'     => 0, 
						]);

						// Get the selected category from user meta
						$selected_cat = get_user_meta($user_id, 'selected_category_id', true);

						// Check if we have terms (categories) available
						if (!empty($terms) && !is_wp_error($terms)) {
							foreach ($terms as $term) {
								// Determine if this category is selected
								$checked = checked($selected_cat, $term->term_id, false);
								?>
								<label>
									<input type="radio" name="selected_category_id" value="<?php echo esc_attr($term->term_id); ?>" <?php echo $checked; ?>>
									<?php echo esc_html($term->name); ?>
								</label><br>
								<?php
							}
						} else {
							echo '<p>No specializations found.</p>';
						}
						?>
					</div>


                    <!-- Orders Tab -->
    <!-- Orders Tab -->
           <div class="dashboard-tab-content" id="tab-orders">
                    <h3>Your Orders</h3>
                    <div class="order-tabs">
                        <div class="tab-link" data-tab="today-orders">Today Orders</div>
                        <div class="tab-link" data-tab="order-history">Orders History</div>
                        <div class="tab-link" data-tab="future-orders">Future Orders</div>
                    </div>

                    <div class="order-tab-content" id="today-orders">
            <h4>Today's Orders</h4>
            <?php
            global $wpdb;

            // Get the current user's ID
            $user_id = get_current_user_id();

            if ($user_id == 0) {
                echo '<p>You must be logged in to view your orders.</p>';
                return;
            }

            // Get the staff_id from the bookly_staff table
            $staff_id = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}bookly_staff WHERE wp_user_id = %d",
                    $user_id
                )
            );

            // Get today's date
            $today = date('Y-m-d');

            // Fetch appointments for today
            $today_appointments = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}bookly_appointments WHERE DATE(start_date) = %s AND staff_id = %d",
                    $today, $staff_id
                )
            );

            if ($today_appointments) {
                echo '<ul>';
                foreach ($today_appointments as $appointment) {
                $datetime = new DateTime($appointment->start_date);
                        $date = $datetime->format('Y-m-d');
                        $time = $datetime->format('H:i:s');

                        echo "<li>
                            <strong>Appointment #{$appointment->id}</strong><br>
                            Date: $date<br>
                            Time: $time<br>
                        </li><hr>";
                    }
                    echo '</ul>';
                } else {
                echo '<p>No appointments scheduled for today.</p>';
            }
            ?>
        </div>


                    <div class="order-tab-content" id="order-history">
                        <h4>Orders History</h4>
                        <?php
                        global $wpdb;

                        // Get current user ID
                        $user_id = get_current_user_id();

                        // Get staff ID from Bookly
                        $staff_id = $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT id FROM {$wpdb->prefix}bookly_staff WHERE wp_user_id = %d",
                                $user_id
                            )
                        );
                        $today = date('Y-m-d');

                            // Fetch appointments for today
                            $history_appointments = $wpdb->get_results(
                                $wpdb->prepare(
                                    "SELECT * FROM {$wpdb->prefix}bookly_appointments WHERE DATE(start_date) < %s AND staff_id = %d",
                                    $today, $staff_id
                                )
                            );
        //echo" <pre>"; print_r($history_appointments);
                        if ($history_appointments) {
                            echo '<ul>';
                            foreach ($history_appointments as $appointment) {
                            $datetime = new DateTime($appointment->start_date);
                                    $date = $datetime->format('Y-m-d');
                                    $time = $datetime->format('H:i:s');

                                    echo "<li>
                                        <strong>Appointment #{$appointment->id}</strong><br>
                                        Date: $date<br>
                                        Time: $time<br>
                                    </li><hr>";
                                }
                                echo '</ul>';
                            } else {
                            echo '<p>No appointments scheduled for today.</p>';
                        }
                        ?>
                    </div>


                    <div class="order-tab-content" id="future-orders">
                        <h4>Future Orders</h4>
                        <?php
                        // Fetch future appointments for the current user
                        $future_appointments = $wpdb->get_results(
                            $wpdb->prepare(
                                    "SELECT * FROM {$wpdb->prefix}bookly_appointments WHERE DATE(start_date) > %s AND staff_id = %d",
                                    $today, $staff_id
                                )
                            );
            

                        if ($future_appointments) {
                            echo '<ul>';
                            foreach ($future_appointments as $appointment) {
                                $datetime = new DateTime($appointment->start_date);
                                $date = $datetime->format('Y-m-d');
                                $time = $datetime->format('H:i:s');

                                echo "<li>
                                    <strong>Appointment #{$appointment->id}</strong><br>
                                    Date: $date<br>
                                    Time: $time<br>
                                </li><hr>";
                            }
                            echo '</ul>';
                        }else {
                            echo '<p>No future appointments scheduled.</p>';
                        }
                        ?>
                    </div>
                </div>
  
        <!-- JavaScript to handle tab switching -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabLinks = document.querySelectorAll('.tab-link');
                const tabContents = document.querySelectorAll('.order-tab-content');

                // Function to show the selected tab and hide others
                function showTab(tabId) {
                    // Hide all tab contents
                    tabContents.forEach(content => {
                        content.style.display = 'none';
                    });

                    // Show the selected tab content
                    const activeTab = document.getElementById(tabId);
                    if (activeTab) {
                        activeTab.style.display = 'block';
                    }
                }

                // Add click event listeners to each tab
                tabLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        const tabId = link.getAttribute('data-tab');
                        showTab(tabId);

                        // Highlight the active tab (optional)
                        tabLinks.forEach(l => l.classList.remove('active'));
                        link.classList.add('active');
                    });
                });

                // Initialize by showing the first tab
                showTab('today-orders');
            });
        </script>

                    <input type="submit" class="btn btnTheme" name="update_profile" value="Save Changes">
                </form>
            </div>
        </div>
    </section>

    <script>
        const tabs = document.querySelectorAll('.dashboard-tabs div');
        const contents = document.querySelectorAll('.dashboard-tab-content');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                contents.forEach(c => c.classList.remove('active'));
                document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
            });
        });
        tabs[0].click();
    </script>
    <?php
    return ob_get_clean();
}

// Handle file upload logic
function upload_file($field_name) {
    if (!empty($_FILES[$field_name]['name']) && !empty($_FILES[$field_name]['tmp_name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $upload = media_handle_upload($field_name, 0);
        if (!is_wp_error($upload)) {
            return wp_get_attachment_url($upload);
        } else {
            return '';
        }
    }
    return '';
}



add_action('template_redirect', 'redirect_user_from_my_account');
function redirect_user_from_my_account() {
    if (is_user_logged_in() && is_account_page()) {
        $user = wp_get_current_user();
        $roles = (array) $user->roles;

        if (in_array('services_provider', $roles)) {
            wp_redirect(home_url('/service-provider-dashboard/'));
            exit;
        }

        if (in_array('administrator', $roles)) {
            wp_redirect(admin_url());
            exit;
        }
    }
}


// Hook to add a custom tab in the Dokan Dashboard
add_filter( 'dokan_get_dashboard_nav', 'add_custom_dashboard_tab', 99, 1 );

function add_custom_dashboard_tab( $nav ) {
    $nav['custom-orders'] = array(
        'title' => __( 'Custom Orders', 'text-domain' ),
        'icon'  => 'fa fa-cogs', // You can use any icon from FontAwesome
        'url'   => dokan_get_option( 'dashboard_url' ) . '/custom-orders', // Custom URL for your tab
    );
    
    return $nav;
}

// Shortcode to display custom order tabs (Today, History, Future orders)
// Shortcode to display custom order tabs (Today, History, Future orders)
add_shortcode( 'custom_order_tabs', 'display_order_tabs' );

function display_order_tabs() {
    // Get the current logged-in user
    $user_id = get_current_user_id();
    
    if ( !$user_id ) {
        return '<p>You must be logged in to view your orders.</p>';
    }

    // Get WooCommerce orders for today, past, and future
    $today_orders = wc_get_orders( array(
        'customer_id' => $user_id,
        'date_created' => '>' . date('Y-m-d 00:00:00'),
        'status' => 'completed', // Adjust this if you want other statuses
    ) );

    $history_orders = wc_get_orders( array(
        'customer_id' => $user_id,
        'date_created' => '<' . date('Y-m-d 00:00:00'),
    ) );

    $future_orders = wc_get_orders( array(
        'customer_id' => $user_id,
        'date_created' => '>' . date('Y-m-d 23:59:59'),
    ) );
    
    // Get Bookly appointments and categorize based on date
    global $wpdb;
    
    // Get all appointments for the current user
    $appointments = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM {$wpdb->prefix}bookly_appointments WHERE customer_id = %d", $user_id)
    );

    $today_appointments = [];
    $history_appointments = [];
    $future_appointments = [];

    // Categorize appointments based on the start date
    foreach ( $appointments as $appointment ) {
        $appointment_date = strtotime($appointment->appointment_date);
        $today_date = strtotime(date('Y-m-d'));

        if ( $appointment_date == $today_date ) {
            $today_appointments[] = $appointment; // Today’s appointment
        } elseif ( $appointment_date > $today_date ) {
            $future_appointments[] = $appointment; // Future appointment
        } else {
            $history_appointments[] = $appointment; // Past appointment
        }
    }

    ob_start();
    ?>
	
	
<section class="myOrderMain">
	<div class="tabs">
		<button class="tab-button" onclick="showTab('today')">Today's Orders</button>
		<button class="tab-button" onclick="showTab('history')">Order History</button>
		<button class="tab-button" onclick="showTab('future')">Future Orders</button>
	</div>

	<div id="today" class="tab-content">
		<h2>Today's Orders</h2>
		<?php
		global $wpdb;
		$current_user_id = get_current_user_id();

		// Step 1: Get Bookly customer ID
		$customer_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}bookly_customers WHERE wp_user_id = %d",
				$current_user_id
			)
		);

		if ( $customer_data ) {
			$customer_id = $customer_data->id;

			// Step 2: Get today's date
			$today = date('Y-m-d');

			// Step 3: Get today's appointments for that customer
			$appointments = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT a.id, a.start_date 
					 FROM {$wpdb->prefix}bookly_appointments a
					 INNER JOIN {$wpdb->prefix}bookly_customer_appointments ca ON ca.appointment_id = a.id
					 WHERE ca.customer_id = %d",
					$customer_id
				)
			);

			$today_orders = [];

			foreach ( $appointments as $appt ) {
				$appt_date = date('Y-m-d', strtotime($appt->start_date));
				if ( $appt_date === $today ) {
					$today_orders[] = $appt;
				}
			}

			if ( $today_orders ) {
				foreach ( $today_orders as $order ) {
					echo '<p>Appointment ID: ' . esc_html($order->id) . ' | Date: ' . esc_html($order->start_date) . '</p>';
				}
			} else {
				echo '<p>No orders for today.</p>';
			}

		} else {
			echo '<p>No Bookly customer found for this user.</p>';
		}
		?>
	</div>


	<div id="history" class="tab-content" style="display:none;">
		<h2>Order History</h2>
		<?php if ( $history_orders ) : ?>
			<?php foreach ( $history_orders as $order ) : ?>
				<p>Order #<?php echo $order->get_id(); ?> - Status: <?php echo $order->get_status(); ?></p>
			<?php endforeach; ?>
		<?php else : ?>
			<p>No past orders.</p>
		<?php endif; ?>
	</div>

   <div id="future" class="tab-content" style="display: none;">
	<h2>Future Orders</h2>
	<?php
	global $wpdb;
	$current_user_id = get_current_user_id();

	// Step 1: Get Bookly customer ID
	$customer_data = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}bookly_customers WHERE wp_user_id = %d",
			$current_user_id
		)
	);

	if ( $customer_data ) {
		$customer_id = $customer_data->id;

		// Step 2: Get today's date
		$today = date('Y-m-d');

		// Step 3: Get appointments for that customer
		$appointments = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.id, a.start_date 
				 FROM {$wpdb->prefix}bookly_appointments a
				 INNER JOIN {$wpdb->prefix}bookly_customer_appointments ca ON ca.appointment_id = a.id
				 WHERE ca.customer_id = %d",
				$customer_id
			)
		);

		$future_orders = [];

		foreach ( $appointments as $appt ) {
			$appt_date = date('Y-m-d', strtotime($appt->start_date));
			if ( $appt_date > $today ) {
				$future_orders[] = $appt;
			}
		}

		if ( $future_orders ) {
			foreach ( $future_orders as $order ) {
				echo '<p>Appointment ID: ' . esc_html($order->id) . ' - Date: ' . esc_html($order->start_date) . '</p>';
			}
		} else {
			echo '<p>No future orders.</p>';
		}

	} else {
		echo '<p>No Bookly customer found for this user.</p>';
	}
	?>
</div>

</section>

    <script>
        function showTab(tabName) {
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.style.display = 'none');
            document.getElementById(tabName).style.display = 'block';
        }
    </script>

    <?php
    return ob_get_clean();
}

// Add some custom CSS for the tabs
function custom_order_tabs_styles() {
    ?>
    <style>
        .tabs {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }

        .tab-button {
            padding: 10px 20px;
            cursor: pointer;
            background-color: #f0f0f0;
            border: none;
            border-radius: 5px;
        }

        .tab-button:hover {
            background-color: #ddd;
        }

        .tab-content {
            display: none;
        }
    </style>
    <?php
}
add_action( 'wp_head', 'custom_order_tabs_styles' );




function custom_change_password_form() {
    if (!is_user_logged_in()) {
        return '<p>You need to <a href="' . wp_login_url() . '">log in</a> to change your password.</p>';
    }

    $output = '';
    
    if (isset($_POST['custom_password_nonce']) && wp_verify_nonce($_POST['custom_password_nonce'], 'custom_password_action')) {
        $user_id = get_current_user_id();
       // echo "fsdfds<pre>"; print_r($user_id);die;
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        $user = wp_get_current_user();

        if (!wp_check_password($current_password, $user->data->user_pass, $user->ID)) {
            $output .= '<p style="color:red;">Current password is incorrect.</p>';
        } elseif ($new_password !== $confirm_password) {
            $output .= '<p style="color:red;">New passwords do not match.</p>';
        } else {
            wp_set_password($new_password, $user_id);
            wp_logout(); // Log out after password change for security
            $output  = '<p style="color:green;">Password changed successfully! Please <a href="' . wp_login_url( home_url('/login') ) . '">Login</a> again.</p>';
            return $output;

        }
    }

    $output .= '
    <form method="post">
        <p><label>Current Password<br><input type="password" name="current_password" required></label></p>
        <p><label>New Password<br><input type="password" name="new_password" required></label></p>
        <p><label>Confirm New Password<br><input type="password" name="confirm_password" required></label></p>
        ' . wp_nonce_field('custom_password_action', 'custom_password_nonce', true, false) . '
        <p><input type="submit" value="Change Password"></p>
    </form>
    ';

    return $output;
}
add_shortcode('change_password_form', 'custom_change_password_form');


// Function to schedule the push notification after user registration
function schedule_push_notification_on_user_register($user_id) {
    // Check if the user was registered via the app
    $was_registered_via_app = get_user_meta($user_id, 'user_registered_via_app', true);

    // If the user was registered via the app, do not schedule the notification again
    if ($was_registered_via_app) {
        error_log('User ID ' . $user_id . ' was registered via the app. Skipping push notification scheduling.');
        return; // Skip scheduling
    }

    // Otherwise, schedule the task to run after a short delay (e.g., 5 seconds)
    wp_schedule_single_event(time() + 5, 'check_last_user_service_provider_form_and_send_notification');

    // Log to verify that the event is scheduled
    error_log('Scheduled push notification for user ID ' . $user_id . ' after 5 seconds.');
}

// Hook into user registration to schedule the push notification
add_action('user_register', 'schedule_push_notification_on_user_register', 10, 1);

// Function to check the last user's service provider form and send notification
function check_last_user_service_provider_form_and_send_notification() {
    // Log to see if this function is being triggered
    error_log('Triggered check_last_user_service_provider_form_and_send_notification event.');

    // Retrieve the most recently created user
    $args = array(
        'number' => 1,          // Limit to the most recent user
        'orderby' => 'ID',      // Order by user ID (ascending or descending)
        'order' => 'DESC'       // DESC to get the most recently created user
    );

    $users = get_users($args);

    // Ensure we have at least one user
    if (empty($users)) {
        error_log('No users found, exiting.');
        return;  // No users found, exit early
    }

    // Get the last user (most recent)
    $last_user = $users[0];

    // Log the user ID to check which user we are working with
    error_log('Last user ID: ' . $last_user->ID);

    // Get the 'service_provider_form' from user meta
    $service_provider_form = get_user_meta($last_user->ID, 'service_provider_form', true);

    // Log the value of 'service_provider_form' for debugging
    error_log('Service provider form value: ' . $service_provider_form);

    // Check if 'service_provider_form' exists and has the expected value
    if ($service_provider_form) {
        // Log that the form value is set correctly
        error_log('Service provider form is set to: ' . $service_provider_form);

        // Retrieve all admins
        $args_admins = array(
            'role' => 'administrator',
            'fields' => array('ID', 'user_email') // Get user ID and email
        );

        $admins = get_users($args_admins);

        // Loop through all admins
        foreach ($admins as $admin) {
            // Get the FCM tokens for the admin (it could be an array)
            $fcm_tokens = get_user_meta($admin->ID, 'device_login_tokens', true);

            // Log the FCM tokens for debugging
            error_log('Admin FCM tokens: ' . print_r($fcm_tokens, true));

            // Check if FCM tokens exist and are an array
            if (is_array($fcm_tokens) && !empty($fcm_tokens)) {
                // Instantiate the HelperService class
                $helperService = new RestMyApis\Services\HelperService();

                // Prepare the custom data for the notification
                $customData = [
                    'customData' => 'value',  // Default custom data
                    'type' => 'service_provider',  // Example static type
                    'url' => '/admin/service_provider_approval', // URL to direct admins to
                ];

                // Loop through each FCM token and send the push notification
                foreach ($fcm_tokens as $fcm_token) {
                    if (!empty($fcm_token)) {
                        try {
                            // Send the push notification to each admin's FCM token with custom data
                            $helperService->sendPushNotification(
                                [$fcm_token], 
                                "A new service provider has filled the service provider form and is waiting for your approval.", 
                                "Please review the service provider's form.", 
                                $customData
                            );

                            // Log the push notification sent
                            error_log('Push notification sent to admin ID: ' . $admin->ID . ' with FCM token: ' . $fcm_token);
                        } catch (Exception $e) {
                            // Log any error if sending the notification fails
                            error_log('Failed to send push notification to admin ID: ' . $admin->ID . '. Error: ' . $e->getMessage());
                        }
                    }
                }
            } else {
                // Log if no FCM token exists or the token is not an array
                error_log('No valid FCM tokens found for admin ID: ' . $admin->ID);
            }
        }
    } else {
        error_log('Service provider form is not set or has an unexpected value.');
    }
}

// Hook the check function to the action when it's scheduled
add_action('check_last_user_service_provider_form_and_send_notification', 'check_last_user_service_provider_form_and_send_notification', 10, 0);

// Ensure wp-cron works, especially if you're testing the cron job manually.
function trigger_wp_cron() {
    // Uncomment the next line for testing purposes
    // wp_remote_get( home_url( '/wp-cron.php?doing_wp_cron' ) );
}

// Hook to make sure wp-cron runs properly.
add_action('init', 'trigger_wp_cron');







add_action('updated_user_meta', 'notify_on_status_change', 10, 4);
function notify_on_status_change($meta_id, $user_id, $meta_key, $meta_value) {
    if ($meta_key === 'ur_user_status') {
        // Get the FCM tokens (should be a PHP array)
        $fcm_tokens = get_user_meta($user_id, 'device_login_tokens', true);
		error_log("FCM tokens for user ID $user_id: " . print_r($fcm_tokens, true));
		

        // Ensure we have a valid array
        if (empty($fcm_tokens) || !is_array($fcm_tokens)) {
            error_log("No valid FCM tokens found for user ID $user_id");
            return;
        }

        // Instantiate helper service to send notifications
        $helperService = new RestMyApis\Services\HelperService();

        // Determine the message
        if ($meta_value == '1') {
            $message = "✅ Your service provider profile has been *approved*.";
            error_log("Approval notification ready for user ID $user_id");
        } elseif ($meta_value == '-1') {
            $message = "❌ Your service provider profile has been *denied*. Please contact support for more info.";
            error_log("Denial notification ready for user ID $user_id");
        } else {
            error_log("Invalid status value: $meta_value for user ID $user_id");
            return;
        }

        // Send push notification to each token
        foreach ($fcm_tokens as $token) {
            $token = trim($token); // clean just in case
            if (!empty($token)) {
                try {
                    $helperService->sendPushNotification([$token], $message);
                    error_log("Notification sent to user ID $user_id with FCM token $token");
                } catch (Exception $e) {
                    error_log("Failed to send notification to user ID $user_id. Error: " . $e->getMessage());
                }
            } else {
                error_log("Empty FCM token for user ID $user_id, skipping.");
            }
        }
    }
}


// [property_listing_form] shortcode for property submission by owner

// Register the shortcode
add_shortcode('property_listing_form', 'property_listing_form_shortcode');
function property_listing_form_shortcode() {
    // Check if the user is logged in
    if (!is_user_logged_in()) {
        return '<p>Please <a href="/login">login</a> to submit a property.</p>';
    }

    // Get the parent category for "To Let Service"
    $parent_cat = get_term_by('slug', 'to-let-services', 'product_cat');

    if (!$parent_cat) {
        return '<p>Error: Unable to find the property type category.</p>';
    }

    // Get property types (child terms) for "To Let Service"
    $property_type_terms = get_terms([
        'taxonomy' => 'product_cat',
        'parent' => $parent_cat->term_id,
        'hide_empty' => false,
    ]);

    // Start output buffering to capture the form HTML
    ob_start();
    ?>
    <div class="to_let_form">
	<?php if (isset($_GET['submitted']) && $_GET['submitted'] === 'true') {
			echo '<div class="alert alert-success">✅ Property submitted successfully and is pending approval.</div>';
		}
		?>
        <form id="property_form" method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('property_listing_form_action', 'property_listing_form_nonce'); ?>
            <h2 class="mb-3">Property Owner</h2>
            <div class="row">
                <!-- Hidden Usage Field -->
                <input type="hidden" name="usage" value="<?php echo esc_attr($parent_cat->term_id); ?>">

                <!-- Owner Info -->
              <div class="col-md-6">
					<div class="form-group mb-3">
					
						<label for="owner_name">Owner Name</label>
						<input type="text" class="form-control" name="owner_name" id="owner_name" placeholder="Only alphabetic characters"
       pattern="[A-Za-z\s]+" >

						<div id="owner_name_error" class="text-danger mb-1" style="display:none;"></div>
					</div>
				</div>

				<div class="col-md-6">
				<div class="form-group mb-3">
						<label for="contact">Contact Number</label>
						<input type="tel" 
							   class="form-control" 
							   name="contact" 
							   id="contact"
							   pattern="[0-9]{10}" 
							   title="Please enter exactly 10 digits (numbers only)"
							   oninput="this.value = this.value.replace(/[^0-9]/g, '')"
							   minlength="10"
							   maxlength="10"
							   placeholder="123456789"
							   required>
						<div id="contact_error" class="text-danger mb-1" style="display:none;"></div>
					</div>
				</div>

                <!-- Property Type -->
                <div class="col-md-12">
                    <div class="form-group mb-3">
                        <label for="property_type">Property Type</label>
                        <select class="form-control dynamic-sub-type" name="property_type" id="property_type" required>
                            <option value="">--Select--</option>
                            <?php foreach ($property_type_terms as $term): ?>
                                <option value="<?php echo esc_attr($term->term_id); ?>"><?php echo esc_html($term->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Dynamic Sub-Type (child categories) -->
              <div class="col-md-12" id="sub-type-container" style="display: flex; flex-direction: column; gap: 10px;">
					<!-- All dynamic child dropdowns will appear here -->
				</div>
			<div id="dynamic-filters-container" class="row mt-3"></div>

				
                <!-- Enhanced Location Selector -->
                <div class="col-md-12">
                    <div class="form-group mb-3">
                        <label for="property-location">Location</label>
                        <div class="location-selector">
                            <div class="location-dropdown">
                                <button type="button" class="location-dropbtn form-control text-left" onclick="toggleLocationDropdown()" style="display: flex; justify-content: space-between; align-items: center;">
                                    <span id="selected-location">Choose a location</span>
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                                <div id="locationDropdown" class="location-dropdown-content" style="display: none; position: absolute; background-color: white; width: 100%; max-height: 300px; overflow-y: auto; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 5px; z-index: 1000; margin-top: 5px; border: 1px solid #d0d0d0;">
                                    <div class="location-option" onclick="selectLocation('Chandigarh')" style="padding: 12px 15px; display: flex; align-items: center; cursor: pointer; transition: background-color 0.2s;">
                                        <i class="fas fa-city" style="margin-right: 10px; color: #3498db;"></i>
                                        <span>Chandigarh</span>
                                    </div>
                                    <div class="location-option" onclick="selectLocation('Mohali')" style="padding: 12px 15px; display: flex; align-items: center; cursor: pointer; transition: background-color 0.2s;">
                                        <i class="fas fa-city" style="margin-right: 10px; color: #3498db;"></i>
                                        <span>Mohali</span>
                                    </div>
                                    <div class="location-option" onclick="selectLocation('Panchkula')" style="padding: 12px 15px; display: flex; align-items: center; cursor: pointer; transition: background-color 0.2s;">
                                        <i class="fas fa-city" style="margin-right: 10px; color: #3498db;"></i>
                                        <span>Panchkula</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sector/Place Selection -->
                        <div id="sectorSelection" class="sector-selection" style="display: none; margin-top: 20px;">
                            <input type="text" class="form-control sector-search" placeholder="Search sectors..." oninput="filterSectors()">
                            <div class="sector-list" id="sectorList" style="max-height: 200px; overflow-y: auto; border: 1px solid #d0d0d0; border-radius: 5px; margin-top: 10px;"></div>
                            <div class="selected-location-display mt-3 p-3 bg-light" id="selectedLocationDisplay" style="border-left: 4px solid #3498db;"></div>
                            <input type="hidden" name="location" id="location_input" required>
                        </div>
                    </div>
                </div>

                <!-- Area (sq ft) 
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="area">Area (in sq ft)</label>
                        <input type="text" class="form-control" name="area" id="area" required>
                    </div>
                </div>-->

                <!-- Rent Price 
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="price">Rent Price (Rs.)</label>
                        <input type="number" class="form-control" name="price" id="price" required>
                    </div>
                </div>-->

                <!-- Furnishing Options -->  
			 <div class="col-md-4">
				<div class="form-group mb-3">
					<label for="full_address">Caretaker Available ? </label>
						<select class="form-control" name="caretaker" id="caretaker" >
                            <option value="">--Select--</option>
								<option value="NO">No</option>
								<option value="Yes">Yes</option>
                         </select>
				</div>
			</div>
			
			<div class="col-md-4 care_taker_sec d-none">
				<div class="form-group mb-3">
					<label for="full_address">Caretaker name </label>
						<input class="form-control" name="caretaker_name" id="caretaker_name" >
				</div>
			</div>
			<div class="col-md-4 care_taker_sec d-none">
				<div class="form-group mb-3">
					<label for="full_address">Caretaker contact </label>
					<input class="form-control" name="caretaker_phone" id="caretaker_phone" >
				</div>
			</div>
			<div class="clearfix"></div>
			
             <div class="col-md-6">
				<div class="form-group mb-3">
					
					<label for="full_address">Full Property Address</label>
					<textarea class="form-control" name="full_address" id="full_address" rows="3" placeholder="eg Sector 22"></textarea>
					<div id="address_error" class="text-danger mb-1" style="display:none;"></div>
				</div>
			</div>

                <!-- Upload Property Images -->
				<div class="col-md-12">
					<div class="form-group mb-3">
						<label for="property_images">Upload Property Images</label>
						<div class="image-upload-wrapper">
							<!-- Hidden file input -->
							<input id="property_images" class="d-none" type="file" name="property_images[]" accept=".jpg,.jpeg,.png" multiple>
							
							<!-- Custom upload button -->
							<button type="button" class="btn btn-primary mb-3" onclick="document.getElementById('property_images').click()">
								<i class="fas fa-plus"></i> Add Images
							</button>
							
							<!-- Preview area -->
							<div class="image-preview-container row"></div>
							
							<!-- Validation message -->
							<div id="image-error" class="text-danger mb-1" style="display:none;"></div>
							<div class="note">You can upload multiple images. Only JPG, JPEG, and PNG allowed (Max 200kb each).</div>
						</div>
					</div>
				</div>

                <!-- Description and Declaration -->
                <div class="col-md-12">
                    <div class="form-group mb-3">
                        <label for="description">Additional Description</label>
                        <textarea class="form-control" name="description" id="description" placeholder="Description" rows="4"></textarea>
                        <label style="display:block; margin-top: 15px;">
                            <input type="checkbox" name="declaration" required>
                            I confirm that all information is true and I agree to the <a href='/privacy-policy' target='_blank'>Privacy Policy</a> and <a href='/wp-content/uploads/2025/06/Chago_Terms_Conditions_Property_Owners-1.pdf' target='_blank'>Terms and Conditions</a>.
                        </label>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="col-md-12">
					<div class="form-group mb-3">
						<button type="submit" class="btn btn-primary" name="submit_property">Submit for Approval</button>
						<div id="form_error" class="text-danger mt-2 fw-bold" style="display:none;"></div>
					</div>
				</div>
            </div> <!-- End of .row -->

            <!-- Success message here -->
		<?php
			if (!session_id()) {
				session_start(); // ensure session available
			}

			// Check if session message is set
			if (!empty($_SESSION['property_submission_success'])) {
				echo '<div id="success-message" class="alert alert-success">✅ Property submitted successfully and is pending approval.</div>';
				unset($_SESSION['property_submission_success']);
			}

			if (!empty($_SESSION['property_submission_error'])) {
				echo '<div id="error-message" class="alert alert-danger">❌ ' . esc_html($_SESSION['property_submission_error']) . '</div>';
				unset($_SESSION['property_submission_error']);
			}
		?>
        </form>
    </div>

    <!-- JavaScript for dynamic sub-types -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
	jQuery(document).on("change", "#caretaker", function() {
		if(jQuery(this).val() == 'Yes'){
			jQuery(".care_taker_sec").removeClass('d-none');
		}else{
			jQuery(".care_taker_sec").addClass('d-none');
		}
	});
	document.getElementById('property_images').addEventListener('change', function(e) {
    const container = document.querySelector('.image-preview-container');
    const errorElement = document.getElementById('image-error');
    const files = e.target.files;
    
    // Clear previous error
    errorElement.style.display = 'none';
    
    // Validate files
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        
        if (!validTypes.includes(file.type)) {
            errorElement.textContent = 'Only JPG, JPEG, and PNG files are allowed';
            errorElement.style.display = 'block';
            return;
        }
        
	if (file.size > 200 * 1024) { // 200KB
		errorElement.textContent = 'File size should not exceed 200KB';
		errorElement.style.display = 'block';
		return;
	}

    }
    
    // Create previews
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();
        
        reader.onload = function(event) {
            const previewItem = document.createElement('div');
            previewItem.className = 'image-preview-item col-md-2';
            
            previewItem.innerHTML = `
                <img src="${event.target.result}" alt="Preview">
                <button type="button" class="remove-image-btn" data-index="${i}">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            container.appendChild(previewItem);
            
            // Add remove functionality
            previewItem.querySelector('.remove-image-btn').addEventListener('click', function() {
                removeImageFromList(i);
                previewItem.remove();
            });
        };
        
        reader.readAsDataURL(file);
    }
});

function removeImageFromList(index) {
    const input = document.getElementById('property_images');
    const files = Array.from(input.files);
    files.splice(index, 1);
    
    // Create new DataTransfer and update files
    const dataTransfer = new DataTransfer();
    files.forEach(file => dataTransfer.items.add(file));
    input.files = dataTransfer.files;
}
	
	   $(document).ready(function() {
        // Hide success message after 2 seconds
        if ($('.alert-success').length) {
            setTimeout(function() {
                $('.alert-success').fadeOut();
            }, 2000); // 2 seconds
        }
        
        // Hide error message after 3 seconds
        if ($('#error-message').length) {
            setTimeout(function() {
                $('#error-message').fadeOut();
            }, 3000); // 3 seconds
        }
    });
	
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("property_form");
    form.addEventListener("submit", function (e) {
        let hasError = false;

        // Error display container
        const formError = document.getElementById("form_error");
        formError.style.display = "none";
        formError.textContent = "";

        // Validate: Owner Name
        const owner = document.getElementById("owner_name");
        const ownerError = document.getElementById("owner_name_error");
        if (!owner.value.trim()) {
            ownerError.textContent = "Owner name is required.";
            ownerError.style.display = "block";
            hasError = true;
        } else {
            ownerError.style.display = "none";
        }

        // Validate: Contact
        const contact = document.getElementById("contact");
        const contactError = document.getElementById("contact_error");
        if (!contact.value.trim()) {
            contactError.textContent = "Contact number is required.";
            contactError.style.display = "block";
            hasError = true;
        } else {
            contactError.style.display = "none";
        }

        // Validate: Address
        const address = document.getElementById("full_address");
        const addressError = document.getElementById("address_error");
        if (!address.value.trim()) {
            addressError.textContent = "Address is required.";
            addressError.style.display = "block";
            hasError = true;
        } else {
            addressError.style.display = "none";
        }

        // Show form-level error near button if any input fails
        if (hasError) {
            e.preventDefault();
            formError.textContent = "Please fill all required fields correctly.";
            formError.style.display = "block";
        }
    });
});
	
document.addEventListener("DOMContentLoaded", function () {
    const mainTypeSelect = document.getElementById('property_type');

    if (mainTypeSelect) {
        mainTypeSelect.addEventListener('change', function () {
            if (this.value) {
                loadChildrenSelect(this.value);
            } else {
                document.getElementById('sub-type-container').innerHTML = '';
                document.getElementById('dynamic-filters-container').innerHTML = ''; // clear filters
            }
        });
    }

    // Listen for changes in sub_type_level_1 (second level)
    document.addEventListener('change', function (e) {
		
        if (e.target.classList.contains('dynamic-sub-type')) {
			//alert("gfgfd");
            const selectedSubType = e.target.value;
            showFiltersBySubType(selectedSubType);
        }
    });

    function showFiltersBySubType(value) {
		//alert(value);
        const container = document.getElementById('dynamic-filters-container');
        container.innerHTML = ''; // Clear previous filters

        let html = '';

       switch (value.toLowerCase()) {
			
			case '101':
				html = `<!-- Flat Filters -->
						${flatFilters()}
					`;
				break;

            case '163':
			case '165':
			case '166':
			case '164':
			case '162':
                html = commercialRetailShopFilters();
                break;
            case '167':
			case '168':
			case '169':
			case '170':
                html = warehouseFilters();
                break;
            case '159':
			case '157':
			case '160':
			case '161':
			case '158':
                html = officeFilters();
                break;
            case '102':
                html = roomFilters();
                break;
            case '100':
                html = pgFilters();
                break;
            case '153':
                html = houseFilters();
                break;
            default:
                html = '';
        }

        container.innerHTML = html;
    }

    // Filter Template Functions
    function flatFilters() {
        return `
        <div class="col-md-3 filter-group">
        <label for="bhk">BHK</label>
        <select class="form-control" name="bhk" id="bhk">
            <option value="">Select</option>
            <option value="1BHK">1BHK</option>
            <option value="2BHK">2BHK</option>
            <option value="3BHK">3BHK</option>
            <option value="4BHK">4BHK</option>
            <option value="5BHK+">5BHK+</option>
        </select>
    </div>

    <!-- Budget Filter -->
	<div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>


    <!-- Furnishing Filter -->
    <div class="col-md-3 filter-group">
        <label for="furnishing">Furnishing</label>
        <select class="form-control" name="furnishing" id="furnishing">
            <option value="">Select</option>
            <option value="Furnished">Furnished</option>
            <option value="Semi-Furnished">Semi-Furnished</option>
            <option value="Unfurnished">Unfurnished</option>
        </select>
    </div>

    <!-- Floor Filter -->
    <div class="col-md-3 filter-group">
        <label for="floor">Floor</label>
        <select class="form-control" name="floor" id="floor">
            <option value="">Select</option>
            <option value="Ground Floor">Ground Floor</option>
            <option value="1st Floor">1st Floor</option>
            <option value="2nd Floor">2nd Floor</option>
            <option value="3rd Floor">3rd Floor</option>
            <option value="4th Floor+">4th Floor+</option>
        </select>
    </div>
`;
    }

   function commercialRetailShopFilters() {
    return `
    <div class="col-md-3">
    <label for="area">Area (sqft)</label>
    <select class="form-control" name="area" id="area">
        <option value="">Select</option>
        <option value="<200">&lt;200</option>
        <option value="200-500">200-500</option>
        <option value="500-1000">500-1000</option>
        <option value="1000-2000">1000-2000</option>
        <option value="2000+">2000+</option>
    </select>
</div>
<div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>


<div class="col-md-3">
    <label for="footfall">Footfall</label>
    <select class="form-control" name="footfall" id="footfall">
        <option value="">Select</option>
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
    </select>
</div>

<div class="col-md-3">
    <label for="visibility">Visibility</label>
    <select class="form-control" name="visibility" id="visibility">
        <option value="">Select</option>
        <option value="Main Road">Main Road</option>
        <option value="Side Road">Side Road</option>
        <option value="Inside Market">Inside Market</option>
    </select>
</div>

    `;
}


    function warehouseFilters() {
    return `
    <div class="col-md-3">
        <label for="area">Area (sqft)</label>
        <select class="form-control" name="area" id="area">
            <option value="">Select</option>
            <option value="<2000">&lt;2000</option>
            <option value="2000-5000">2000-5000</option>
            <option value="5000-10000">5000-10000</option>
            <option value="10000-20000">10000-20000</option>
            <option value="20000+">20000+</option>
        </select>
    </div>
   <div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>
    <div class="col-md-3">
        <label for="ceilingHeight">Ceiling Height</label>
        <select class="form-control" name="ceilingHeight" id="ceilingHeight">
            <option value="">Select</option>
            <option value="<10ft">&lt;10ft</option>
            <option value="10-15ft">10-15ft</option>
            <option value="15-20ft">15-20ft</option>
            <option value="20ft+">20ft+</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="loadingFacilities">Loading Facilities</label>
        <select class="form-control" name="loadingFacilities" id="loadingFacilities">
            <option value="">Select</option>
            <option value="Dock">Dock</option>
            <option value="Ramp">Ramp</option>
            <option value="Crane">Crane</option>
        </select>
    </div>
    `;
}


    function officeFilters() {
    return `
    <div class="col-md-3">
    <label for="area">Area (sqft)</label>
    <select class="form-control" name="area" id="area">
        <option value="">Select</option>
        <option value="<500">&lt;500</option>
        <option value="500-1000">500-1000</option>
        <option value="1000-2000">1000-2000</option>
        <option value="2000-5000">2000-5000</option>
        <option value="5000+">5000+</option>
    </select>
</div>

<div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>

<div class="col-md-3">
    <label for="lease_type">Lease Type</label>
    <select class="form-control" name="lease_type" id="lease_type">
        <option value="">Select</option>
        <option value="Monthly">Monthly</option>
        <option value="Quarterly">Quarterly</option>
        <option value="Yearly">Yearly</option>
    </select>
</div>

<div class="col-md-3">
    <label>Facilities</label>
    <div class="form-control" style="height: auto; padding: 15px;">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityParking" value="Parking">
            <label class="form-check-label" for="amenityParking">Parking</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityAC" value="AC">
            <label class="form-check-label" for="amenityAC">AC</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityLift" value="Lift">
            <label class="form-check-label" for="amenityLift">Lift</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenitySecurity" value="Security">
            <label class="form-check-label" for="amenitySecurity">Security</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityPantry" value="Pantry">
            <label class="form-check-label" for="amenityPantry">Pantry</label>
        </div>
		<div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityConferenceHall" value="Conference Hall">
            <label class="form-check-label" for="amenityConferenceHall">Conference Hall</label>
        </div>
    </div>
</div>
<div class="col-md-3">
    <label>Cabins</label>
    <select name="cabins"  class="form-control" >
        <option value="">Select Cabins</option>
        <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="5">5</option>
        <option value="7">7</option>
        <option value="10+">10+</option>
    </select>
</div>
<div class="col-md-3">
    <label>Open Space Option</label>
    <select name="open_space_option" class="form-control">
        <option value="">Select Open Space Option</option>
        <option value="Standard Partitioned Space">Standard Partitioned Space</option>
        <option value="Open Workspace">Open Workspace</option>
        <option value="Bare Shell(Full Floor, No Setup)">Bare Shell(Full Floor, No Setup)</option>
    </select>
</div>
<div class="col-md-3">
    <label>Prefered Floor</label>
    <select name="prefered_floor" class="form-control">
        <option value="">Select Prefered Floor</option>
        <option value="Ground Floor">Ground Floor</option>
        <option value="First Floor">First Floor</option>
        <option value="Second Floor">Second Floor</option>
        <option value="3RD Floor">3RD Floor</option>
        <option value="4TH Floor">4TH Floor</option>
        <option value="5+">5+</option>
    </select>
</div>
<div class="col-md-3">
    <label>Seating Capacity</label>
    <select name="seating_capacity" class="form-control">
        <option value="">Select Seating Capacity</option>
        <option value="0">0</option>
        <option value="1 - 5">1 - 5</option>
        <option value="6 - 10">6 - 10</option>
        <option value="11 - 20">11 - 20</option>
        <option value="20+">20+</option>
    </select>
</div>

    `;
}


    function roomFilters() {
    return `
      <div class="col-md-3">
        <label for="room-set">Room Set</label>
        <select class="form-control" name="room-set" id="room-set">
            <option value="">Select</option>
            <option value="1 Room Set">1 Room Set</option>
            <option value="2 Room Set">2 Room Set</option>
            <option value="3 Room Set">3 Room Set</option>
        </select>
    </div>
   <div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>
    <div class="col-md-3">
        <label for="furnishing">Furnishing</label>
        <select class="form-control" name="furnishing" id="furnishing">
            <option value="">Select</option>
            <option value="Furnished">Furnished</option>
            <option value="Semi-Furnished">Semi-Furnished</option>
            <option value="Unfurnished">Unfurnished</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="bathroom">Bathroom</label>
        <select class="form-control" name="bathroom" id="bathroom">
            <option value="">Select</option>
            <option value="Attached">Attached</option>
            <option value="Shared">Shared</option>
        </select>
    </div>
    `;
}


    function pgFilters() {
    return `
    <div class="col-md-3">
        <label for="sharing-type">Sharing Type</label>
        <select class="form-control" name="sharing-type" id="sharing-type">
            <option value="">Select</option>
            <option value="Single Sharing">Single Sharing</option>
            <option value="Double Sharing">Double Sharing</option>
            <option value="Triple Sharing">Triple Sharing</option>
            <option value="Dormitory">Dormitory</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="gender">Gender</label>
        <select class="form-control" name="gender" id="gender">
            <option value="">Select</option>
            <option value="Boys">Boys</option>
            <option value="Girls">Girls</option>
            <option value="Unisex">Unisex</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="food-included">Food Included</label>
        <select class="form-control" name="food-included" id="food-included">
            <option value="">Select</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
        </select>
    </div>
   <div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>
    <div class="col-md-3">
    <label>Facilities</label>
    <div class="form-control" style="height: auto; padding: 15px;">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityAC" value="AC">
            <label class="form-check-label" for="amenityAC">AC</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityWiFi" value="WiFi">
            <label class="form-check-label" for="amenityWiFi">WiFi</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityLaundry" value="Laundry">
            <label class="form-check-label" for="amenityLaundry">Laundry</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="amenities[]" id="amenityCleaning" value="Cleaning">
            <label class="form-check-label" for="amenityCleaning">Cleaning</label>
        </div>
    </div>
</div>
    `;
}


   function houseFilters() {
    return `
    <div class="col-md-3">
        <label for="house-area">Area (sqft)</label>
        <select class="form-control" name="house-area" id="house-area">
            <option value="">Select</option>
            <option value="500-1000">500-1000</option>
            <option value="1000-1500">1000-1500</option>
            <option value="1500-2000">1500-2000</option>
            <option value="2000-2500">2000-2500</option>
            <option value="2500+">2500+</option>
        </select>
    </div>
    <div class="col-md-3 filter-group">
    <label for="budget">Budget</label>
    <input type="text" class="form-control" name="price" id="budget" placeholder="e.g. ₹10K - ₹15K">
</div>
    <div class="col-md-3">
        <label for="house-furnishing">Furnishing</label>
        <select class="form-control" name="house-furnishing" id="house-furnishing">
            <option value="">Select</option>
            <option value="Furnished">Furnished</option>
            <option value="Semi-Furnished">Semi-Furnished</option>
            <option value="Unfurnished">Unfurnished</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="house-parking">Parking</label>
        <select class="form-control" name="house-parking" id="house-parking">
            <option value="">Select</option>
            <option value="1 Car">1 Car</option>
            <option value="2 Cars">2 Cars</option>
            <option value="3+ Cars">3+ Cars</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="house-bedroom">Bedrooms</label>
        <select class="form-control" name="house-bedroom" id="house-bedroom">
            <option value="">Select</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5+">5+</option>
        </select>
    </div>
    `;
}

});
    document.addEventListener("DOMContentLoaded", function () {


	  document.getElementById('property_type')?.addEventListener('change', function () {
        if (this.value) {
            loadChildrenSelect(this.value, 1);
        } else {
            document.getElementById('sub-type-container').innerHTML = '';
        }
    });
});
         function loadChildrenSelect(parentId, level = 1) {
    fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=get_property_sub_types&parent_id=' + parentId)
        .then(response => response.json())
        .then(data => {
            // Remove all dropdowns from current level and below to avoid duplicates
            document.querySelectorAll(`.dynamic-sub-type[data-level]`).forEach(el => {
                if (parseInt(el.dataset.level) >= level) {
                    el.parentElement.remove();
                }
            });

            if (data.length > 0) {
                const container = document.getElementById('sub-type-container');

                const wrapper = document.createElement('div');
                wrapper.className = 'form-group mb-3';

                const label = document.createElement('label');
                label.innerText = level === 1 ? 'Sub Type' : `Sub ${'Child '.repeat(level - 2)}Type`;

                const select = document.createElement('select');
                select.className = 'form-control dynamic-sub-type';
                select.name = `sub_type_level_${level}`;
                select.dataset.level = level;
                select.required = true;

                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.innerText = '--Select--';
                select.appendChild(defaultOption);

                data.forEach(term => {
                    const option = document.createElement('option');
                    option.value = term.term_id;
                    option.innerText = term.name;
                    select.appendChild(option);
                });

                wrapper.appendChild(label);
                wrapper.appendChild(select);
                container.appendChild(wrapper);

                // When this dropdown changes, load next level children
                select.addEventListener('change', function () {
                    if (this.value) {
                        loadChildrenSelect(this.value, level + 1);
                    } else {
                        // If nothing selected, remove all lower level selects
                        document.querySelectorAll(`.dynamic-sub-type[data-level]`).forEach(el => {
                            if (parseInt(el.dataset.level) > level) {
                                el.parentElement.remove();
                            }
                        });
                    }
                });
            }
        })
        .catch(err => console.error('Sub Type Load Error:', err));
}
	const mainTypeSelect = document.getElementById('property_type');
	if (mainTypeSelect) {
		mainTypeSelect.addEventListener('change', function () {
			if (this.value) {
				loadChildrenSelect(this.value, 1); // Start from level 1
			} else {
				document.getElementById('sub-type-container').innerHTML = '';  // Clear all sub-type dropdowns
			}
		});
	}


    // Location and sector data
   const locationData = {
    Chandigarh: [
        ...Array.from({ length: 56 }, (_, i) => `Sector ${i + 1}`),
        "Industrial Area Phase 1",
        "Industrial Area Phase 2",
        "Ram Darbar Industrial Estate",
        "Sector 17 Plaza",
        "Sector 22 Market",
        "Sector 19 Market",
        "Sector 26 Madhya Marg (restaurants, offices, bars)",
        "Sector 34 Commercial Belt (coaching, banks, hotels)",
        "Sector 35 & 36 Business Zone",
        "Sector 8 Inner Market",
        "Manimajra Furniture Market",
        "Modern Housing Complex, Manimajra",
        "Burail Market (Sector 45)",
        "Mauli Jagran Local Market",
        "Bapu Dham Market",
        "Daria Local Market",
        "Hallo Majra Market",
        "Elante Mall (Industrial Area Phase 1)",
        "DT Mall (IT Park, Manimajra)",
        "Centra Mall (Industrial Area Phase 1)",
        "TDI Mall (Sector 17)",
        "City Centre Mall (Sector 34)",
        "Piccadilly Square Mall (Sector 34)",
        "Fun Republic Mall, Manimajra",
        "Tribune Chowk",
        "Transport Area (Back Side Road belt)",
        "Kishangarh", "Dhanas", "Sarangpur", "Khuda Lahora", "Khuda Jassu",
        "Hallo Majra", "Manimajra", "Daria", "Maloya", "Dadu Majra",
        "Palsora", "Kansal", "Kaimbala", "Khuda Ali Sher", "Ram Darbar Colony",
        "Railway Colony", "Burail", "Mauli Jagran", "Raipur Kalan", "Raipur Khurd",
        "Behlana", "Makhan Majra", "Attawa", "Badheri", "Bapu Dham Colony", "Indira Colony"
    ],
    Mohali: [
        ...Array.from({ length: 12 }, (_, i) => `Phase ${i + 1}`),
        ...Array.from({ length: 23 }, (_, i) => `Sector ${60 + i}`),
        "Shahi Majra", "Balongi", "Kharar", "Sohana", "Matour", "Aero City",
        "Sector 54", "Sector 55", "Sector 56", "Sector 57", "Sector 58", "Sector 59",
        "Sector 83", "Sector 84", "Sector 85", "Sector 86", "Sector 87", "Sector 88",
        "Sector 89", "Sector 90", "Sector 91", "Sector 92", "Sector 93", "Sector 94",
        "Sector 95", "Sector 96", "Sector 97", "Sector 98", "Sector 99", "Sector 100",
        "Kumbra", "Mohali Village", "Manak Majra", "Madanpur", "Daun", "Desu Majra",
        "Jhungian", "Jagatpura", "Jhanjeri (student hub)", "IT City", "Sunny Enclave",
        "TDI City", "Sector 66-A", "Sector 82-A", "Sector 88-A", "Sector 115", "Sector 116",
        "Sector 117", "Sector 118", "Sector 119", "Sector 125", "Sector 126", "Sector 127", "Sector 128",
        "Sector 1 (New Chandigarh)", "Sector 2 (New Chandigarh)", "Sector 3 (New Chandigarh)",
        "Sector 4 (New Chandigarh)", "Sector 5 (New Chandigarh)", "Sector 6 (New Chandigarh)",
        "Omaxe New Chandigarh", "Eco City Phase 1", "Eco City Phase 2", "DLF Hyde Park",
        "Manohar Singh Palm Residency", "GMADA Urban Plots", "The MedCity",
        "New Chandigarh Extension (Mullanpur Garibdass)", "Ambika Florence Park",
        "Jubilee Golf Vista", "The Address by Unity Group"
    ],
    Panchkula: [
        ...Array.from({ length: 20 }, (_, i) => `Sector ${i + 1}`),
        "Sector 21", "Sector 22", "Sector 23", "Sector 24", "Sector 25", "Sector 26",
        "Sector 27", "Sector 28", "Sector 29", "Sector 30", "Sector 31", "Sector 12A",
        "MDC Sector 4", "MDC Sector 5", "Panchkula Extension (Sector 20–21 Side)",
        "Housing Board Colony", "Indira Awas Colony", "Ramgarh Colony", "Peer Muchalla",
        "Baltana Border Area", "Majri Chowk", "Raipur Rani", "Barwala", "Amravati Enclave",
        "Green Valley Apartments (Sector 20)", "The Valley by DLF", "Panchkula Heights",
        "Sushma Villas", "Motia Heights", "Imperial Residency", "Suncity Parikrama",
        "Victoria Heights", "Urban Vatika", "Trishla City"
    ]
};


    // Location selection functionality
    let selectedLocation = null;
    let selectedSector = null;

    function toggleLocationDropdown() {
        document.getElementById('locationDropdown').style.display = 
            document.getElementById('locationDropdown').style.display === 'block' ? 'none' : 'block';
        const icon = document.querySelector('.location-dropbtn i');
        if (document.getElementById('locationDropdown').style.display === 'block') {
            icon.classList.remove('fa-chevron-down');
            icon.classList.add('fa-chevron-up');
        } else {
            icon.classList.remove('fa-chevron-up');
            icon.classList.add('fa-chevron-down');
        }
    }

    function selectLocation(location) {
        selectedLocation = location;
        selectedSector = null;
        document.getElementById('selected-location').textContent = location;
        document.getElementById('locationDropdown').style.display = 'none';
        document.querySelector('.location-dropbtn i').classList.remove('fa-chevron-up');
        document.querySelector('.location-dropbtn i').classList.add('fa-chevron-down');

        // Show sector selection
        const sectorSelection = document.getElementById('sectorSelection');
        sectorSelection.style.display = 'block';
        
        // Populate sectors
        const sectorList = document.getElementById('sectorList');
        sectorList.innerHTML = '';
        
        locationData[location].forEach(sector => {
            const sectorItem = document.createElement('div');
            sectorItem.className = 'sector-item';
            sectorItem.style.padding = '10px 15px';
            sectorItem.style.cursor = 'pointer';
            sectorItem.style.transition = 'all 0.2s';
            sectorItem.textContent = sector;
            sectorItem.onclick = function() {
                selectSector(sector);
            };
            sectorList.appendChild(sectorItem);
        });
        
        // Update selected location display
        document.getElementById('selectedLocationDisplay').textContent = `Selected City: ${location}`;
    }

    function selectSector(sector) {
        selectedSector = sector;
        
        // Update active sector
        const sectorItems = document.querySelectorAll('.sector-item');
        sectorItems.forEach(item => {
            item.style.backgroundColor = '';
            item.style.color = '';
            if (item.textContent === sector) {
                item.style.backgroundColor = '#3498db';
                item.style.color = 'white';
				document.getElementById('sectorList').style.display = 'none';
				 document.querySelector('.sector-search').value = sector;
            }
        });
        
        // Update selected location display and hidden input
        const fullLocation = `${selectedLocation} - ${sector}`;
        document.getElementById('selectedLocationDisplay').textContent = `Selected Location: ${fullLocation}`;
        document.getElementById('location_input').value = fullLocation;
    }

    function filterSectors() {
        const searchTerm = document.querySelector('.sector-search').value.toLowerCase();
        const sectorItems = document.querySelectorAll('.sector-item');
        
        sectorItems.forEach(item => {
            const text = item.textContent.toLowerCase();
			document.getElementById('sectorList').style.display = 'block';
            item.style.display = text.includes(searchTerm) ? 'block' : 'none';
        });
    }

    // Close the dropdown if clicked outside
    window.onclick = function(event) {
        if (!event.target.matches('.location-dropbtn') && !event.target.closest('.location-dropdown-content')) {
            const dropdown = document.getElementById("locationDropdown");
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
                document.querySelector('.location-dropbtn i').classList.remove('fa-chevron-up');
                document.querySelector('.location-dropbtn i').classList.add('fa-chevron-down');
            }
        }
    }
    </script>
    <?php
    return ob_get_clean();
}

// AJAX handler for loading subtypes
add_action('wp_ajax_get_property_sub_types', 'get_property_sub_types_callback');
add_action('wp_ajax_nopriv_get_property_sub_types', 'get_property_sub_types_callback');

function get_property_sub_types_callback() {
    // Ensure proper input sanitization
    $parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;

    // Fetch child terms for the property categories
    $terms = get_terms([
        'taxonomy' => 'product_cat',
        'parent' => $parent_id,
        'hide_empty' => false,
    ]);

    $results = [];
    foreach ($terms as $term) {
        $results[] = [
            'term_id' => $term->term_id,
            'name'    => $term->name,
        ];
    }

    wp_send_json($results);
}

add_action('init', function() {
    if (!session_id()) {
        session_start();
    }
});

// Handle form submission
add_action('init', 'handle_property_listing_submission');
function handle_property_listing_submission() {
    if (isset($_POST['submit_property']) && is_user_logged_in()) {
      //echo"<pre>";print_r($_POST);die;
        if (!isset($_POST['property_listing_form_nonce']) || !wp_verify_nonce($_POST['property_listing_form_nonce'], 'property_listing_form_action')) {
            wp_die('Security check failed.');
        }

        $current_user = wp_get_current_user();

        // Initialize product categories array
        $cat_ids = [];

        if (!empty($_POST['usage'])) {
            $cat_ids[] = intval($_POST['usage']);
        }

        if (!empty($_POST['property_type'])) {
            $cat_ids[] = intval($_POST['property_type']);
        }

        if (!empty($_POST['sub_type'])) {
            $cat_ids[] = intval($_POST['sub_type']);
        }
		 if (!empty($_POST['sub_type_level_1'])) {
            $cat_ids[] = intval($_POST['sub_type_level_1']);
        }
		 if (!empty($_POST['sub_type_level_2'])) {
            $cat_ids[] = intval($_POST['sub_type_level_2']);
        }

        // Create WooCommerce Product
        $product_data = [
            'post_title'   => sanitize_text_field($_POST['owner_name']),
            'post_type'    => 'product',
            'post_status'  => 'pending', // or 'publish' cabins
            'post_author'  => $current_user->ID,
            'post_content' => sanitize_textarea_field($_POST['description']),
        ];

        $product_id = wp_insert_post($product_data);

        if ($product_id && !is_wp_error($product_id)) {
            // Set product meta city
            update_post_meta($product_id, '_regular_price', sanitize_text_field($_POST['price']));
            update_post_meta($product_id, '_price', sanitize_text_field($_POST['price']));
            update_post_meta($product_id, 'contact', sanitize_text_field($_POST['contact']));
            update_post_meta($product_id, 'location', sanitize_text_field($_POST['location']));
            update_post_meta($product_id, 'area', wp_kses_post($_POST['area']));
            update_post_meta($product_id, 'furnishing', sanitize_text_field($_POST['furnishing']));
			update_post_meta($product_id, 'lease_type', sanitize_text_field($_POST['lease_type']));
			update_post_meta($product_id, 'cabins', sanitize_text_field($_POST['cabins']));
			update_post_meta($product_id, 'open_space_option', sanitize_text_field($_POST['open_space_option']));
			update_post_meta($product_id, 'prefered_floor', sanitize_text_field($_POST['prefered_floor']));
			update_post_meta($product_id, 'seating_capacity', sanitize_text_field($_POST['seating_capacity']));
			update_post_meta($product_id, 'caretaker', sanitize_text_field($_POST['caretaker']));
			update_post_meta($product_id, 'caretaker_name', sanitize_text_field($_POST['caretaker_name']));
			update_post_meta($product_id, 'caretaker_phone', sanitize_text_field($_POST['caretaker_phone']));
			
			
			
			// ===== HANDLE AMENITIES (CHECKBOX ARRAY) ===== 
			if (isset($_POST['amenities']) && is_array($_POST['amenities'])) {
				// Sanitize each value in the array
				$amenities = array_map('sanitize_text_field', $_POST['amenities']);
				// Save as serialized array
				update_post_meta($product_id, 'amenities', $amenities);
			} else {
				// If no amenities selected, save empty array
				update_post_meta($product_id, 'amenities', array());
			}
			update_post_meta($product_id, 'footfall', sanitize_text_field($_POST['footfall']));
			update_post_meta($product_id, 'visibility', sanitize_text_field($_POST['visibility']));
			update_post_meta($product_id, 'ceilingHeight', sanitize_text_field($_POST['ceilingHeight']));
			update_post_meta($product_id, 'loadingFacilities', sanitize_text_field($_POST['loadingFacilities']));
			update_post_meta($product_id, 'bhk', sanitize_text_field($_POST['bhk']));
			update_post_meta($product_id, 'floor', sanitize_text_field($_POST['floor']));
			update_post_meta($product_id, 'house-parking', sanitize_text_field($_POST['house-parking']));
			update_post_meta($product_id, 'sharing-type', sanitize_text_field($_POST['sharing-type']));
			update_post_meta($product_id, 'gender', sanitize_text_field($_POST['gender']));
			update_post_meta($product_id, 'food-included', sanitize_text_field($_POST['food-included']));
			update_post_meta($product_id, 'bhk', sanitize_text_field($_POST['room-set']));
			update_post_meta($product_id, 'bathroom', sanitize_text_field($_POST['bathroom']));
			update_post_meta($product_id, 'full_address', sanitize_text_field($_POST['full_address']));
			

            // Assign selected categories
            if (!empty($cat_ids)) {
                wp_set_object_terms($product_id, $cat_ids, 'product_cat');
            }

            // ✅ Handle image uploads
            if (!empty($_FILES['property_images']['name'][0])) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
                require_once ABSPATH . 'wp-admin/includes/file.php';
                require_once ABSPATH . 'wp-admin/includes/media.php';

                $gallery_ids = [];

                foreach ($_FILES['property_images']['name'] as $key => $value) {
                    if ($_FILES['property_images']['name'][$key]) {
                        $file = [
                            'name'     => $_FILES['property_images']['name'][$key],
                            'type'     => $_FILES['property_images']['type'][$key],
                            'tmp_name' => $_FILES['property_images']['tmp_name'][$key],
                            'error'    => $_FILES['property_images']['error'][$key],
                            'size'     => $_FILES['property_images']['size'][$key],
                        ];

                        $_FILES['temp_file'] = $file;

                        $attach_id = media_handle_upload('temp_file', $product_id);

                        if (!is_wp_error($attach_id)) {
                            $gallery_ids[] = $attach_id;
                        }
                    }
                }

                if (!empty($gallery_ids)) {
                    // Set first image as featured
                    set_post_thumbnail($product_id, $gallery_ids[0]);

                    // Remaining images as gallery
                    if (count($gallery_ids) > 1) {
                        array_shift($gallery_ids); // remove featured image from gallery
                        update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
                    }
                }
            }

            $_SESSION['property_submission_success'] = true;
        } else {
            $_SESSION['property_submission_error'] = 'Failed to create product.';
        }
		
			// Redirect after successful submission
			if (!headers_sent()) {
				wp_redirect(add_query_arg('submitted', 'true', wp_get_referer()));
				exit;
			}

    }
}








function render_approval_box($post) {
    $status = get_post_meta($post->ID, 'approval_status', true);
    ?>
    <select name="approval_status" style="width:100%;">
        <option value="pending" <?php selected($status, 'pending'); ?>>Pending</option>
        <option value="approved" <?php selected($status, 'approved'); ?>>Approved</option>
        <option value="rejected" <?php selected($status, 'rejected'); ?>>Rejected</option>
    </select>
    <?php
}

add_action('save_post_product', function ($post_id) {
    if (isset($_POST['approval_status'])) {
        update_post_meta($post_id, 'approval_status', sanitize_text_field($_POST['approval_status']));
    }
});


/*
// Filter front-end product display
add_action('pre_get_posts', function($query) {
    if (!is_admin() && $query->is_main_query() && (is_shop() || is_product_category() || is_product_tag())) {
        $meta_query = $query->get('meta_query');
        if (!is_array($meta_query)) $meta_query = [];

        $meta_query[] = [
            'key'     => 'approval_status',
            'value'   => 'approved',
            'compare' => '='
        ];
        $query->set('meta_query', $meta_query);
    }
});

*/
/*
function defer_all_scripts_except_jquery($tag, $handle, $src) {
    if ($handle === 'jquery') {
        return $tag;
    }

    return '<script src="' . esc_url($src) . '" defer></script>';
}
add_filter('script_loader_tag', 'defer_all_scripts_except_jquery', 10, 3);*/





    

?>
