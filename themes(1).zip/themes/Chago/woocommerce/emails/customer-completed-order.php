<?php
/**
 * Customer completed order email template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * @hooked WC_Emails::email_header() Output the email header
 */
do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<p><?php printf( esc_html__( 'Hi %s,', 'woocommerce' ), esc_html( $order->get_billing_first_name() ) ); ?></p>
<p><?php esc_html_e( 'We have finished processing your order.', 'woocommerce' ); ?></p>

<?php
/*
 * @hooked WC_Emails::order_details() Shows the order details table.
 */
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

/*
 * Add Assigned Staff Details (Including Image)
 */
$staff_name  = get_post_meta( $order->get_id(), 'bookly_staff_name', true );
$staff_phone = get_post_meta( $order->get_id(), 'bookly_staff_phone', true );
$staff_email = get_post_meta( $order->get_id(), 'bookly_staff_email', true );
$staff_image = get_post_meta( $order->get_id(), 'bookly_staff_image', true ); // Check correct meta key

// If image is stored as an attachment ID, get the image URL
if ( is_numeric($staff_image) ) {
    $staff_image = wp_get_attachment_url($staff_image);
}

if ( !empty($staff_name) ) : ?>
    <h2><?php esc_html_e( 'Assigned Professional Details', 'woocommerce' ); ?></h2>
    <?php if ( !empty($staff_image) ) : ?>
        <p><img src="<?php echo esc_url($staff_image); ?>" alt="<?php echo esc_attr($staff_name); ?>" style="width:150px;height:auto;border-radius:10px;"></p>
    <?php endif; ?>
    <p><strong><?php esc_html_e( 'Name:', 'woocommerce' ); ?></strong> <?php echo esc_html( $staff_name ); ?></p>
    <p><strong><?php esc_html_e( 'Phone:', 'woocommerce' ); ?></strong> <?php echo esc_html( $staff_phone ); ?></p>
    <p><strong><?php esc_html_e( 'Email:', 'woocommerce' ); ?></strong> <?php echo esc_html( $staff_email ); ?></p>
<?php endif; ?>

<?php
/*
 * @hooked WC_Emails::order_meta() Shows order meta data.
 */
do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

/*
 * @hooked WC_Emails::customer_details() Shows customer details
 */
do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

/*
 * Show user-defined additional content
 */
if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

/*
 * @hooked WC_Emails::email_footer() Output the email footer
 */
do_action( 'woocommerce_email_footer', $email );
?>
