<?php
// Load header
get_header();
?>
<section class="section-404">
<div class="container">
<h1 class="head-404">404</h1>
<div class="body-404">
<h2> <span class="bold">Oh no!</span> This isn't right.</h2>
<p>This may be an old link, the URL may be typed incorrectly, or the page could have moved.</p>
<p>Please visit our <a href="<?php echo esc_url( home_url( '/' ) ); ?>">homepage</a> instead to find what you're looking for.</p>
</div>
</div>
</section>
 
<?php
get_footer();
?>
