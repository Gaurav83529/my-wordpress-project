<?php
get_header();

	while ( have_posts() ) : the_post();
		$result[] = [
                'id'            => get_the_ID(),
                'product_name'  => get_the_title(),
                'product_image'         => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'),
                'product_link'          => get_permalink(),
                'type'          => 'product',
            ];
	endwhile; 
	
	// Get categories separately
	$search_term = get_search_query();
	$categories = get_terms([
		'taxonomy'   => 'product_cat',
		'name__like' => $search_term,
		'hide_empty' => false,
	]);

	if (!empty($categories)) {
		foreach ($categories as $category) {
			$thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
			$image_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : wc_placeholder_img_src();
			 $category_url = get_term_link($category);
			$result[] = [
				'id'            => $category->term_id,
				'product_name'  => $category->name,
				'product_image' => $image_url,
				'product_link'  => esc_url($category_url),
				'type'			=> 'category'
			];
		}
	}
	// echo "<pre>";print_r($results);die;	
?>
<div class="service-content">
    <div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="headingOther">
					<h2>Search</h2>
				</div>
			</div>
		</div>
        <div class="row justify-content-center">
	<?php if(!empty($result)):
     foreach ( $result as $results){ ?>
        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="inner-booked-service">
             
				<?php if ( $results['product_image'] ) {  ?>
					<img class="img-fluid" src="<?php echo $results['product_image']; ?>" alt="Default Image">
				 <?php
				} else { ?>
					<img class="img-fluid" src="<?php echo esc_url(get_template_directory_uri() . '/images/default.png'); ?>" alt="Default Image">
				<?php } ?>

                <div class="content-services-about">
            
                    <h4><?php echo $results['product_name']; ?></h4>
           
                    <div class="reviews">
                        <?php echo do_shortcode('[wpcr_average_and_total_reviews]'); ?>
                    </div>
					<?php /*
                    <div class="service-description">
                        <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                    </div>
                    <!-- WooCommerce Product Price -->
                    <?php if ( class_exists('WooCommerce') ) :
                        $product = wc_get_product(get_the_ID());
                        if ($product && $product->get_price()) : ?>
                            <p class="price">Price: <?php echo $product->get_price_html(); ?></p>
                        <?php endif; ?>
                    <?php endif; */?>
                    <div class="price-book-now">
						<?php
						if($results['type'] == 'category')
						{ ?>
							 <a href="<?php echo '/sub-categories/?cat_id='.$results['id']; ?>" class="btn btn-primary">View More</a>
						<?php
						}
						else{ ?>
							 <a href="<?php echo $results['product_link']; ?>" class="btn btn-primary">View More</a>
						<?php } ?>
                       
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php else : ?>
    <p>No products or categories found matching your search.</p>
<?php endif; ?>

        </div>
    </div>
</div>

<?php
get_footer();
?>
