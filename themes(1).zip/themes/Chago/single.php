<?php

/**
 * Template Name: Service Page
 * Description: A custom template to display services related to a selected subcategory.
 */
get_header(); // Include the header
// Start output buffering
ob_start();
?>

<!--<div class="service-header">-->
<!--    <div class="container">-->
<!--        <h2>Services</h2>-->
<!--    </div>-->
<!--</div>-->
<div class="service-content">
    <div class="container">
        <div class="row">
            <?php
            // Get the subcategory ID from the query string
            $subcategory_id = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : 0;
            //Get ancestor if this subcategory
            $ancestors = get_ancestors($subcategory_id, 'product_cat');
            $areafield = false;
            if (in_array(98, $ancestors) || in_array(99, $ancestors)) {
                echo '    <!-- Left Sidebar -->
                <div class="col-md-2">
                    <aside class="product-filters">
                        <h4>Filters</h4>
                        
                        <!-- Area Filter -->
                        <div class="filter-area">
                            <label for="filter_area">Filter by Area (sqft):</label>
                            <div id="area_slider"></div>
                            <input type="number" id="filter_area_min" name="filter_area_min" placeholder="Min Area" />
                            <input type="number" id="filter_area_max" name="filter_area_max" placeholder="Max Area" />
                        </div>
                        
                        <!-- Budget Filter -->
                        <div class="filter-budget">
                            <label for="filter_budget">Filter by Budget (₹):</label>
                            <div id="budget_slider"></div>
                            <input type="number" id="filter_budget_min" name="filter_budget_min" placeholder="Min Budget" />
                            <input type="number" id="filter_budget_max" name="filter_budget_max" placeholder="Max Budget" />
                        </div>
                        
                        <!-- Filter Button -->
                        <button id="apply_filters" class="btn btn-primary">Apply Filters</button>
                    </aside>
                </div>';
            } ?>
            <div class="loader" style="display:none;"></div>
            <div class="col-md-10 col-lg-10 col-sm-12 col-12">
                <div class="row" id="service-list">
                    <?
                    // Check if a subcategory ID is provided
                    if ($subcategory_id) {
                        // Fetch services related to the specified subcategory
                        $args = array(
                            'post_type' => 'product', // Assuming services are WooCommerce products
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'term_id',
                                    'terms'    => $subcategory_id,
                                ),
                            ),
                        );
                        $services = new WP_Query($args);

                        // The Loop
                        if ($services->have_posts()) {
                            while ($services->have_posts()) {
                                $services->the_post();
                                // Get the featured image
                                $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                // Get the price
                                $price = get_post_meta(get_the_ID(), '_price', true);
                                // Get the product ID
                                $product_id = get_the_ID();
                                $product_author = get_the_author();
                                $product_area = get_post_meta($product_id, '_product_area', true);
                    ?>
                                <div class="col-xs-12 col-sm-12 col-md-4 mb-4">
                                    <div class="inner-booked-service">
                                        <!-- Display service image -->
                                        <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>">
                                            <img src="<?php echo esc_url($service_image); ?>" class="img-fluid" alt="<?php the_title(); ?>" />
                                            <div class="content-services-about">
                                                <!-- Display service title -->
                                                <h4><?php the_title(); ?><?php if (isset($product_area) && $product_area != "") {
                                                                                echo ' ' . '<small>(' . $product_area .'sqft)';
                                                                            } ?></small></h4>
                                                <small>(<?php echo $product_author ?>)</small>
                                        </a>
                                        <!-- Display service description -->
                                        <p class="service-description"><?php the_excerpt(); ?></p>

                                        <!-- hh -->
                                        <div class="price-book-now">
                                            <!-- Display price -->
                                            <span class="pricebok"><?php echo wc_price($price); ?></span>
                                            <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>" class="btn btn-primary">Book Now</a>
                                        </div>
                                    </div>
                                </div>
                </div>
    <?php
                            }
                            wp_reset_postdata(); // Reset the post data
                        } else {
                            echo '<p>No services found for this subcategory.</p>';
                        }
                    } else {
                        echo '<p>No subcategory selected.</p>';
                    }
    ?>
            </div>
        </div>
    </div>
    
    <script>
        jQuery(document).ready(function($) {
            $('#apply_filters').on('click', function(e) {
                e.preventDefault();
               
                // Gather filter inputs
                const subcategory_id = <?php echo $subcategory_id; ?>;
                console.log(subcategory_id);
                const area_min = $('#filter_area_min').val();
                const area_max = $('#filter_area_max').val();
                const budget_min = $('#filter_budget_min').val();
                const budget_max = $('#filter_budget_max').val();
                 $('#service-list').addClass('loading');

                $.ajax({
                    url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                    type: 'POST',
                    data: {
                        action: 'filter_services',
                        subcategory_id: subcategory_id,
                        area_min: area_min,
                        area_max: area_max,
                        budget_min: budget_min,
                        budget_max: budget_max,
                    },
                    beforeSend: function () {
                       $('.loader').show();
                    },
                    success: function(response) {
                        if (response.success) {
                            var servicesHtml = '';
                            $.each(response.data, function(index, service) {
                                servicesHtml += service.html; // Concatenate each service's HTML
                            });
                            $('.loader').hide();
                            $('#service-list').html(servicesHtml); // Update the content
                        } else {
                            $('#service-list').html('<p>No services found for the selected filters.</p>');
                        }
                        $('#service-list').removeClass('loading');
                    },
                });
            });
        });
    </script>
   <script>
    jQuery(document).ready(function($) {
    // Initialize the sliders
    $('#area_slider').slider({
        range: true,
        min: 0,
        max: 5000,
        step: 50,
        values: [50, 3000],
        slide: function(event, ui) {
            $('#filter_area_min').val(ui.values[0]);
            $('#filter_area_max').val(ui.values[1]);
        },
    });

    $('#filter_area_min').val($('#area_slider').slider('values', 0));
    $('#filter_area_max').val($('#area_slider').slider('values', 1));

    $('#budget_slider').slider({
        range: true,
        min: 0,
        max: 500000,
        step: 500,
        values: [500, 50000],
        slide: function(event, ui) {
            $('#filter_budget_min').val(ui.values[0]);
            $('#filter_budget_max').val(ui.values[1]);
        },
    });

    $('#filter_budget_min').val($('#budget_slider').slider('values', 0));
    $('#filter_budget_max').val($('#budget_slider').slider('values', 1));

    // Input handling for area min
    $('#filter_area_min').on('input', function() {
        let areaMin = parseInt($(this).val());
        let areaMax = parseInt($('#filter_area_max').val()) || $('#area_slider').slider('option', 'max');

        if (isNaN(areaMin) || areaMin < 0) {
            areaMin = 0; // Default to minimum value
            $(this).val('');
        }

        if (areaMin > areaMax) {
            areaMin = areaMax;
        }

        $('#area_slider').slider('values', 0, areaMin);
    });

    // Input handling for area max
    $('#filter_area_max').on('input', function() {
        let areaMax = parseInt($(this).val());
        let areaMin = parseInt($('#filter_area_min').val()) || $('#area_slider').slider('option', 'min');

        if (isNaN(areaMax) || areaMax < areaMin) {
            areaMax = areaMin;
            $(this).val('');
        }

        $('#area_slider').slider('values', 1, areaMax);
    });

    // Input handling for budget min
    $('#filter_budget_min').on('input', function() {
        let budgetMin = parseInt($(this).val());
        let budgetMax = parseInt($('#filter_budget_max').val()) || $('#budget_slider').slider('option', 'max');

        if (isNaN(budgetMin) || budgetMin < 0) {
            budgetMin = 0; // Default to minimum value
            $(this).val('');
        }

        if (budgetMin > budgetMax) {
            budgetMin = budgetMax;
        }

        $('#budget_slider').slider('values', 0, budgetMin);
    });

    // Input handling for budget max
    $('#filter_budget_max').on('input', function() {
        let budgetMax = parseInt($(this).val());
        let budgetMin = parseInt($('#filter_budget_min').val()) || $('#budget_slider').slider('option', 'min');

        if (isNaN(budgetMax) || budgetMax < budgetMin) {
            budgetMax = budgetMin;
            $(this).val('');
        }

        $('#budget_slider').slider('values', 1, budgetMax);
    });
    
});
</script>
<style>
/* Service Page Loader */
.loader {
    width: 48px;
    height: 48px;
    border: 5px solid #378CCF;;
    border-bottom-color: transparent;
    border-radius: 50%;
    display: inline-block;
    box-sizing: border-box;
    animation: rotation 1s linear infinite;
    
    position: absolute;  /* Position it relative to the parent container */
    top: 50%;  /* Center vertically */
    left: 57%;  /* Center horizontally */
    transform: translate(-50%, -50%);  /* Offset the element by its own width and height to center it */
    z-index: 9999;
    }

    @keyframes rotation {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
    }
    /* Apply a blurred effect when the loader is visible */
#service-list.loading{
    filter: blur(2px);
    opacity: 0.2;
    pointer-events: none; /* Optional: prevents interactions with content while loader is visible */
}

</style>
    <?php
    // End output buffering
    $content = ob_get_clean();
    echo $content; // Output the content to the page
    get_footer(); // Include the footer
    ?>