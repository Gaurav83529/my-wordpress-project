<?php
ob_start();
if (!isset($_COOKIE['user_lat']) || !isset($_COOKIE['user_address'])):
?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const locationBox = document.getElementById("location-input").value;
            console.log(locationBox);

            if (!locationBox.trim()) {
				
                document.getElementById("location-modal").style.display = "block";
                // Hide the close button
                const closeButton = document.querySelector(".close-btn");
                if (closeButton) {
                    closeButton.style.display = "none";
                }
            }
        });
    </script>
<?php
else:
    // Debugging for existing cookies
    echo '<script>console.log("Location already set: Latitude: ' . $_COOKIE['user_lat'] . ', Longitude: ' . $_COOKIE['user_lon'] . '");</script>';
endif;
?>
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_COOKIE['user_address'])) {
    $user_address = $_COOKIE['user_address'];
    $escaped_address = htmlspecialchars($user_address, ENT_QUOTES, 'UTF-8');
}
?>

<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
        <?php if (isset($escaped_address)) : ?>
            const locationInput = document.getElementById('location-input');
            if (locationInput) { // Ensure the element exists
                locationInput.value = "<?php echo $escaped_address; ?>";
                // console.log(locationInput.value); // Log to verify the value is set
            }
        <?php endif; ?>
    });
</script>


<!doctype html>
<html lang="en">

<head>
    <title>Chago</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.9/dist/flatpickr.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css?v=<?php echo rand(100000, 999999); ?>" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	
    <?php wp_head(); ?>
</head>

<body class="body-wrap">
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-5">
                    <a href="/" class="navbar-logo"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" class="img-fluid" /></a>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-7 search-service">
                    <div class="inner-flex-content">
                        <!-- Main Search Bar -->
                        <div class="search-bar">
                            <span class="location-icon">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/Place-Marker.svg" alt="Location" />
                            </span>
                            <input type="text" class="form-control" id="location-input" placeholder="Mohali, India" onclick="openModal()" readonly />
                        </div>
                        <!-- Modal Popup -->
                        <div id="location-modal" class="modal">
                            <div class="modal-content">
                                <span class="close-btn" onclick="closeModal()">&times;</span>
                                <!-- Modal Header -->
                                <h3>Select Location</h3>
                                <!-- Location Search Bar in Modal -->
						

            <input type="text" class="form-control" id="searchBox" placeholder="Search for a location..." autocomplete="off" />
                                <!-- Button to use current location -->
                                <button type="button" id="use-location-btn" onclick="getLocation()">Use My Current Location</button>
                                <!-- Suggestions List -->
                                	<div id="suggestions-loader" style="display: none;">Loading...</div>
                                <div id="suggestions" class="suggestions-list"></div>
                            </div>
                        </div>
						<!-- HTML for the loader -->
						<div id="loading-spinner" style="display:none;">
							<div class="spinner"></div> <!-- You can use CSS spinner -->
						</div>

                        <!-- CSS Styling -->
                        <style>
                            .form-control {
                                width: 100%;
                                padding: 10px;
                                border: 1px solid #ccc;
                                border-radius: 25px;
                                font-size: 16px;
                            }

                            /* Modal Styles */
                            .modal {
                                display: none;
                                position: fixed;
                                z-index: 1;
                                left: 0;
                                top: 0;
                                width: 100%;
                                height: 100%;
                                overflow: auto;
                                background-color: rgba(0, 0, 0, 0.5);
                                /* Background color */
                            }

                            .modal-content {
                                background-color: #fff;
                                margin: 15% auto;
                                padding: 20px;
                                border-radius: 8px;
                                width: 80%;
                                max-width: 500px;
                            }

                            .close-btn {
                                color: #aaa;
                                float: right;
                                font-size: 28px;
                                font-weight: bold;
                            }

                            .close-btn:hover,
                            .close-btn:focus {
                                color: black;
                                text-decoration: none;
                                cursor: pointer;
                            }

                            button {
                                padding: 10px 15px;
                                background-color: #007bff;
                                color: white;
                                border: none;
                                border-radius: 25px;
                                cursor: pointer;
                                margin-top: 10px;
                            }

                            button:hover {
                                background-color: #0056b3;
                            }

                            /* Suggestions List */
                            .suggestions-list {
                                margin-top: 10px;
                                border-top: 1px solid #ccc;
                                max-height: 200px;
                                overflow-y: auto;
                            }

                            .suggestion-item {
                                padding: 10px;
                                cursor: pointer;
                                font-size: 16px;
                            }

                            .suggestion-item:hover {
                                background-color: #f1f1f1;
                            }

                            .location-icon i {
                                color: #378ccf;
                                margin-right: 8px;
                            }
                        </style>

                        <script>
                            //   jQuery(document).ready(function(){
                            // 	   const locationBox = document.getElementById("location-input").value;
                            // 	   console.log(locationBox);
                            // 	   if(!locationBox.trim()){
                            // 		   document.getElementById("location-modal").style.display = "block";
                            // 		           // Hide the close-btn
                            // 		   document.querySelector(".close-btn").style.display = "none";
                            // 	   }
                            // 	   });

                            // Open Modal when the input field is clicked
                            function openModal() {
                                document.getElementById("location-modal").style.display = "block";
                                const closeButton = document.querySelector(".close-btn");
                                clearSuggestionList();
                                if (closeButton) {
                                    closeButton.style.display = "block"; // Set the button to be visible
                                    console.log("Close button is now visible.");
                                }
                            }

                            function clearSuggestionList() {
                                const suggestionsList = document.getElementById("suggestions");
                                suggestionsList.innerHTML = "";
                            }
                            // Close the modal
                            function closeModal() {
                                document.getElementById("location-modal").style.display = "none";
                            }

                            // Fetch the current location using HTML5 Geolocation API
                            function getLocation() {
                                const locationInput = document.getElementById('searchBox');

                                if (navigator.geolocation) {
                                    locationInput.value = "Fetching location..."; // Set a loading message
                                    navigator.geolocation.getCurrentPosition(
                                        function(position) {
                                            const lat = position.coords.latitude;
                                            const lon = position.coords.longitude;
                                            fetchSuggestionsByCoordinates(lat, lon);
                                            // Set the coordinates directly into the input field
                                            // locationInput.value = `${locations[2]}`;
                                            // locationInput.value = `Latitude: ${lat}, Longitude: ${lon}`;
                                            closeModal(); // Close the modal after fetching location
                                            //console.log(lat);
                                            storeUserCoordinatesInSession(lat, lon);
                                        },
                                        handleError, {
                                            enableHighAccuracy: true,
                                            timeout: 20000,
                                            maximumAge: 0
                                        } // Optional parameters
                                    );
                                } else {
                                    alert("Geolocation is not supported by this browser.");
                                }
                            }
			


                            // Handle errors in geolocation
                            function handleError(error) {
                                const locationInput = document.getElementById('location-input');
                                locationInput.value = ""; // Clear any temporary message

                                switch (error.code) {
                                    case error.PERMISSION_DENIED:
                                        alert("User denied the request for Geolocation.");
                                        break;
                                    case error.POSITION_UNAVAILABLE:
                                        alert("Location information is unavailable.");
                                        break;
                                    case error.TIMEOUT:
                                        alert("Unable to fetch your location, Please try to add location manually");
                                        break;
                                    case error.UNKNOWN_ERROR:
                                        alert("An unknown error occurred.");
                                        break;
                                }
                            }

                            function storeUserCoordinatesInSession(lat, lon) {
                                var data = {
                                    action: 'store_coordinates',
                                    lat: lat,
                                    lon: lon
                                };
                                
                                jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', data, function(response) {
                                    if (response.success) {
                                        console.log(response.data.message); // Successfully stored coordinates
                                    } else {

                                        // console.log(response.data.message); // Error message
                                    }
                                });
                            }

                            // setInterval(function() {
                            //     getLocation();
                            //     // console.log("Fetching location at regular interval...");
                            // }, 900000);

                            async function fetchSuggestionsByCoordinates(lat, lon) {
                            
                                try {
                                    const response = await fetch("<?php echo admin_url('admin-ajax.php'); ?>?action=fetch_location_from_lat_lon&lat=" + encodeURIComponent(lat) + "&lon=" + encodeURIComponent(lon));
                                    const result = await response.json();
                                    const address = result.data[0];
                                    if (result.success) {
                                        const locationInput = document.getElementById('location-input');
                                        const formattedAddress = [
                                            address.subLocality,
                                            address.locality,
                                            address.city,
                                            address.pincode
                                        ].filter(Boolean).join(", ");
                                        locationInput.value = formattedAddress;
                                        if (typeof autofill_checkout_address === 'function') {
                                            autofill_checkout_address();
                                            //console.log('Checkout Data:');
                                        } else { // console.log('not exist');
                                        }
                                    } else {
                                        console.error("Error fetching suggestions:", result.data.message);
                                    }
                                } catch (error) {
                                    console.error("Error fetching suggestions by coordinates:", error);
                                }
                            }

                            let typingTimer;
                            const typingDelay = 500;

                            async function fetchSuggestions(query) {
                                if (query.length < 2 && !query.includes(' ')) return;
                                query = JSON.stringify(query.replace(/\s/g, "+"));
                                try {
                                    const response = await fetch("<?php echo admin_url('admin-ajax.php'); ?>?action=fetch_autosuggestions&query=" +
                                        query);
                                    const result = await response.json();
                                    console.log('Result is this:', result);

                                    if (result.success) {
                                        displaySuggestions(result.data);
                                    } else {
                                        console.error("Error fetching suggestions:", result.data.message);
                                    }
                                } catch (error) {
                                    console.error("Error fetching suggestions:", error);
                                }
                            }

                            const inputElement = document.getElementById('searchBox'); // Replace with your input element ID

                            inputElement.addEventListener('input', function(event) {
                                const query = event.target.value;

                                // Clear the previous timer if it's still running
                                clearTimeout(typingTimer);

                                // Set a new timer that will call fetchSuggestions after 500ms of inactivity
                                typingTimer = setTimeout(function() {
                                    fetchSuggestions(query);
                                }, typingDelay);
                            });
			let suggestionsList = []; // Declare globally

					// Function to fetch suggestions based on coordinates or search query
					/*async function fetchSuggestions(query) {
						if (query.length < 2 && !query.includes(' ')) return;

						query = JSON.stringify(query.replace(/\s/g, "+"));
						try {
							const response = await fetch("<?php //echo admin_url('admin-ajax.php'); ?>?action=fetch_autosuggestions&query=" + query);
							const result = await response.json();
							console.log('Result is this:', result);

							if (result.success) {
								suggestionsList = result.data;  // Populate the suggestionsList with the fetched data
								displaySuggestions(suggestionsList);  // Now pass the populated list to displaySuggestions
							} else {
								console.error("Error fetching suggestions:", result.data.message);
							}
						} catch (error) {
							console.error("Error fetching suggestions:", error);
						}
					}*/
					
					async function fetchSuggestions(query) {
	//if (query.length < 2 && !query.includes(' ')) return;
	const trimmedQuery = query.trim();
if (trimmedQuery.length < 2 && !trimmedQuery.includes(' ')) {
    hideSuggestions(); // <-- Hide suggestions
    return;
  }
	query = JSON.stringify(query.replace(/\s/g, "+"));

	// Show the loader
	document.getElementById('suggestions-loader').style.display = 'block';

	try {
		const response = await fetch("<?php echo admin_url('admin-ajax.php'); ?>?action=fetch_autosuggestions&query=" + query);
		const result = await response.json();
		console.log('Result is this:', result);

		if (result.success) {
			suggestionsList = result.data;
			displaySuggestions(suggestionsList);
		} else {
			console.error("Error fetching suggestions:", result.data.message);
		}
	} catch (error) {
		console.error("Error fetching suggestions:", error);
	} finally {
		// Hide the loader no matter what
		document.getElementById('suggestions-loader').style.display = 'none';
	}
}
function hideSuggestions() {
  const list = document.getElementById('suggestions');
  if (list) {
    list.innerHTML = '';  // Clear suggestions
    //list.style.display = 'none'; // Hide list
  }
}

					 // Function to display suggestions
						function displaySuggestions(suggestions) {
					const locationInput = document.getElementById('searchBox');
					const suggestionsContainer = document.getElementById('suggestions');
					const locationModal = document.getElementById('location-modal'); // Get the modal element

					// If the input is empty, clear the suggestions list and hide the modal
					if (!locationInput.value.trim()) {
						suggestionsContainer.innerHTML = '';  // Clear suggestions
						locationModal.style.display = "none";  // Hide the modal or dropdown
						return; // Exit the function if input is empty
					}

					// Ensure the suggestions list is properly populated before trying to display
					if (suggestions && suggestions.length > 0) {
						suggestionsContainer.innerHTML = ''; // Clear any previous suggestions

						suggestions.forEach(location => {
							const listItem = document.createElement("div"); // Create a new list item
							listItem.classList.add("suggestion-item"); // Add a class for styling
							listItem.textContent = location.placeAddress || "Unknown Place"; // Set the text content

							// Add an onclick event to handle selection
							listItem.onclick = () => {
								document.getElementById("location-input").value = location.placeAddress; // Set selected place in the input field
								document.cookie = "user_address=" + location.placeAddress + "; path=/; max-age=3600"; // Store in cookie
								jQuery.ajax({
									url: '<?php echo admin_url('admin-ajax.php'); ?>',
									type: 'POST',
									data: {
										action: 'set_formatted_address',
										place_address: location.placeAddress
									},
									success: function(response) {
										if (typeof autofill_checkout_address === 'function') {
											autofill_checkout_address(); // Call checkout address autofill if necessary
										}
									},
									error: function() {
										console.log('Error executing PHP function');
									}
								});
								closeModal(); // Close the modal after selection
							};

							// Add an icon for location (optional)
							const icon = document.createElement("span");
							icon.classList.add("location-icon");
							icon.innerHTML = '<i class="fas fa-map-marker-alt"></i>';
							listItem.insertBefore(icon, listItem.firstChild); // Add icon at the start of the list item

							// Append the listItem to the suggestions container
							suggestionsContainer.appendChild(listItem);  // Correctly append to the container, not the array
						});
					} else {
						suggestionsContainer.innerHTML = ''; // Clear suggestions if no results
						console.log("No suggestions to display.");
					}
				}


jQuery(document).ready(function($) {
    $('#search-input').on('keyup', function() {
        var query = $(this).val();

        if (query.length > 2) { // Trigger search only if more than 2 characters
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                method: 'GET',
                data: {
                    action: 'search_products_services',
                    query: query
                },
                success: function(response) {
                    $('#search-results').html(response);
                    $('#search-results').show();
                }
            });
        } else {
            $('#search-results').hide();
        }
    });

    // Hide results if clicked outside
    $(document).click(function(e) {
        if (!$(e.target).closest('.search-bar').length) {
            $('#search-results').hide();
        }
    });
});

                        </script>

							<div class="search-bar search-field">
							<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
								<input type="text" name="s" class="form-control" placeholder="Search Service" value="<?php echo get_search_query(); ?>" />
								<button type="submit" class="btn btnTheme">
									<img src="<?php echo get_template_directory_uri(); ?>/images/Search.svg" alt="Search" />
								</button>
							</form>
						</div>

                        <!-- <div class="cart">
                            <a href="<?php //echo esc_url(home_url('/cart'));
                                        ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/Shopping-Cart.svg" alt="Shopping-Cart" />
                        <span class="cart-count"><?php //echo WC()->cart->get_cart_contents_count(); 
                                                    ?></span></a>
                        </div>-->
                      <div class="account-login">
					<?php 
						$default_image = "/wp-content/uploads/2025/02/profile.png"; 
						$user_image = $default_image; 

						if (is_user_logged_in()) {
							$current_user = wp_get_current_user();
							$user_id = $current_user->ID;
							$profile_image = get_user_meta($user_id, 'user_registration_profile_pic_url', true);

							// Check if the profile image is stored as an attachment ID
							if (!empty($profile_image)) {
								if (is_numeric($profile_image)) {
									$profile_image = wp_get_attachment_url($profile_image);
								}
								$user_image = esc_url($profile_image);
							}
						}
					?>

					<img decoding="async" class="profile-picture" alt="profile-picture" 
						 src="<?php echo esc_url($user_image); ?>">

					<div class="dropdown-content">
						<a href="<?php echo esc_url(home_url('/wishlist')); ?>">Wishlist</a>
						<?php if (is_user_logged_in()) : ?>
							<?php if (in_array('subscriber', (array) $current_user->roles)) : ?>
								<a href="<?php echo esc_url(home_url('/my-account')); ?>">My Account</a>
                                <a href="<?php echo esc_url(home_url('/my-orders')); ?>">My Orders</a>
							<?php else : ?>
								<a href="<?php echo esc_url(get_edit_profile_url()); ?>">Profile</a>
							<?php endif; ?>
							<a href="<?php echo wp_logout_url(home_url()); ?>">Logout</a>
						<?php else : ?>
							<a href="<?php echo esc_url(home_url('/login')); ?>">Login</a>
							<a href="<?php echo esc_url(home_url('/user-registration')); ?>">Sign-Up</a>
						<?php endif; ?>
					</div>
				</div>


                    </div>

                </div>
            </div>
        </div>
        <?php wp_head(); ?>
    </header>