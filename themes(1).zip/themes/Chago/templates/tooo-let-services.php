<?php
/*
Template Name: Too-Let Services
*/

get_header(); ?>

<section class="toolet-template">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="headingOther">
					<h2>
						<?php
						$subcategory_id = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : 0;
						$subcategory_name = '';
						$parent_category_name = '';
						$city = isset($_GET['city']) ? sanitize_text_field($_GET['city']) : '';
						$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';

						if ($subcategory_id) {
							$subcategory = get_term($subcategory_id, 'product_cat');
							if ($subcategory && !is_wp_error($subcategory)) {
								$subcategory_name = $subcategory->name;

								if ($subcategory->parent) {
									$parent_category = get_term($subcategory->parent, 'product_cat');
									if ($parent_category && !is_wp_error($parent_category)) {
										$parent_category_name = $parent_category->name;
									}
								}
							}
						}

						// Build dynamic title
						$parts = [];

						if ($subcategory_name) {
							$parts[] = $subcategory_name;
						}

						if ($city) {
							$parts[] = ucfirst($city);
						}

						if ($type) {
							$parts[] = ucfirst($type);
						}

						$parts[] = 'Too-Let Services';

						//echo esc_html(implode(' - ', $parts));
						?>
					</h2>
				</div>
			</div>
		</div>
	</div>
    <div class="property-location-selector">
        <div class="container">
            <!-- Residential Section -->
			
            <div id="residential" class="toolet-template-inner" style="display: none;">
			<h2 class="page_title">Residential Properties </h2>
                <h3>Residential Properties </h3>
                
                <!-- City Selector -->
                <div class="city-buttons">
                    <button class="btn btnTheme city-button" onclick="selectCity('Chandigarh', 'residential')">Chandigarh</button>
                    <button class="btn btnTheme city-button" onclick="selectCity('Mohali', 'residential')">Mohali</button>
                    <button class="btn btnTheme city-button" onclick="selectCity('Panchkula', 'residential')">Panchkula</button>
                </div>
                
                <!-- Search and Sector Selection -->
                <div id="residential-location-selector" style="display: none;">
                    <div class="search-container">
                        <input type="text" class="form-control search-bar" id="residential-search" 
                               placeholder="Search sectors or localities..." onkeyup="filterAreas('residential')">
                    </div>
                    
                   
                    
                    <!-- Selected Location Display -->
                    <div id="residential-selected-location" class="selected-location"></div>
                    
                    <!-- Property Type Options -->
                    <div id="residential-property-options" class="property-options" style="display: none;">
                        <h3>Select Property Type</h3>
                        <div class="options-grid">
                            <div class="option-card" onclick="selectCategoryType('residential', 'flat')">
                                <i class="fas fa-building"></i>
                                <h4>Flat</h4>
                                <p>Apartments & Flats</p>
                            </div>
                            <div class="option-card" onclick="selectCategoryType('residential', 'room')">
                                <i class="fas fa-door-open"></i>
                                <h4>Room</h4>
                                <p>Single or Shared Rooms</p>
                            </div>
                            <div class="option-card" onclick="selectCategoryType('residential', 'pg')">
                                <i class="fas fa-users"></i>
                                <h4>PG</h4>
                                <p>Paying Guest Accommodation</p>
                            </div>
                            <div class="option-card" onclick="selectCategoryType('residential', 'house')">
                                <i class="fas fa-home"></i>
                                <h4>House</h4>
                                <p>Independent Houses & Villas</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Filter Panel -->
                    <div id="residential-filter-panel" class="filter-panel"></div>
					
					 <div class="sectors-container" style="padding-top: 19px;">
                        <div class="sectors-list" id="residential-area-list"></div>
                    </div>
                </div>
            </div>
            
            <!-- Commercial Section -->
            <div id="commercial" class="toolet-template-inner" style="display: none;">
			<h2 class="page_title">Commercial Properties</h2>
                <h3>Commercial Properties</h3>
                
                <!-- City Selector -->
                <div class="city-buttons">
                    <button class="btn btnTheme city-button" onclick="selectCity('Chandigarh', 'commercial')">Chandigarh</button>
                    <button class="btn btnTheme city-button" onclick="selectCity('Mohali', 'commercial')">Mohali</button>
                    <button class="btn btnTheme city-button" onclick="selectCity('Panchkula', 'commercial')">Panchkula</button>
                </div>
                
                <!-- Search and Sector Selection -->
                <div id="commercial-location-selector" style="display: none;">
                    <div class="search-container">
                        <input type="text" class="form-control search-bar" id="commercial-search" 
                               placeholder="Search sectors or commercial areas..." onkeyup="filterAreas('commercial')">
                    </div>
                    
                 
                    
                    <!-- Selected Location Display -->
                    <div id="commercial-selected-location" class="selected-location"></div>
                    
                    <!-- Commercial Categories -->
                    <div id="commercial-categories" class="commercial-categories" style="display: none;">
                        <button class="category-button" onclick="showCommercialSubcategories('office')">
                            <i class="fas fa-briefcase"></i> Office Space
                        </button>
                        <button class="category-button" onclick="showCommercialSubcategories('shop')">
                            <i class="fas fa-store"></i> Retail Space
                        </button>
                        <button class="category-button" onclick="showCommercialSubcategories('warehouse')">
                            <i class="fas fa-warehouse"></i> Warehouse
                        </button>
                    </div>
                    
                    <!-- Commercial Subcategories -->
                    <div id="commercial-subcategories" class="commercial-subcategories" style="display: none;"></div>
                    
                    <!-- Filter Panel -->
                    <div id="commercial-filter-panel" class="filter-panel"></div>
					
					<div class="sectors-container" style="padding-top: 19px;">
                        <div class="sectors-list" id="commercial-area-list"></div>
                    </div>
					
                </div>
            </div>
            
            <!-- Results Section -->
            <div class="row" id="property-results" style="display: none;">
                <div class="col-lg-12">
                    <div class="headingOther">
                        <h2 id="results-heading">Available Properties</h2>
                    </div>
                </div>
                <div class="col-lg-12" id="property-results-container">
                    <!-- Properties will be loaded here via AJAX -->
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    /* Add the CSS styles from the original property selector here */
    /* These should be added to your theme's stylesheet or in a style tag */
    :root {
        --primary-color: #3498db;
        --primary-hover: #2980b9;
        --secondary-color: #f39c12;
        --secondary-hover: #e67e22;
        --success-color: #2ecc71;
        --danger-color: #e74c3c;
        --light-gray: #f2f2f2;
        --medium-gray: #d0d0d0;
        --dark-gray: #333;
    }
    
    .property-type-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-bottom: 30px;
    }
    
    .main-button {
        padding: 12px 25px;
        border: none;
        border-radius: 30px;
        cursor: pointer;
        font-size: 16px;
        font-weight: 600;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .primary-button {
        background-color: var(--primary-color);
        color: white;
    }
    
    .primary-button:hover {
        background-color: var(--primary-hover);
        transform: translateY(-2px);
    }
    
    .secondary-button {
        background-color: var(--secondary-color);
        color: white;
    }
    
    .secondary-button:hover {
        background-color: var(--secondary-hover);
        transform: translateY(-2px);
    }
    
    .active-button {
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.3);
    }
    
    .section {
        display: none;
        animation: fadeIn 0.5s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .property-options {
        display: none;
        margin-top: 20px;
        animation: fadeIn 0.3s ease;
    }
    
    .options-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 15px;
        margin-top: 15px;
    }
    
    .option-card {
        background-color: white;
        border-radius: 10px;
        padding: 15px;
        cursor: pointer;
        transition: all 0.3s;
        border: 1px solid var(--medium-gray);
        text-align: center;
    }
    
    .option-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        border-color: var(--primary-color);
    }
    
    .option-card i {
        font-size: 24px;
        margin-bottom: 10px;
        color: var(--primary-color);
    }
    
    .filter-panel {
     
        margin-top: 30px; 
        display: none;
        animation: fadeIn 0.3s ease;
		flex-wrap: wrap;
		width: 100%;
		gap: 15px;
		justify-content: space-between;
	}
	
    
.filter-group {
    margin-bottom: 15px;
    width: calc(50% - 8px);
}
    
    .filter-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
    }
    
    .filter-group select, .filter-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid var(--medium-gray);
        border-radius: 5px;
        font-size: 14px;
		border-radius: 4px !important;
    background: #f0f5fd;
    border: 1px solid rgb(0 0 0 / 5%);
    }
    
    .filter-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 20px;
		width: 100%;
    }
    
    .action-button {
        padding: 8px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: 600;
        transition: all 0.3s;
    }
    
    .apply-button {
        background-color: var(--success-color);
        color: white;
    }
    
    .apply-button:hover {
        background-color: #27ae60;
    }
    
    .reset-button {
        background-color: var(--danger-color);
        color: white;
    }
    
    .reset-button:hover {
        background-color: #c0392b;
    }
    
    .commercial-categories {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 15px;
        flex-wrap: wrap;
    }
    
    .category-button {
        padding: 8px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        background-color: var(--secondary-color);
        color: white;
        font-size: 14px;
        transition: all 0.3s;
    }
    
    .category-button:hover {
        background-color: var(--secondary-hover);
    }
    
    .commercial-subcategories {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 15px;
        flex-wrap: wrap;
    }
    
    .subcategory-button {
        padding: 6px 12px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        background-color: var(--primary-color);
        color: white;
        font-size: 13px;
        transition: all 0.3s;
    }
    
    .subcategory-button:hover {
        background-color: var(--primary-hover);
    }
    
    @media (max-width: 768px) {
        .property-type-buttons {
            flex-direction: column;
            align-items: center;
        }
        
        .options-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<script>
// Property data with sectors for each city

	const propertyData = {
  residential: {
    Chandigarh: Array.from(
      new Set([
        ...Array.from({ length: 56 }, (_, i) => `Sector ${i + 1}`),
        "Kishangarh", "Dhanas", "Sarangpur", "Khuda Lahora", "Khuda Jassu",
        "Hallo Majra", "Manimajra", "Daria", "Maloya", "Dadu Majra",
        "Palsora", "Kansal", "Kaimbala", "Khuda Ali Sher", "Ram Darbar Colony",
        "Railway Colony", "Burail", "Mauli Jagran", "Raipur Kalan", "Raipur Khurd",
        "Behlana", "Makhan Majra", "Attawa", "Badheri", "Bapu Dham Colony", "Indira Colony"
      ])
    ),
    Mohali: Array.from(
      new Set([
        ...Array.from({ length: 12 }, (_, i) => `Phase ${i + 1}`),
        ...Array.from({ length: 23 }, (_, i) => `Sector ${60 + i}`),
        "Shahi Majra", "Balongi", "Kharar", "Sohana", "Matour", "Aero City",
        "Sector 54", "Sector 55", "Sector 56", "Sector 57", "Sector 58", "Sector 59",
        "Sector 83", "Sector 84", "Sector 85", "Sector 86", "Sector 87", "Sector 88",
        "Sector 89", "Sector 90", "Sector 91", "Sector 92", "Sector 93", "Sector 94",
        "Sector 95", "Sector 96", "Sector 97", "Sector 98", "Sector 99", "Sector 100",
        "Kumbra", "Mohali Village", "Manak Majra", "Madanpur", "Daun", "Desu Majra",
        "Jhungian", "Jagatpura", "Jhanjeri (student hub)", "IT City", "Sunny Enclave",
        "TDI City", "Sector 66-A", "Sector 82-A", "Sector 88-A", "Sector 115", "Sector 116",
        "Sector 117", "Sector 118", "Sector 119", "Sector 125", "Sector 126", "Sector 127", "Sector 128",
        "Sector 1 (New Chandigarh)", "Sector 2 (New Chandigarh)", "Sector 3 (New Chandigarh)",
        "Sector 4 (New Chandigarh)", "Sector 5 (New Chandigarh)", "Sector 6 (New Chandigarh)",
        "Omaxe New Chandigarh", "Eco City Phase 1", "Eco City Phase 2", "DLF Hyde Park",
        "Manohar Singh Palm Residency", "GMADA Urban Plots", "The MedCity",
        "New Chandigarh Extension (Mullanpur Garibdass)", "Ambika Florence Park",
        "Jubilee Golf Vista", "The Address by Unity Group"
      ])
    ),
    Panchkula: Array.from(
      new Set([
        ...Array.from({ length: 20 }, (_, i) => `Sector ${i + 1}`),
        "Sector 21", "Sector 22", "Sector 23", "Sector 24", "Sector 25", "Sector 26",
        "Sector 27", "Sector 28", "Sector 29", "Sector 30", "Sector 31", "Sector 12A",
        "MDC Sector 4", "MDC Sector 5", "Panchkula Extension (Sector 20–21 Side)",
        "Housing Board Colony", "Indira Awas Colony", "Ramgarh Colony", "Peer Muchalla",
        "Baltana Border Area", "Majri Chowk", "Raipur Rani", "Barwala", "Amravati Enclave",
        "Green Valley Apartments (Sector 20)", "The Valley by DLF", "Panchkula Heights",
        "Sushma Villas", "Motia Heights", "Imperial Residency", "Suncity Parikrama",
        "Victoria Heights", "Urban Vatika", "Trishla City"
      ])
    )
  },
  commercial: {
    Chandigarh: Array.from(
      new Set([
        ...Array.from({ length: 56 }, (_, i) => `Sector ${i + 1}`),
        "Industrial Area Phase 1",
        "Industrial Area Phase 2",
        "Ram Darbar Industrial Estate",
        "Sector 17 Plaza",
        "Sector 22 Market",
        "Sector 19 Market",
        "Sector 26 Madhya Marg (restaurants, offices, bars)",
        "Sector 34 Commercial Belt (coaching, banks, hotels)",
        "Sector 35 & 36 Business Zone",
        "Sector 8 Inner Market",
        "Manimajra Furniture Market",
        "Modern Housing Complex, Manimajra",
        "Burail Market (Sector 45)",
        "Mauli Jagran Local Market",
        "Bapu Dham Market",
        "Daria Local Market",
        "Hallo Majra Market",
        "Elante Mall (Industrial Area Phase 1)",
        "DT Mall (IT Park, Manimajra)",
        "Centra Mall (Industrial Area Phase 1)",
        "TDI Mall (Sector 17)",
        "City Centre Mall (Sector 34)",
        "Piccadilly Square Mall (Sector 34)",
        "Fun Republic Mall, Manimajra",
        "Tribune Chowk",
        "Transport Area (Back Side Road belt)",
        "Madhya Marg", "Udyog Path", "Elante Mall", "Fun Republic", "Manimajra Market",
        "Sector 17 Plaza", "Sector 34 Market", "Sector 35 Market",
        "Ram Darbar Industrial Estate", "Sector 22 Market", "Sector 19 Market",
        "Sector 26 Madhya Marg (restaurants, offices, bars)",
        "Sector 34 Commercial Belt (coaching, banks, hotels)",
        "Sector 35 & 36 Business Zone", "Sector 8 Inner Market",
        "Manimajra Furniture Market", "Modern Housing Complex, Manimajra",
        "Burail Market (Sector 45)", "Mauli Jagran Local Market", "Bapu Dham Market",
        "Daria Local Market", "Hallo Majra Market", "DT Mall (IT Park, Manimajra)",
        "Centra Mall (Industrial Area Phase 1)", "TDI Mall (Sector 17)",
        "City Centre Mall (Sector 34)", "Piccadilly Square Mall (Sector 34)",
        "Fun Republic Mall, Manimajra", "Tribune Chowk", "Transport Area (Back Side Road belt)"
      ])
    ),
    Mohali: Array.from(
      new Set([
        ...Array.from({ length: 12 }, (_, i) => `Phase ${i + 1}`),
        ...Array.from({ length: 23 }, (_, i) => `Sector ${60 + i}`),
        "Mohali Industrial Area", "Mohali Stadium Road", "Mohali Airport Road",
        "Mohali Mall Road", "Mohali Kharar Bypass", "Sector 54", "Sector 55", "Sector 56",
        "Sector 57", "Sector 58", "Sector 59", "Sector 83", "Sector 84", "Sector 85",
        "Sector 86", "Sector 87", "Sector 88", "Sector 89", "Sector 90", "Sector 91",
        "Sector 92", "Sector 93", "Sector 94", "Sector 95", "Sector 96", "Sector 97",
        "Sector 98", "Sector 99", "Sector 100", "Kumbra", "Mohali Village", "Manak Majra",
        "Madanpur", "Daun", "Desu Majra", "Jhungian", "Jagatpura", "Jhanjeri (student hub)",
        "IT City","Sunny Enclave", "TDI City", "Sector 66-A", "Sector 82-A", "Sector 88-A",
        "Sector 115", "Sector 116", "Sector 117", "Sector 118", "Sector 119", "Sector 125",
        "Sector 126", "Sector 127", "Sector 128", "CP.67 Mall – Sector 67", "Bestech Square Mall – Sector 66",
        "VR Punjab Mall – Kharar Road", "Cosmos Plaza – Sector 62", "North Country Mall Showrooms (outside VR Punjab)",
        "TDI City Commercial – Sector 117/118", "Gillco Valley Market – Sector 115",
        "Sunny Enclave Business Centre", "Airport Road (PR-7) – Full commercial stretch",
        "Stadium Road (Sector 68–69 PCA region)", "ISBT Phase 8 Mohali Circle",
        "Purv Marg Commercial Belt", "Fateh Burj / Chappar Chiri Road Belt (emerging commercial)",
        "Jubilee Walk – Retail & Office Complex", "Florence Plaza – Ambika Group Commercial Strip",
        "MedCity Belt – Upcoming Clinics/Health Offices", "New Chandigarh Extension (Mullanpur Road Commercial Front)"
      ])
    ),
    Panchkula: Array.from(
      new Set([
        ...Array.from({ length: 20 }, (_, i) => `Sector ${i + 1}`),
        "Industrial Area Panchkula", "Mansa Devi Complex", "Sector 5 Market",
        "Sector 10 Market", "Sector 11 Market", "Sector 12 Market",
        "Sector 21", "Sector 22", "Sector 23", "Sector 24", "Sector 25", "Sector 26",
        "Sector 27", "Sector 28", "Sector 29", "Sector 30", "Sector 31", "Sector 12A",
        "MDC Sector 4", "MDC Sector 5", "Panchkula Extension (Sector 20–21 Side)",
        "Housing Board Colony", "Indira Awas Colony", "Ramgarh Colony", "Peer Muchalla",
        "Baltana Border Area", "Majri Chowk", "Raipur Rani", "Barwala", "Amravati Enclave",
        "Green Valley Apartments (Sector 20)", "The Valley by DLF", "Panchkula Heights",
        "Sushma Villas", "Motia Heights", "Imperial Residency", "Suncity Parikrama",
        "Victoria Heights", "Urban Vatika", "Trishla City"
      ])
    )
  }
};



// Filter options
const filterOptions = {
    residential: {
        flat: {
            "BHK": ["1BHK", "2BHK", "3BHK", "4BHK", "5BHK+"],
            "Budget": ["₹10K", "₹10K - ₹15K", "₹15K - ₹20K", "₹20K - ₹25K", 
                      "₹25K - ₹30K", "₹30K - ₹35K", "₹35K - ₹45K", "₹50K+"],
            "Furnishing": ["Furnished", "Semi-Furnished", "Unfurnished"],
            "Floor": ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor+"]
        },
        room: {
            "Room Set": ["1 Room Set", "2 Room Set", "3 Room Set"],
            "Budget": ["₹5K", "₹5K - ₹8K", "₹8K - ₹12K", "₹12K - ₹18K", 
                      "₹18K - ₹25K", "₹25K - ₹35K", "₹35K - ₹50K"],
            "Furnishing": ["Furnished", "Semi-Furnished", "Unfurnished"],
            "Bathroom": ["Attached", "Shared"]
        }, 
        pg: {
            "Sharing Type": ["Single Sharing", "Double Sharing", "Triple Sharing", "Dormitory"],
            "Gender": ["Boys", "Girls", "Unisex"],
            "Food Included": ["Yes", "No"],
            "Budget": ["₹3K - ₹5K", "₹5K - ₹8K", "₹8K - ₹12K", "₹12K - ₹18K", "₹18K+"],
            "Facilities": ["AC", "WiFi", "Laundry", "Cleaning"],
			"__multi_select__": ["Facilities"] 
        },
        house: {
            "Area (sqft)": ["500-1000", "1000-1500", "1500-2000", "2000-2500", "2500+"],
            "Budget": ["₹20K - ₹30K", "₹30K - ₹45K", "₹45K - ₹60K", "₹60K+"],
            "Furnishing": ["Furnished", "Semi-Furnished", "Unfurnished"],
            "Bedrooms": ["2", "3", "4", "5+"],
            "Parking": ["1 Car", "2 Cars", "3+ Cars"]
        }
    },
    commercial: {
        office: {
            "Type": ["Cabin"],
            "Area (sqft)": ["<500", "500-1000", "1000-2000", "2000-5000", "5000+"],
            "Budget": ["₹20K", "₹20K-₹50K", "₹50K-₹1L", "₹1L-₹2L", "₹2L+"],
            "Lease Type": ["Monthly", "Quarterly", "Yearly"],
			"Furnishing": ["Furnished", "Semi-Furnished", "Unfurnished"],
            "Facilities": ["Parking", "AC", "Lift", "Security", "Pantry","Conference Hall"],
			"Cabins":["0","1","2","3","5","7","10+"],
			"Open Space Option":["Standard Partitioned Space","Open Workspace","Bare Shell(Full Floor, No Setup)"],
			"Prefered Floor":["Ground Floor","First Floor","Second Floor", "3RD Floor","4TH Floor","5+"],
			"Seating Capacity":[ "0","1 - 5","6 - 10","11 - 20","20+",],
			
			"__multi_select__": ["Facilities"] 
        },
        shop: {
            "Type": ["Showroom", "Booth", "SCO", "High Street Shop", "Mall Space"],
            "Area (sqft)": ["<200", "200-500", "500-1000", "1000-2000", "2000+"],
            "Budget": ["₹15K", "₹15K-₹30K", "₹30K-₹50K", "₹50K-₹1L", "₹1L+"],
            "Footfall": ["Low", "Medium", "High"],
            "Visibility": ["Main Road", "Side Road", "Inside Market"]
        },
        warehouse: {
            "Type": ["Godown", "Cold Storage", "Industrial Space", "Logistics Park"],
            "Area (sqft)": ["<2000", "2000-5000", "5000-10000", "10000-20000", "20000+"],
            "Budget": ["₹50K", "₹50K-₹1L", "₹1L-₹2L", "₹2L-₹5L", "₹5L+"],
            "Ceiling Height": ["<10ft", "10-15ft", "15-20ft", "20ft+"],
            "Loading Facilities": ["Dock", "Ramp", "Crane"]
        }
    }
};

// Current selections
let urlParams = new URLSearchParams(window.location.search);

let currentSelections = {
    propertyType: urlParams.get('subcat_id'), // ✅ Syntax fixed (semicolon → comma)
    city: null,
    area: null,
    category: null,
    subcategory: null
};


// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    // Load Font Awesome if not already loaded
    if (!document.querySelector('link[href*="font-awesome"]')) {
        const faLink = document.createElement('link');
        faLink.rel = 'stylesheet';
        faLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
        document.head.appendChild(faLink);
    }

    // Get subcat_id from URL
    const urlParams = new URLSearchParams(window.location.search);
    const subcatId = urlParams.get('subcat_id');


    // Show section based on subcat_id
    if (subcatId === '99') {
        showSection('commercial');
    } else {
        showSection('residential'); // default fallback
    }
});


// Show the selected section
function showSection(sectionId) {
	//alert(sectionId);
    document.querySelectorAll('.section').forEach(el => el.style.display = 'none');
    document.getElementById(sectionId).style.display = 'block';
    
    // Update button states
    document.querySelectorAll('.main-button').forEach(btn => {
        btn.classList.remove('active-button');
    });
    
    if (sectionId === 'residential') {
        document.querySelector('.primary-button').classList.add('active-button');
    } else {
        document.querySelector('.secondary-button').classList.add('active-button');
    }
    
    // Reset selections when switching property types
    currentSelections.propertyType = sectionId;
    currentSelections.city = null;
    currentSelections.area = null;
    currentSelections.category = null;
    currentSelections.subcategory = null;
    
    // Hide location selectors and results
    document.getElementById(`${sectionId}-location-selector`).style.display = 'none';
    document.getElementById(`${sectionId}-selected-location`).textContent = '';
    document.getElementById(`${sectionId}-property-options`).style.display = 'none';
    document.getElementById(`${sectionId}-filter-panel`).style.display = 'none';
    
    if (sectionId === 'commercial') {
        document.getElementById('commercial-categories').style.display = 'none';
        document.getElementById('commercial-subcategories').style.display = 'none';
    }
    
    // Hide results section
    document.getElementById('property-results').style.display = 'none';
}

// Select city
function selectCity(city, propertyType) {
    currentSelections.city = city;
    currentSelections.area = null;
    
    // Update active city button
    document.querySelectorAll(`#${propertyType} .city-button`).forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Populate sectors list
    const areaList = document.getElementById(`${propertyType}-area-list`);
    areaList.innerHTML = '';
    
    propertyData[propertyType][city].forEach(area => {
        const sectorItem = document.createElement('div');
        sectorItem.className = 'sector-item';
        sectorItem.textContent = area;
        sectorItem.onclick = function() {
            selectArea(area, propertyType);
        };
        areaList.appendChild(sectorItem);
    });
    
    // Show location selector
    document.getElementById(`${propertyType}-location-selector`).style.display = 'block';
    
    // Update selected location display
    document.getElementById(`${propertyType}-selected-location`).textContent = `Selected City: ${city}`;
    
    // Hide property options and filters
    document.getElementById(`${propertyType}-property-options`).style.display = 'none';
    document.getElementById(`${propertyType}-filter-panel`).style.display = 'none';
    
    if (propertyType === 'commercial') {
        document.getElementById('commercial-categories').style.display = 'none';
        document.getElementById('commercial-subcategories').style.display = 'none';
    }
    
    // Hide results
    document.getElementById('property-results').style.display = 'none';
}

// Select area
function selectArea(area, propertyType) {
    currentSelections.area = area;
    
    // Update active sector item
    document.querySelectorAll(`#${propertyType}-area-list .sector-item`).forEach(item => {
        item.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update selected location display
    document.getElementById(`${propertyType}-selected-location`).textContent = 
        `Selected Location: ${currentSelections.city} - ${area}`;
    
    // Show property options
    if (propertyType === 'residential') {
        document.getElementById(`${propertyType}-property-options`).style.display = 'block';
    } else {
        document.getElementById('commercial-categories').style.display = 'flex';
    }
    
    // Hide filters
    document.getElementById(`${propertyType}-filter-panel`).style.display = 'none';
}

// Filter areas based on search input
function filterAreas(propertyType) {
    const input = document.getElementById(`${propertyType}-search`).value.toLowerCase();
    const items = document.querySelectorAll(`#${propertyType}-area-list .sector-item`);
    
    items.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(input) ? 'block' : 'none';
    });
}

// Show commercial subcategories
function showCommercialSubcategories(category) {
    currentSelections.category = category;
    
    const subcategoriesDiv = document.getElementById('commercial-subcategories');
    subcategoriesDiv.innerHTML = '';
    
    // Get the subcategories from the filter options
    const subcategories = filterOptions.commercial[category]['Type'];
    
    subcategories.forEach(subcategory => {
        const btn = document.createElement('button');
        btn.className = 'subcategory-button';
        btn.textContent = subcategory;
        btn.onclick = function() {
            selectCategoryType('commercial', category, subcategory);
        };
        subcategoriesDiv.appendChild(btn);
    });
    
    subcategoriesDiv.style.display = 'flex';
    document.getElementById('commercial-filter-panel').style.display = 'none';
}

function selectCategoryType(propertyType, category, subcategory = null) {
    currentSelections.category = category;
    currentSelections.subcategory = subcategory;

    const panel = document.getElementById(`${propertyType}-filter-panel`);
    panel.innerHTML = '';

    const categoryFilters = filterOptions[propertyType][category];

    // Create filter groups
    for (const [label, options] of Object.entries(categoryFilters)) {
        if (propertyType === 'commercial' && label === 'Type') continue;
        if (label === '__multi_select__') continue;

        const group = document.createElement('div');
        group.className = 'filter-group';

        const labelEl = document.createElement('label');
        labelEl.textContent = label;

        const isMultiSelect = categoryFilters.__multi_select__?.includes(label);

        if (isMultiSelect) {
            group.appendChild(labelEl);

            const checkboxContainer = document.createElement('div');
            checkboxContainer.className = 'checkbox-container';

            options.forEach(option => {
                const checkboxLabel = document.createElement('label');
                checkboxLabel.style.display = 'block';
                checkboxLabel.style.marginBottom = '5px';

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.name = label.toLowerCase().replace(/\s+/g, '_') + '[]';
                checkbox.value = option;

                checkboxLabel.appendChild(checkbox);
                checkboxLabel.appendChild(document.createTextNode(' ' + option));

                checkboxContainer.appendChild(checkboxLabel);
            });

            group.appendChild(checkboxContainer);
        } else {
            const select = document.createElement('select');
            select.name = label.toLowerCase().replace(/\s+/g, '_');

            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Select ' + label;
            select.appendChild(defaultOption);

            options.forEach(option => {
                const optionEl = document.createElement('option');
                optionEl.value = option;
                optionEl.textContent = option;
                select.appendChild(optionEl);
            });

            group.appendChild(labelEl);
            group.appendChild(select);
        }

        panel.appendChild(group);
    }

    // Add action buttons
    const actions = document.createElement('div');
    actions.className = 'filter-actions';

    const applyBtn = document.createElement('button');
    applyBtn.className = 'action-button apply-button';
    applyBtn.textContent = 'Apply Filters';
    applyBtn.onclick = applyFilters;

    const resetBtn = document.createElement('button');
    resetBtn.className = 'action-button reset-button';
    resetBtn.textContent = 'Reset';
    resetBtn.onclick = resetFilters;

    actions.appendChild(resetBtn);
    actions.appendChild(applyBtn);
    panel.appendChild(actions);

    panel.style.display = 'flex';

    if (propertyType === 'commercial') {
        document.getElementById(`${propertyType}-selected-location`).textContent =
            `Selected: ${currentSelections.city} - ${currentSelections.area} (${category}: ${subcategory})`;
    }
}


// Apply filters and load properties
function applyFilters() {
    const propertyType = currentSelections.propertyType;
    const panel = event.target.closest('.filter-panel');
    const selects = panel.querySelectorAll('select');
	 const checkboxes = panel.querySelectorAll('input[type="checkbox"]:checked');
    let filters = {};
	// Get subcategory ID from URL if it exists
    const urlParams = new URLSearchParams(window.location.search);
    const subcategoryId = urlParams.get('subcat_id') || '';
    
    selects.forEach(select => {
        const label = select.previousElementSibling.textContent;
        if (select.value) {
             // Create a URL-friendly key for the filter
            const filterKey = label.toLowerCase().replace(/[^a-z0-9]+/g, '_');
            filters[filterKey] = encodeURIComponent(select.value);
        }
    });
	// Handle checkbox filters (for PG Facilities and other multi-select options)
    const checkboxGroups = {};
    checkboxes.forEach(checkbox => {
        const groupName = checkbox.name.replace('[]', '');
        if (!checkboxGroups[groupName]) {
            checkboxGroups[groupName] = [];
        }
        checkboxGroups[groupName].push(encodeURIComponent(checkbox.value));
    });
    
    // Add checkbox groups to filters
    for (const [groupName, values] of Object.entries(checkboxGroups)) {
        filters[groupName] = values.join(',');
    }
	 // Build the base URL for the results page
    let resultsUrl = '/property-results/?';
       // Add main parameters
    resultsUrl += `property_type=${encodeURIComponent(currentSelections.propertyType)}`;
    resultsUrl += `&city=${encodeURIComponent(currentSelections.city)}`;
	
    resultsUrl += `&area=${encodeURIComponent(currentSelections.area)}`;
      // Add category and subcategory if they exist
    if (currentSelections.category) {
        resultsUrl += `&category=${encodeURIComponent(currentSelections.category)}`;
    }
    if (currentSelections.subcategory) {
        resultsUrl += `&subcategory=${encodeURIComponent(currentSelections.subcategory)}`;
    }
	 // Add subcategory ID from original URL if it exists
    if (subcategoryId) {
        resultsUrl += `&subcat_id=${encodeURIComponent(subcategoryId)}`;
    }
    
    // Add filters as URL parameters
    for (const [key, value] of Object.entries(filters)) {
        resultsUrl += `&${key}=${value}`;
    }
    
    // Redirect to the results page with all parameters
    window.location.href = resultsUrl;
    // Update results heading
    let heading = `Properties in ${currentSelections.city} - ${currentSelections.area}`;
    if (currentSelections.category) {
        heading += ` (${currentSelections.category}`;
        if (currentSelections.subcategory) {
            heading += `: ${currentSelections.subcategory}`;
        }
        heading += ')';
    }
    document.getElementById('results-heading').textContent = heading;
    
    // Prepare data for AJAX request
    const requestData = {
        action: 'get_properties_by_location',
        property_type: currentSelections.propertyType,
        city: currentSelections.city,
        area: currentSelections.area,
        category: currentSelections.category,
        subcategory: currentSelections.subcategory,
        filters: filters
    };
    
    // Make AJAX request to WordPress
    jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', requestData, function(response) {
        if (response.success && response.data.length > 0) {
            displayPropertyResults(response.data);
        } else {
            document.getElementById('property-results-container').innerHTML = 
                '<p class="no-properties">No properties found matching your criteria. Please try different filters.</p>';
        }
    }).fail(function() {
        document.getElementById('property-results-container').innerHTML = 
            '<p class="error-message">Error loading properties. Please try again.</p>';
    });
}

// Reset filters
function resetFilters() {
    const panel = event.target.closest('.filter-panel');
    const selects = panel.querySelectorAll('select');
    
    selects.forEach(select => {
        select.selectedIndex = 0;
    });
}

// Display property results
function displayPropertyResults(properties) {
    const container = document.getElementById('property-results-container');
    let html = '<div class="property-results-grid">';
    
    properties.forEach(property => {
        html += `
            <div class="property-card">
                <div class="property-image" style="background-image: url('${property.image}')"></div>
                <div class="property-details">
                    <h3 class="property-title">${property.title}</h3>
                    <div class="property-price">${property.price}</div>
                    <div class="property-meta">
                        <span><i class="fas fa-map-marker-alt"></i> ${property.location}</span>
                        <span><i class="fas fa-home"></i> ${property.type}</span>
                    </div>
                    <div class="property-description">${property.excerpt}</div>
                    <a href="${property.link}" class="property-link">View Property</a>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}
</script>

<?php
// Add AJAX handler for property search
add_action('wp_ajax_get_properties_by_location', 'get_properties_by_location');
add_action('wp_ajax_nopriv_get_properties_by_location', 'get_properties_by_location');

function get_properties_by_location() {
    // Verify nonce for security
    // if (!wp_verify_nonce($_POST['nonce'], 'property_search_nonce')) {
    //     wp_send_json_error('Invalid request');
    // }
    
    $property_type = sanitize_text_field($_POST['property_type'] ?? '');
    $city = sanitize_text_field($_POST['city'] ?? '');
    $area = sanitize_text_field($_POST['area'] ?? '');
    $category = sanitize_text_field($_POST['category'] ?? '');
    $subcategory = sanitize_text_field($_POST['subcategory'] ?? '');
    $filters = $_POST['filters'] ?? [];
    
    // Prepare the meta query
    $meta_query = [
        'relation' => 'AND',
        [
            'key' => 'property_type',
            'value' => $property_type,
            'compare' => '='
        ],
        [
            'key' => 'location_city',
            'value' => $city,
            'compare' => '='
        ],
        [
            'key' => 'location_area',
            'value' => $area,
            'compare' => '='
        ]
    ];
    
    // Add category filter if provided
    if ($category) {
        $meta_query[] = [
            'key' => 'property_category',
            'value' => $category,
            'compare' => '='
        ];
    }
    
    // Add subcategory filter if provided
    if ($subcategory) {
        $meta_query[] = [
            'key' => 'property_subcategory',
            'value' => $subcategory,
            'compare' => '='
        ];
    }
    
    // Add additional filters
    foreach ($filters as $filter_key => $filter_value) {
        $meta_query[] = [
            'key' => sanitize_key($filter_key),
            'value' => sanitize_text_field($filter_value),
            'compare' => '='
        ];
    }
    
    $args = [
        'post_type' => 'product', // Change to 'product' if using WooCommerce
        'posts_per_page' => -1,
        'meta_query' => $meta_query,
        'orderby' => 'date',
        'order' => 'DESC'
    ];
    //echo"<pre>";print_r($args);die;
    $query = new WP_Query($args);
    $results = [];
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            
            $results[] = [
                'title' => get_the_title(),
                'link' => get_permalink(),
                'image' => get_the_post_thumbnail_url($post_id, 'large') ?: get_template_directory_uri() . '/images/default-property.jpg',
                'price' => get_field('price') ? '₹' . number_format(get_field('price')) : 'Price on Request',
                'location' => get_field('location_area') . ', ' . get_field('location_city'),
                'type' => get_field('property_type'),
                'category' => get_field('property_category'),
                'subcategory' => get_field('property_subcategory'),
                'excerpt' => wp_trim_words(get_the_excerpt(), 20)
            ];
        }
        wp_reset_postdata();
    }
    
    wp_send_json_success($results);
}

get_footer();
?>