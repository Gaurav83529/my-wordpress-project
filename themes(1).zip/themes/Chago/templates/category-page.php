<?php

/**
 * Template Name:Service Categories Template
 * Description: A custom template to display WooCommerce product categories.
 */
get_header(); // Include the header
// Start output buffering
ob_start();
?>
<div class="service-content">
    <div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="headingOther">
					<h2>Categories</h2>
				</div>
			</div>
		</div>
        <div class="row">
            <?php
            // Get all product categories
            $args = array(
                'taxonomy'   => 'product_cat',
                'orderby'    => 'name',
                'hide_empty' => false, // Show empty categories as well
                'parent'     => 0,     // Fetch only top-level categories
                'exclude'    => array(23),
            );

            $categories = get_terms($args);

            // The Loop
            if (!empty($categories) && !is_wp_error($categories)) {
                foreach ($categories as $category) {
                    // Get the category image (thumbnail)
                    $category_image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                    $category_image_url = $category_image_id
                        ? wp_get_attachment_url($category_image_id)
                        : get_template_directory_uri() . '/images/default.png'; // Replace with your default image path

                    // Get the category link
                    // Link to the category, passing the category ID as a query parameter
                    $category_link = get_permalink(get_page_by_path('sub-categories')) . '?cat_id=' . $category->term_id;
            ?>
                    <div class="col-lg-3 col-md-4 col-sm-12  mb-4">
                        <div class="inner-booked-service inner-services1">
                            <!-- Display category image -->
							<a href="<?php echo esc_url($category_link); ?>">
                                <img src="<?php echo esc_url($category_image_url); ?>" class="img-fluid" alt="<?php echo esc_attr($category->name); ?>" />
                            </a>
                            <div class="content-services-about">
                                <!-- Display category title -->
                                <a href="<?php echo esc_url($category_link); ?>">
                                    <h4><?php echo esc_html($category->name); ?></h4></a>
                                <!-- Display category description (if available) -->
                                <?php if (!empty($category->description)) : ?>
                                  <div class="service-description"><p><?php echo esc_html(wp_strip_all_tags($category->description)); ?><p></div>
                             
                                <?php endif; ?>
                                <!-- Link to the category -->
                                <div class="price-book-now">
                                <a href="<?php echo esc_url($category_link); ?>" class="btn">View Services</a>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p>No categories found.</p>';
            }
            ?>
        </div>
    </div>
</div>

<?php
// End output buffering
$content = ob_get_clean();
echo $content; // Output the content to the page
get_footer(); // Include the footer
?>