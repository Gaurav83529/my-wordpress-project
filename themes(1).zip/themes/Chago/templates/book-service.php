<?php

/**
 * Template Name: Book Service
 */
get_header(); // Include the header
// Fetch the current user information (if logged in)
$current_user = wp_get_current_user();
$user_full_name = $current_user->first_name . ' ' . $current_user->last_name;
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

if ($product_id) {
    // Fetch the WooCommerce product using the product ID
    $product = wc_get_product($product_id);
    if ($product) {
        // Get product details
       // echo '<pre>';print_r($product); echo '</pre>';die;
        $product_name = $product->get_name();
        $product_short_description = $product->get_short_description();
		$product_description = $product->get_description();
        $product_price = $product->get_price();
        $product_thumbnail = get_the_post_thumbnail_url($product_id, 'full'); // Get product thumbnail
        $product_categories = wp_get_post_terms($product_id, 'product_cat'); // Get product categories
        $product_area = get_post_meta($product_id, '_product_area', true);
        // Extract the category IDs for related product queries
        $category_ids = wp_list_pluck($product_categories, 'term_id');
?>

        <!--<div class="book-services-section">-->
        <!--    <h1 class="page-title">Book a Service: 
        <?php //echo esc_html($product_name); 
        ?>
        </h1>-->
        <!--</div>-->

        <div class="productsMain">
            <div class="container">
                <div class="row image-book">
                    <div class="col-xs-12 col-md-5 img-servc-bk">
                        
                            <img src="<?php echo esc_url( !empty($product_thumbnail) ? $product_thumbnail : get_template_directory_uri() . '/images/default.png' ); ?>" alt="Product Thumbnail" class="service-thumbnail" />
                        
                    </div>
                    <div class="col-xs-12 col-md-7 service-bok-content">
                        <div>
                            <h2><?php echo esc_html($product_name); ?></h2>
                            <div class="wishlist-item">
                            <?php 
                            if ( is_user_logged_in() ) {
                                echo do_shortcode('[yith_wcwl_add_to_wishlist product_id="' . $product_id . '"]');
                            } else {
                                echo '<a href="/login" class="wishlist-login-link">Login to add to wishlist</a>';
                            }     
                            ?>
                        </div>

                        </div>
                        <?php
                            if ($product_area) {
                                echo ' ' . '<small>(' . $product_area . ')sqft</small>';
                            } ?>
                            <?php do_shortcode('[wpcr_average_and_total_reviews]'); ?>
                            
                            <p><?php echo esc_html($product_short_description); ?>
                            </p>

                            <span class="pricebook">Price:&nbsp;₹<?php echo esc_html($product_price); ?></span>

                            <div class="service-bok-content-form">
                                <form id="book-service-form" method="post" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>">

                                    <!-- Product Information (Hidden) -->
                                    <input type="hidden" name="product_name" value="<?php echo esc_attr($product_name); ?>" />
                                    <input type="hidden" name="product_id" value="<?php echo esc_attr($product_id); ?>" />
                                    <input type="hidden" name="product_price" value="<?php echo esc_attr($product_price); ?>" />
                                    <div class="date-time-selection">
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                                <!-- Bookly Form Integration -->
                                                <?php echo '<div class="container"><h2>Pick Date & Time</h2>' . do_shortcode('[bookly-form]') . '</div>'; ?>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        if ($product) {
            // Query the Bookly service table to get the Bookly service ID associated with this product
            global $wpdb;
            $bookly_service_id = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}bookly_services WHERE wc_product_id = %d",
                    $product_id
                )
            );
        } else {
            error_log('Query the Bookly service table to get the Bookly service ID associated with this product not working');
        }
        ?>

        
        <!-- Related Products Section -->
                <section class="booked-services moreFeatures">
                    <div class="container">
<!--Tabs section-->
<div class="bookservice-tabs">
			<div class="row">
			<div class="col-lg-12">
				<div class="headingOther">
					<h2>More Services From Us</h2>
				</div>
			</div>
		</div> 
    <ul class="tab-titles">
        <li class="tab-title active" data-tab="description">Description</li>
        <li class="tab-title" data-tab="reviews">Reviews</li> 
    </ul>

    <div class="bookservice-tab-content">
        <div id="description" class="tab-pane active">
            
             <p><?php echo $product_description; ?></p>
        </div>
        <div id="reviews" class="tab-pane">
            
           <div class="reviews-section">
            <div class="container">
                <?php if (is_user_logged_in()): ?>

                    <?php echo do_shortcode('[WPCR_SHOW POSTID="' . $product_id . '" NUM="10" SHOWFORM="1"]'); ?>
                <?php else: ?>
                    <?php echo do_shortcode('[WPCR_SHOW POSTID="' . $product_id . '" NUM="10" SHOWFORM="0"]'); ?>
                    <!-- If the user is not logged in, show a prompt to log in -->
                    <p>You need to <a href="<?php echo wp_login_url(get_permalink()); ?>">log in</a> to submit a review.</p>
                <?php endif; ?>
            </div>
        </div>
        </div>
      <!-- <div id="vendor-info" class="tab-pane">
            <h2>Vendor Info</h2>
            <p>Content for the vendor info tab.</p>
        </div>
        <div id="more-products" class="tab-pane">
            <h2>More Products</h2>
            <p>Content for the more products tab.</p>
        </div>--!>
    </div>
</div>

                         <div class="owl-carousel b-service-owl-slider-new">
            <?php
            // Get all product categories
            $categories = get_terms(array(
                'taxonomy'   => 'product_cat', // The taxonomy for product categories
                'orderby'    => 'name',        // Order categories by name
                'hide_empty' => false,         // Show empty categories as well
                'parent'     => 0,
                 'exclude'    => array(23),
            ));

            if (! empty($categories) && ! is_wp_error($categories)) {
                // Loop through each category
                foreach ($categories as $category) {
                    // Get the category name
                    $category_name = $category->name;

                    // Get the category image (thumbnail)
                    $category_image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                    $category_link = get_permalink(get_page_by_path('sub-categories')) . '?cat_id=' . $category->term_id;

                    // Fallback image URL if no image is found
                    $category_image_url = $category_image_id
                        ? wp_get_attachment_url($category_image_id)
                        : get_template_directory_uri() . '/images/default.png'; // Replace with your default image path
            ?>
                    <div class="item"> <!-- Each category becomes its own slide -->
                        <div class="inner-booked-service">
                            <!-- Display category image -->
                            <a href="<?php echo esc_url($category_link)?>">
                            <img src="<?php echo esc_url($category_image_url); ?>" alt="<?php echo esc_attr($category_name); ?>" class ="img-fluid" /></a>

                            <!-- Display category name -->
                            <h4><?php echo esc_html($category_name); ?></h4></a>
                            <!-- Book Now Button -->
                            <div class="price-book-now">
                                <a href="<?php echo esc_url($category_link)?>" class="btn btn-primary">Explore</a>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '';
            }
            ?>
        </div>
                    </div>
                </section>

        <?php
    } else {
        echo '<p>Sorry, the product you are looking for is not available.</p>';
    }
} else {
    echo '<p>Invalid product ID.</p>';
}
        ?>

        <?php get_footer(); // Include the footer 
        ?>
        <script>
            $(document).ready(function() {
                $('.owl-carousel.b-service-owl-slider-new').owlCarousel({
                    margin: 8,
                    dots: false,
                   // center: true,
                    loop: true,
                    autoplay: true,
                    nav: true,
                    navText: ["<img src='<?php echo get_template_directory_uri(); ?>/images/left-icon.png'/>", "<img src='<?php echo get_template_directory_uri(); ?>/images/right-icon.png'/>"],
                    responsive: {
                        0: {
                            items: 1,
                            margin: 10
                        },

                        575: {
                            items: 2,
                            margin: 10
                        },

                        768: {
                            items: 3,
                            margin: 10
                        },
                        992: {
                            items: 4,
                            margin: 11
                        }
                    }
                })
            })
        </script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Get the logged-in user's name using PHP
                var userName = '<?php echo esc_js($user_full_name); ?>';

                // Attach a click event to the button with classes wpcr3_button_1 wpcr3_show_btn
                $(document).on('click', '.wpcr3_button_1.wpcr3_show_btn', function() {
                    // Get the review name field
                    var reviewNameField = $('#wpcr3_fname');

                    // Check if the review name field is empty before populating it
                    if (reviewNameField.length && !reviewNameField.val()) {
                        reviewNameField.val(userName); // Set the reviewer's name to the logged-in user's name
                        console.log('Populated review name field with user name:', userName);
                    }
                });
            });
        </script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Get the Bookly service ID from PHP
                var booklyServiceId = <?php echo json_encode($bookly_service_id); ?>;
                console.log("Bookly Service ID:", booklyServiceId);
				
				function timeOutFallBack(booklyServiceId){
					var selectElement = document.querySelector('.bookly-form-group[data-type="service"] select');

                    console.log("Select element:", selectElement);

                    if (selectElement) {
                        console.log("Available options:", selectElement.options);

                        selectElement.value = booklyServiceId;

                        console.log("Selected option value:", selectElement.value);

                        var event = new Event('change');
                        selectElement.dispatchEvent(event);

                        console.log("Change event triggered.");
                    } else {
                        console.log("Select element not found.");
                    }

                    selectElement.addEventListener('change', function() {
                        console.log("Option selected: " + selectElement.value);
				});
				}
				var checkInterval = setInterval(function(){
					if($('.bookly-form-group[data-type="service"] select')){
						var serviceValue = $('.bookly-form-group[data-type="service"] select').val();
						if(serviceValue==0){
							console.log('selected');
							timeOutFallBack(booklyServiceId);
							clearInterval(checkInterval);
						}
					}
				});
                setTimeout(function() {
					//timeOutFallBack(booklyServiceId);
                    
                }, 2000);
            });
        </script>
<script>
    document.querySelectorAll('.tab-title').forEach(tab => {
    tab.addEventListener('click', function() {
        const targetTab = this.getAttribute('data-tab');

        // Remove active class from all tabs and content
        document.querySelectorAll('.tab-title').forEach(title => title.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));

        // Add active class to the clicked tab and corresponding content
        this.classList.add('active');
        document.getElementById(targetTab).classList.add('active');
    });
});

</script>
<style>
    .tabs {
    width: 100%;
    margin-top: 20px;
}

.tab-titles {
    display: flex;
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.tab-title {
    padding: 10px 20px;
    cursor: pointer;
    font-weight: bold;
    margin-right: 5px;
    transition: background-color 0.3s ease;
    position: relative;
}

.tab-title.active {
    background-color: #f0f0f0;
}

.tab-title:hover {
    background-color: #f5f5f5;
}

.tab-title.active::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: -5px; /* Adjust the space below the tab */
    width: 100%;
    height: 3px; /* Thickness of the line */
    background-color: #000; /* Line color */
}

.bookservice-tab-content {
    margin-top: 20px;
}

.tab-pane {
    display: none;
}

.tab-pane.active {
    display: block;
}

.tab-pane h2 {
    font-size: 1.5em;
    margin-bottom: 10px;
}
</style>