<?php
/**
 * Template Name: Wishlist Page
 */
get_header(); // Include the header
?>

<style>
/* Style the ordered list and list items */
.wishlist-items-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

/* Each list item */
.wishlist-product-item {
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ddd;
    padding: 15px 0;
}

/* Style the serial number */
.wishlist-product-item .serial-number {
    font-size: 16px;
    margin-right: 10px;
    font-weight: bold;
}

/* Style the product thumbnail */
.wishlist-product-item .product-thumbnail img {
    width: 80px;  /* Adjust image size */
    height: 80px;
    object-fit: cover;
    margin-right: 15px;
}

/* Style the product details */
.wishlist-product-item .product-details {
    flex: 1; /* Take up remaining space */
}

/* Style the product name */
.wishlist-product-item .product-details h3 {
    font-size: 18px;
    margin: 0;
    margin-bottom: 5px;
}

/* Style the price */
.wishlist-product-item .product-details p {
    font-size: 16px;
    margin-bottom: 10px;
}
</style>
<section class="wishlistMain">
<?php

// Get the current user ID
$current_user_id = get_current_user_id();

// Check if user is logged in
if ($current_user_id > 0) {
    
    // Get wishlist items for the current user
    $wishlist = YITH_WCWL_Wishlists()->get_wishlists(); // Fetch the wishlists for the current user
    
    // Check if the wishlist is not empty
    $wishlist_is_empty = true; // Flag to check if wishlist has items
    
    if (!empty($wishlist)) {
        echo '<div class="container">';
        // Start an ordered list for the wishlist items
        echo '<ol class="wishlist-items-list">';
        
        // Loop through the wishlists
        foreach ($wishlist as $list) {
            // Loop through the wishlist items
            $items = $list->get_items(); // Get all items from the wishlist

            if (!empty($items)) {
                $wishlist_is_empty = false; // If items are found, set flag to false
                
                foreach ($items as $item) {
                    $product_id = $item->get_product_id(); // Get the product ID from wishlist item
                    $product = wc_get_product($product_id); // Get the product object
                    
                    if ($product) {
                        $product_name = $product->get_name();
                        $product_thumbnail = get_the_post_thumbnail_url($product_id, 'thumbnail');
						$default_image = get_template_directory_uri() . '/images/default.png';
						$product_image = !empty($product_thumbnail) ? $product_thumbnail : $default_image;
                        $product_price = $product->get_price();
                        
                        // Display product info in <li> tag with serial number
                        echo '<li class="wishlist-product-item">';
                        
                        // Product thumbnail
                        echo '<div class="product-thumbnail">';
                        if ($product_thumbnail) {
                            echo '<img src="' . esc_url($product_thumbnail) . '" alt="' . esc_attr($product_name) . '">';
                        }
                        echo '</div>';

                        // Product details
                        echo '<div class="product-details">';
                        echo '<h3>' . esc_html($product_name) . '</h3>';
                        echo '<p>Price: ₹' . esc_html($product_price) . '</p>';
                        
                        // Remove button wrapped in a form
                        echo '<form method="POST" action="' . esc_url( get_permalink() ) . '">';
                        wp_nonce_field( 'remove_from_wishlist', 'remove_wishlist_nonce' ); // Security field
                        echo '<input type="hidden" name="product_id" value="' . esc_attr( $product_id ) . '">';
                        echo '<button type="submit" class="btn btn-primary" name="remove_from_wishlist">Remove</button>';
                        echo '</form>';

                        // Book service link with product ID in query
                        $book_service_url = add_query_arg('product_id', $product_id, get_permalink(get_page_by_path('book-service')));
                        echo '<a href="' . esc_url($book_service_url) . '" class="btn btn-primary btnBook">Book Service</a>';

                        echo '</div>';
                        echo '</li>';
                    }
                }
            }
        }
        
        echo '</ol>';
        echo '</div>';
    } 
    
    // Check if the wishlist is empty
    if ($wishlist_is_empty) {
        echo '<div class="container">';
        echo '<p class="emptyWishlist">Your wishlist is empty.</p>';
        echo '</div>';
    }

} else {
    echo '<p>You need to log in to view your wishlist. <a href="' . home_url('/login') . '">Login here</a>.</p>';
}
echo "</section>";
get_footer(); // Include the footer
?>
