<?php
/*
Template Name: Service Provider Registration
*/

$message = '';  // Variable to store success or error messages

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and assign form data to variables
    //echo "fsdlfk"; print_r($_POST);die;
    $name = sanitize_text_field($_POST['dname']);
    $phone = sanitize_text_field($_POST['phone']);
    $email = sanitize_email($_POST['email']) ?: $phone . '@chago.in';  // Optional email field, defaults to phone + @chago.in
    $password = sanitize_text_field($_POST['password']);
    $confirm_password = sanitize_text_field($_POST['confirm_password']);
    $vehicle_availability = sanitize_text_field($_POST['vehicle_availability']);
   // $address = sanitize_textarea_field($_POST['address']);
	$house_area = sanitize_text_field($_POST['house_area']);
    $gali_sector = sanitize_text_field($_POST['gali_sector']);
    $city = sanitize_text_field($_POST['city']);
    $pin_code = sanitize_text_field($_POST['pin_code']);
	
	//<input type="hidden" name="form_type" value="service_provider" />
	 $service_provider_form = sanitize_text_field($_POST['form_type']);
	    
	// Combine the new address fields into a full address string
	$full_address = $house_area . ', ' . $gali_sector . ', ' . $city . ' - ' . $pin_code;

	// Get eLoc using the new address structure
	$eloc = get_eloc_from_mapmyindia($full_address);

    // echo"<pre>";print_r($eloc);die;
	$confirmation = isset($_POST['confirmation']) ? 'Yes' : 'No';
    $account_number = sanitize_text_field($_POST['account_number']);
    $account_name = sanitize_text_field($_POST['account_name']);
	$ifsc_code = sanitize_text_field($_POST['ifsc_code']);
    $selected_category_id = isset($_POST['product_category']) ? intval($_POST['product_category']) : 0;

	$provider_latitude = floatval($_POST['provider_latitude']);
	$provider_longitude = floatval($_POST['provider_longitude']);
    // Validate that passwords match
    if ($password !== $confirm_password) {
        $message = "<p style='color: red;'>Passwords do not match.</p>";
    } else {
        // Check if the phone number already exists as a username
        if (username_exists($phone)) {
            $message = "<p style='color: red;'>This mobile number is already registered. Please use a different number.</p>";
        } else {
            // Create a new user using the mobile number as the username
            $user_id = wp_create_user($phone, $password, $email);

            if (is_wp_error($user_id)) {
                $message = "<p style='color: red;'>There was an error creating your account. Please try again.</p>";
            } else {
                // Successfully created the user, now set additional user meta fields
                wp_update_user(array(
                    'ID' => $user_id,
                    'display_name' => $name,  // Set the user's display name to the provided name
                ));

                // Split the name into first and last name
                $name_parts = explode(' ', $name);
                $first_name = $name_parts[0];
                $last_name = isset($name_parts[1]) ? $name_parts[1] : ''; // Handle case where there is no last name

                // Set the first and last name
                wp_update_user(array(
                    'ID' => $user_id,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                ));
                // Store additional user metadata (specialization, vehicle availability, etc.)
                update_user_meta($user_id, 'phone', $phone);
                update_user_meta($user_id, 'vehicle_availability', $vehicle_availability);
               // update_user_meta($user_id, 'address', $address);
                update_user_meta($user_id, 'ur_user_status', 0);
                update_user_meta($user_id, 'account_name', $account_name);
                update_user_meta($user_id, 'account_number', $account_number);
                update_user_meta($user_id, 'selected_category_id', $selected_category_id);
				update_user_meta($user_id, 'provider_latitude', $provider_latitude);
				update_user_meta($user_id, 'provider_longitude', $provider_longitude);
				update_user_meta($user_id, 'provider_eloc', $eloc);
                update_user_meta($user_id, 'house_area', $house_area);
                update_user_meta($user_id, 'gali_sector', $gali_sector);
                update_user_meta($user_id, 'city', $city);
                update_user_meta($user_id, 'pin_code', $pin_code);
                update_user_meta($user_id, 'address', $full_address);  
				update_user_meta($user_id, 'service_provider_form',$service_provider_form );
			
                
                // Assign "Service Provider" role to the user
                $user = new WP_User($user_id);
                $user->set_role('services_provider');  // Custom role "service_provider"

                // Handle individual file uploads
                $profile_image = handle_file_upload('profile_image', $user_id);
                $adhaar_front_image = handle_file_upload('adhaar_upload_front', $user_id);
                $adhaar_back_image = handle_file_upload('adhaar_upload_back', $user_id);
                $labour_card = handle_file_upload('labour_card_upload', $user_id);
                //echo "<pre>"; print_r($labour_card);die;

                if ($profile_image) {
                    update_user_meta($user_id, 'profile_image', $profile_image);
                }
    
                if ($adhaar_front_image) {
                    update_user_meta($user_id, 'adhaar_front_image', $adhaar_front_image);
                }
    
                if ($adhaar_back_image) {
                    update_user_meta($user_id, 'adhaar_back_image', $adhaar_back_image);
                }
    
                if ($labour_card) {
                    update_user_meta($user_id, 'labour_card', $labour_card);
                }

                // Success message with redirect countdown
                $message = "<p style='color: green;'>Thank you for your registration! Your account will be approved after verification.</p>";
                $message .= "<p id='countdown' style='color: green;'>Redirecting you to the homepage in <span id='timer'>5</span> seconds...</p>";

               
                wp_localize_script('countdown-script', 'countdown_data', array('redirect_url' => home_url()));
            }
        }
    }
}

function handle_file_upload($field_name, $user_id)
{
    if (!empty($_FILES[$field_name]['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $upload_id = media_handle_upload($field_name, 0);

        if (is_wp_error($upload_id)) {
            echo "<p style='color: red;'>Error uploading file: " . $upload_id->get_error_message() . "</p>";
            return false;
        } else {
            return wp_get_attachment_url($upload_id);
        }
    }
    return false;
}

// Function to get eLoc from MapmyIndia
function get_eloc_from_mapmyindia($full_address)
{
    $api_key = 'YOUR_MAPMYINDIA_API_KEY';
    $url = "https://atlas.mapmyindia.com/api/places/geocode?address=" . urlencode($address);

    $response = wp_remote_get($url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key
        ]
    ]);

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!empty($data['copResults'][0]['eLoc'])) {
        return sanitize_text_field($data['copResults'][0]['eLoc']);
    }

    return false;
}


get_header();  // This loads the WordPress header
?><div class="container">
    <div class="service-provider-registration">
        <h2 class="mb-3">Sewa Mitra Registration</h2>
        <?php if ($message): ?>
            <div class="registration-message">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="POST" enctype="multipart/form-data">
            <div class="row">
                <!-- Left Column -->
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="dname">Name: <span class="text-danger">*</span></label>
                        <input type="text" name="dname" id="dname" class="form-control" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="phone">Phone Number: <span class="text-danger">*</span></label>
                        <input type="text" name="phone" id="phone" maxlength="10" class="form-control" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="password">Password: <span class="text-danger">*</span></label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>

                    <!-- Aadhaar Upload (Two Image Uploads) -->
                    <div class="form-group mb-3">
                        <label for="adhaar_upload_front">Adhaar Upload (Front): <span class="text-danger">*</span></label>
                        <input type="file" name="adhaar_upload_front" id="adhaar_upload_front" accept="image/jpeg, image/png" class="form-control" required>
						<small class="form-text text-muted">Allowed file types: JPG, PNG | Max size: 200KB</small>
					</div>
                    <div class="form-group mb-3">
                        <label for="adhaar_upload_back">Adhaar Upload (Back): <span class="text-danger">*</span></label>
                        <input type="file" name="adhaar_upload_back" id="adhaar_upload_back" accept="image/jpeg, image/png" class="form-control" required>
						<small class="form-text text-muted">Allowed file types: JPG, PNG | Max size: 200KB</small>
					</div>
					<div class="form-group mb-3">
                        <label for="vehicle_availability">Vehicle Availability: <span class="text-danger">*</span></label>
                        <select name="vehicle_availability" id="vehicle_availability" class="form-control" required>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="email">Email (Optional)</label>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>

                    <div class="form-group mb-3">
                        <label for="profile_image">Profile Image: <span class="text-danger">*</span></label>
                        <input type="file" name="profile_image" accept="image/jpeg, image/png" id="profile_image" class="form-control" required>
						<small class="form-text text-muted">Allowed file types: JPG, PNG | Max size: 200KB</small>
					</div>

                    <div class="form-group mb-3">
                        <label for="confirm_password">Confirm Password: <span class="text-danger">*</span></label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="labour_card_upload">Labour Card Upload (Optional)</label>
                        <input type="file" name="labour_card_upload" accept="image/jpeg, image/png" id="labour_card_upload" class="form-control">
						<small class="form-text text-muted">Allowed file types: JPG, PNG | Max size: 200KB</small>
					</div>

                    <!-- Specialization Field -->
                    <div class="form-group mb-3">
                        <label for="product_category">Specialization: <span class="text-danger">*</span></label>
                        <select name="product_category" id="product_category" class="form-control" required>
                            <option value="" disabled selected>Select Specialization</option>
                            <?php 
                            $args = array(
                                'taxonomy'   => 'product_cat',
                                'orderby'    => 'name',
                                'order'      => 'ASC',
                                'hide_empty' => false,
                                'parent'     => 0,
                                'exclude'    => array(107),
                            );

                            $categories = get_terms($args);
                            if (!empty($categories) && !is_wp_error($categories)) {
                                foreach ($categories as $category) {
                                    if ('uncategorized' === strtolower($category->name)) {
                                        continue;
                                    }
                                    echo '<option value="' . esc_attr($category->term_id) . '">' . esc_html($category->name) . '</option>';
                                }
                            } else {
                                echo '<option value="" disabled>No categories found</option>';
                            }
                            ?>
                        </select>
                    </div>

                    
                </div>
            </div>

            <!-- Address Fields -->
            <div class="form-group mb-3">
                <label for="house_area">House No/Flat/Area: <span class="text-danger">*</span></label>
                <input type="text" name="house_area" id="house_area" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="gali_sector">Gali/Sector: <span class="text-danger">*</span></label>
                <input type="text" name="gali_sector" id="gali_sector" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="city">City: <span class="text-danger">*</span></label>
                <input type="text" name="city" id="city" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="pin_code">Pin Code: <span class="text-danger">*</span></label>
                <input type="text" name="pin_code" id="pin_code" class="form-control" required>
            </div>

            <!-- ✅ Moved Bank Info Section Here -->
            <div class="form-group mb-3">
                <label for="account_name">Account Holder's Name: <span class="text-danger">*</span></label>
                <input type="text" name="account_name" id="account_name" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="account_number">Account Number: <span class="text-danger">*</span></label>
                <input type="text" name="account_number" id="account_number" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="ifsc_code">IFSC Code: <span class="text-danger">*</span></label>
                <input type="text" name="ifsc_code" id="ifsc_code" class="form-control" required>
            </div>

            <div class="form-group mb-3 form-check">
                <input type="checkbox" name="confirmation" id="confirmation" class="form-check-input" value="yes" required>
                <label for="confirmation" class="form-check-label">
                    <span class="text-danger">*</span>
                    I confirm that all information in this document is true to the best of my knowledge and I agree to the 
                    <a href="/privacy-policy" target="_blank">Privacy Policy</a> and 
                    <a href="/terms-and-conditions/" target="_blank">Terms and Conditions</a>.
                </label>
            </div>  


  
			    <input type="hidden" name="form_type" value="service_provider" />
            <input type="hidden" id="provider_latitude" name="provider_latitude" value="<?php echo $_COOKIE['user_lat']; ?>">
            <input type="hidden" id="provider_longitude" name="provider_longitude" value="<?php echo $_COOKIE['user_lon']; ?>">

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>


<?php
get_footer();  // This loads the WordPress footer
?>

<script type="text/javascript">
 function validateFile(input, maxKB = 200) {
    const file = input.files[0];
    if (!file) return;

    const allowedTypes = ['image/jpeg', 'image/png'];

    if (!allowedTypes.includes(file.type)) {
      alert('Invalid file type. Only JPG and PNG are allowed.');
      input.value = '';
      return;
    }

     const maxBytes = maxKB * 1024;
	if (file.size > maxBytes) {
      alert(`File size should be less than ${maxKB}KB.`);
      input.value = '';
      return;
    }
  }

  // Attach event listeners to all inputs
  ['labour_card_upload', 'profile_image', 'adhaar_upload_front', 'adhaar_upload_back'].forEach(id => {
    const input = document.getElementById(id);
    if (input) {
      input.addEventListener('change', function () {
        validateFile(this);
      });
    }
  });
    // Countdown logic for the redirect
    document.addEventListener("DOMContentLoaded", function() {
        const countdownElement = document.getElementById("timer");
        if (countdownElement) {
            let timeLeft = parseInt(countdownElement.textContent, 10); // Read initial time from the DOM
            const countdownInterval = setInterval(function() {
                timeLeft--;
                countdownElement.textContent = timeLeft;

                if (timeLeft <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = "<?php echo home_url(); ?>"; // Redirect to homepage
                }
            }, 1000);
        }
    });

    document.querySelector('form').addEventListener('submit', function(e) {
        const phoneInput = document.getElementById('phone');
        const phoneValue = phoneInput.value.trim();

        if (!/^\d{10}$/.test(phoneValue)) {
            e.preventDefault(); // Prevent form submission
            alert('Please enter a valid 10-digit phone number.');
            phoneInput.focus();
        }
    });

    // Prevent numbers in the name field
    document.getElementById('dname').addEventListener('input', function(e) {
        const nameInput = e.target;
        nameInput.value = nameInput.value.replace(/[0-9]/g, ''); // Remove any numbers
    });

    // Prevent non-numeric input in the phone field
    document.getElementById('phone', 'account_number').addEventListener('input', function(e) {
        const phoneInput = e.target;
        const accountInput = e.target;
        phoneInput.value = phoneInput.value.replace(/\D/g, ''); // Remove any non-digit characters
        accountInput.value = accountInput.value.replace(/\D/g, '');
    });
	//Script for geoLocation 
	
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent the form from submitting immediately
    
    // Request the user's location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            // Get latitude and longitude
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;

            // Set the location in hidden inputs
            document.getElementById('provider_latitude').value = latitude;
            document.getElementById('provider_longitude').value = longitude;

            // Now submit the form
            e.target.submit();
        }, function(error) {
            alert("Unable to retrieve your location.");
            // Proceed with form submission even without location (if necessary)
            e.target.submit();
        });
    } else {
        alert("Geolocation is not supported by this browser.");
        // Proceed with form submission even without location (if necessary)
        e.target.submit();
    }
});
</script>