<?php
// Include WordPress
define('WP_USE_THEMES', false);
require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

// Check if it's an AJAX request
if (!defined('DOING_AJAX') || !DOING_AJAX) {
    die('Invalid request.');
}

// Get filter values from the request
$subcategory_id = isset($_POST['subcategory_id']) ? intval($_POST['subcategory_id']) : 0;
$area_min = isset($_POST['area_min']) ? floatval($_POST['area_min']) : 0;
$area_max = isset($_POST['area_max']) ? floatval($_POST['area_max']) : 0;
$budget_min = isset($_POST['budget_min']) ? floatval($_POST['budget_min']) : 0;
$budget_max = isset($_POST['budget_max']) ? floatval($_POST['budget_max']) : 0;

// Build query arguments
$args = array(
    'post_type' => 'product',
    'posts_per_page' => -1,
    'tax_query' => array(
        array(
            'taxonomy' => 'product_cat',
            'field'    => 'term_id',
            'terms'    => $subcategory_id,
        ),
    ),
    'meta_query' => array(
        'relation' => 'AND',
    ),
);

// Add area filter if provided (separate for min and max)
if ($area_min || $area_max) {
    $meta_query_area = array('relation' => 'AND'); // Use AND to combine min and max conditions

    if ($area_min) {
        $meta_query_area[] = array(
            'key'     => '_product_area',
            'value'   => $area_min,
            'type'    => 'NUMERIC',
            'compare' => '>=',
        );
    }

    if ($area_max) {
        $meta_query_area[] = array(
            'key'     => '_product_area',
            'value'   => $area_max,
            'type'    => 'NUMERIC',
            'compare' => '<=',
        );
    }

    // Ensure that the meta_query for area is added only if there's a valid condition
    if (!empty($meta_query_area)) {
        $args['meta_query'][] = $meta_query_area;
    }
}

// Add budget filter if provided (separate for min and max)
if ($budget_min || $budget_max) {
    $meta_query_budget = array('relation' => 'AND'); // Use AND to combine min and max conditions

    if ($budget_min) {
        $meta_query_budget[] = array(
            'key'     => '_price',
            'value'   => $budget_min,
            'type'    => 'NUMERIC',
            'compare' => '>=',
        );
    }

    if ($budget_max) {
        $meta_query_budget[] = array(
            'key'     => '_price',
            'value'   => $budget_max,
            'type'    => 'NUMERIC',
            'compare' => '<=',
        );
    }

    // Ensure that the meta_query for budget is added only if there's a valid condition
    if (!empty($meta_query_budget)) {
        $args['meta_query'][] = $meta_query_budget;
    }
}
// Fetch filtered products
$query = new WP_Query($args);

$response = array();

if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
		$default_image = get_template_directory_uri() . '/images/default.png';
		$service_image = !empty($service_image) ? $service_image : $default_image;
        $price = get_post_meta(get_the_ID(), '_price', true);
        $product_id = get_the_ID();
        $product_area = get_post_meta($product_id, '_product_area', true);
        
        // Prepare the HTML content for each service
        $response[] = array(
            'html' => '
                    <div class="inner-booked-service">
                        <a href="' . esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))) . '">
                            <img src="' . esc_url($service_image) . '" class="img-fluid" alt="' . get_the_title() . '" />
                            <div class="content-services-about">
                                <h4>' . get_the_title() . ($product_area ? ' (' . $product_area . ' sqft)' : '') . '</h4>
                            </a>
                            <p class="service-description">' . get_the_excerpt() . '</p>
                            <div class="price-book-now">
                                <span class="pricebok">' . wc_price($price) . '</span>
                                <a href="' . esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))) . '" class="btn btn-primary">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>',
        );
    }
    wp_reset_postdata();
} else {
    $response[] = array('html' => '<p>No services found for the selected filters.</p>');
}
// Return the filtered products as a JSON response
wp_send_json_success($response);
die();
