<?php
/**
 * Template Name: Service Page
 * Description: A custom template to display services related to a selected subcategory.
 */
get_header(); // Include the header

ob_start(); // Start output buffering
?>

<div class="service-content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="headingOther">
                    <h2>Services</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php
            // Get the subcategory ID from the query string
            $subcategory_id = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : 0;

            // Check for ancestor to show filters
            $ancestors = get_ancestors($subcategory_id, 'product_cat');
            if (in_array(98, $ancestors) || in_array(99, $ancestors)) {
                echo '<div class="col-md-4 col-lg-4 col-sm-12 col-12">
                    <aside class="product-filters">
                        <h4>Filters</h4>
                        <div class="filter-area">
                            <label for="filter_area">Filter by Area (sqft):</label>
                            <div id="area_slider"></div>
                            <input type="number" id="filter_area_min" name="filter_area_min" placeholder="Min Area" />
                            <input type="number" id="filter_area_max" name="filter_area_max" placeholder="Max Area" />
                        </div>
                        <div class="filter-budget">
                            <label for="filter_budget">Filter by Budget (₹):</label>
                            <div id="budget_slider"></div>
                            <input type="number" id="filter_budget_min" name="filter_budget_min" placeholder="Min Budget" />
                            <input type="number" id="filter_budget_max" name="filter_budget_max" placeholder="Max Budget" />
                        </div>
                        <button id="apply_filters" class="btn btn-primary">Apply Filters</button>
                    </aside>
                </div>';
            }
            ?>

            <div class="loader" style="display:none;"></div>
            <div class="col-sm-12 col-12">
                <div class="row" id="service-list">
                    <?php
                    if ($subcategory_id) {
                        // ✅ Updated: Show all products
                        $args = array(
                            'post_type' => 'product',
                            'posts_per_page' => -1, // Show all products
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'term_id',
                                    'terms'    => $subcategory_id,
                                ),
                            ),
                        );
                        $services = new WP_Query($args);

                        if ($services->have_posts()) {
                            while ($services->have_posts()) {
                                $services->the_post();
                                $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                $price = get_post_meta(get_the_ID(), '_price', true);
                                $product_id = get_the_ID();
                                $product_area = get_post_meta($product_id, '_product_area', true);
                                ?>
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 mb-4">
                                    <div class="inner-booked-service inner-booked-services2">
                                        <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>">
                                            <img src="<?php echo esc_url(!empty($service_image) ? $service_image : get_template_directory_uri() . '/images/default.png'); ?>" class="img-fluid" alt="<?php the_title(); ?>" />
                                            <div class="content-services-about">
                                                <h4>
                                                    <?php the_title(); ?>
                                                    <?php if (!empty($product_area)) {
                                                        echo '<small> (' . $product_area . ' sqft)</small>';
                                                    } ?>
                                                </h4>
                                            </div>
                                        </a>
                                        <div class="service-description">
										<h4><?php the_title(); ?></h4>
										<?php the_excerpt(); ?></div>
                                        <div class="price-book-now">
                                            <span class="pricebok"><?php echo wc_price($price); ?></span>
                                            <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>" class="btn btn-primary">Book Now</a>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo '<p>No services found for this subcategory.</p>';
                        }
                    } else {
                        echo '<p>No subcategory selected.</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts (jQuery sliders + AJAX) -->
<script>
    jQuery(document).ready(function($) {
        $('#apply_filters').on('click', function(e) {
            e.preventDefault();
            const subcategory_id = <?php echo $subcategory_id; ?>;
            const area_min = $('#filter_area_min').val();
            const area_max = $('#filter_area_max').val();
            const budget_min = $('#filter_budget_min').val();
            const budget_max = $('#filter_budget_max').val();
            $('#service-list').addClass('loading');

            $.ajax({
                url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                type: 'POST',
                data: {
                    action: 'filter_services',
                    subcategory_id: subcategory_id,
                    area_min: area_min,
                    area_max: area_max,
                    budget_min: budget_min,
                    budget_max: budget_max,
                },
                beforeSend: function () {
                    $('.loader').show();
                },
                success: function(response) {
                    if (response.success) {
                        let servicesHtml = '';
                        $.each(response.data, function(index, service) {
                            servicesHtml += service.html;
                        });
                        $('.loader').hide();
                        $('#service-list').html(servicesHtml);
                    } else {
                        $('#service-list').html('<p>No services found for the selected filters.</p>');
                    }
                    $('#service-list').removeClass('loading');
                },
            });
        });

        // Sliders initialization
        $('#area_slider').slider({
            range: true,
            min: 0,
            max: 5000,
            step: 50,
            values: [50, 3000],
            slide: function(event, ui) {
                $('#filter_area_min').val(ui.values[0]);
                $('#filter_area_max').val(ui.values[1]);
            },
        });

        $('#budget_slider').slider({
            range: true,
            min: 0,
            max: 500000,
            step: 500,
            values: [500, 50000],
            slide: function(event, ui) {
                $('#filter_budget_min').val(ui.values[0]);
                $('#filter_budget_max').val(ui.values[1]);
            },
        });

        $('#filter_area_min').val($('#area_slider').slider('values', 0));
        $('#filter_area_max').val($('#area_slider').slider('values', 1));
        $('#filter_budget_min').val($('#budget_slider').slider('values', 0));
        $('#filter_budget_max').val($('#budget_slider').slider('values', 1));
    });
</script>

<!-- Loader styles -->
<style>
.loader {
    width: 48px;
    height: 48px;
    border: 5px solid #378CCF;
    border-bottom-color: transparent;
    border-radius: 50%;
    display: inline-block;
    animation: rotation 1s linear infinite;
    position: absolute;
    top: 50%;
    left: 57%;
    transform: translate(-50%, -50%);
    z-index: 9999;
}
@keyframes rotation {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
#service-list.loading {
    filter: blur(2px);
    opacity: 0.2;
    pointer-events: none;
}
</style>

<?php
$content = ob_get_clean();
echo $content;
get_footer(); // Include the footer
?>
