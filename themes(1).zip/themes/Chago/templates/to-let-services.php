<?php
/**
 * Template Name: ToLet-Template
 * Description: A custom template to display WooCommerce subcategories based on the selected category.
 */
get_header(); // Include the header

// Start output buffering
ob_start();
?>
<div class="service-content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="headingOther">
                    <h2>
                        <?php
                        $subcategory_id = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : 0;

                        if ($subcategory_id) {
                            $subcategory = get_term($subcategory_id, 'product_cat');

                            if ($subcategory && !is_wp_error($subcategory)) {
                                $parent_category_id = $subcategory->parent;

                                if ($parent_category_id) {
                                    $parent_category = get_term($parent_category_id, 'product_cat');
                                    echo esc_html($parent_category && !is_wp_error($parent_category) ? $parent_category->name : 'Unknown Parent Category');
                                } else {
                                    echo esc_html($subcategory->name); // If no parent, show current
                                }
                            } else {
                                echo 'Invalid Subcategory ID';
                            }
                        } else {
                            echo 'No Subcategory Selected';
                        }
                        ?>
                    </h2>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <?php
            $category_id = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : 0;

            if ($category_id) {
                $args = array(
                    'taxonomy'   => 'product_cat',
                    'orderby'    => 'name',
                    'hide_empty' => false,
                    'parent'     => $category_id,
                );

                $subcategories = get_terms($args);

                if (!empty($subcategories) && !is_wp_error($subcategories)) {
                    foreach ($subcategories as $subcategory) {
                        $subcat_id = $subcategory->term_id;

                        // Check if this subcategory has children
                        $child_terms = get_terms(array(
                            'taxonomy'   => 'product_cat',
                            'parent'     => $subcat_id,
                            'hide_empty' => false,
                            'number'     => 1
                        ));

                        // Determine link target
                        $target_page = !empty($child_terms) ? 'to-let-services' : 'service';
                        $service_page_link = get_permalink(get_page_by_path($target_page)) . '?subcat_id=' . $subcat_id;

                        // Get image
                        $subcategory_image_id = get_term_meta($subcat_id, 'thumbnail_id', true);
                        $subcategory_image_url = $subcategory_image_id
                            ? wp_get_attachment_url($subcategory_image_id)
                            : get_template_directory_uri() . '/images/default.png';
            ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 mb-4">
                            <div class="inner-booked-service inner-booked-service2">
                                <a href="<?php echo esc_url($service_page_link); ?>">
                                    <img src="<?php echo esc_url($subcategory_image_url); ?>" class="img-fluid" alt="<?php echo esc_attr($subcategory->name); ?>" />
                                </a>
                                <div class="content-services-about">
                                    <a href="<?php echo esc_url($service_page_link); ?>">
                                        <h4><?php echo esc_html($subcategory->name); ?></h4>
                                    </a>
                                    <?php if (!empty($subcategory->description)) : ?>
                                        <div class="service-description">
                                            <p><?php echo esc_html(wp_strip_all_tags($subcategory->description)); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <div class="price-book-now">
                                        <a href="<?php echo esc_url($service_page_link); ?>" class="btn">View Services</a>
                                    </div>
                                </div>
                            </div>
                        </div>
            <?php
                    }
                } else {
                    echo '<p>No subcategories found for this category.</p>';
                }
            } else {
                echo '<p>No category selected.</p>';
            }
            ?>
        </div>
    </div>
</div>

<?php
// End output buffering
echo ob_get_clean(); // Output the content
get_footer(); // Include the footer
?>
