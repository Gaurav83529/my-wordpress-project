<?php
/*
Template Name: Property Results
*/
get_header(); ?>

<?php
// Fetch parameters from URL
$city            = isset($_GET['city']) ? sanitize_text_field($_GET['city']) : '';
$area            = isset($_GET['area']) ? sanitize_text_field($_GET['area']) : '';
$subcat_id       = isset($_GET['subcat_id']) ? intval($_GET['subcat_id']) : '';
$category        = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$bhk             = isset($_GET['bhk']) ? sanitize_text_field($_GET['bhk']) : '';
$budget          = isset($_GET['budget']) ? sanitize_text_field($_GET['budget']) : '';
$furnishing      = isset($_GET['furnishing']) ? sanitize_text_field($_GET['furnishing']) : '';
$floor           = isset($_GET['floor']) ? sanitize_text_field($_GET['floor']) : '';

$cabins           = isset($_GET['cabins']) ? sanitize_text_field($_GET['cabins']) : '';
$open_space_option           = isset($_GET['open_space_option']) ? sanitize_text_field($_GET['open_space_option']) : '';
$prefered_floor           = isset($_GET['prefered_floor']) ? sanitize_text_field($_GET['prefered_floor']) : '';
$seating_capacity           = isset($_GET['seating_capacity']) ? sanitize_text_field($_GET['seating_capacity']) : '';

// New fields from `update_post_meta`
$contact         = isset($_GET['contact']) ? sanitize_text_field($_GET['contact']) : '';
//$location        = isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '';
$lease_type      = isset($_GET['lease_type']) ? sanitize_text_field($_GET['lease_type']) : '';
$amenities       = isset($_GET['amenities']) ? sanitize_text_field($_GET['amenities']) : '';
$footfall        = isset($_GET['footfall']) ? sanitize_text_field($_GET['footfall']) : '';
$visibility      = isset($_GET['visibility']) ? sanitize_text_field($_GET['visibility']) : '';
$ceilingHeight   = isset($_GET['ceilingHeight']) ? sanitize_text_field($_GET['ceilingHeight']) : '';
$loadingFacilities = isset($_GET['loadingFacilities']) ? sanitize_text_field($_GET['loadingFacilities']) : '';
$house_parking   = isset($_GET['house-parking']) ? sanitize_text_field($_GET['house-parking']) : '';
$sharing_type    = isset($_GET['sharing-type']) ? sanitize_text_field($_GET['sharing-type']) : '';
$gender          = isset($_GET['gender']) ? sanitize_text_field($_GET['gender']) : '';
$food_included   = isset($_GET['food-included']) ? sanitize_text_field($_GET['food-included']) : '';
$bathroom        = isset($_GET['bathroom']) ? sanitize_text_field($_GET['bathroom']) : '';
$area_sqft_        = isset($_GET['area_sqft_']) ? sanitize_text_field($_GET['area_sqft_']) : '';

$location        = $city.' - '.$area;
/* $price          = preg_match('/\d+/', $budget, $matches);
$price_text = isset($price[0]) ? $price[0] : ''; */
/* echo "<pre>";
print_r($_GET);
die; */

$min = 0;
$max = PHP_INT_MAX;


function convertToNumber($val) {
    $val = str_replace(['₹', '+', ' '], '', $val);
    if (strpos($val, 'K') !== false) {
        return (int) $val * 1000;
    } elseif (strpos($val, 'L') !== false) {
        return (int) $val * 100000;
    }
    return (int) $val;
}
//for price
if ($budget) {
    if (strpos($budget, 'Under') !== false) {
        preg_match('/₹?(\d+)([KL]?)/', $budget, $matches);
        $max = convertToNumber($matches[1] . $matches[2]);
    } elseif (strpos($budget, '+') !== false) {
        preg_match('/₹?(\d+)([KL]?)/', $budget, $matches);
        $min = convertToNumber($matches[1] . $matches[2]);
    } elseif (strpos($budget, '-') !== false) {
        preg_match('/₹?(\d+)([KL]?)\-₹?(\d+)([KL]?)/', $budget, $matches);
        $min = convertToNumber($matches[1] . $matches[2]);
        $max = convertToNumber($matches[3] . $matches[4]);
    }
}
$parts = array_filter([$city, $area, $category, $bhk, $budget]);
?>
<div class="container property-results-template">
    <div class="row">
        <div class="col-12">
            <div class="headingOther">
                <h2><?php echo esc_html(implode(' - ', $parts)) . ' Properties'; ?></h2>
            </div>
        </div>
    </div>

    <?php
    // Setup WP_Query args
     $args = [
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'tax_query'      => [],
        'meta_query'     => ['relation' => 'OR'],
    ];

    if (!empty($subcat_id)) {
    $args['tax_query'][] = [
        'taxonomy'         => 'product_cat',
        'field'            => 'term_id',
        'terms'            => $subcat_id,
        'include_children' => true,
    ];
}

// Meta filters
/* if (!empty($city)) {
    $args['meta_query'][] = [
        'key'     => 'city',
        'value'   => $city,
        'compare' => '='
    ];
}
 */
 if (!empty($area_sqft_)) {
    $args['meta_query'][] = [
        'key'     => 'area',
        'value'   => $area_sqft_,
        'compare' => '='
    ];
}

if (!empty($bhk)) {
    $args['meta_query'][] = [
        'key'     => 'bhk',
        'value'   => $bhk,
        'compare' => '='
    ];
}

/*  if (!empty($budget)) { area_sqft_
    $args['meta_query'][] = [
        'key'     => '_price', // WooCommerce price field
        'value'   => $budget,
        'compare' => '='
    ];
}  */
if ($budget) {
    $args['meta_query'] = [
        [
            'key' => '_price', 
            'value' => [$min, $max],
            'type' => 'NUMERIC',
            'compare' => 'BETWEEN',
        ],
    ];
}


if (!empty($furnishing)) {
    $args['meta_query'][] = [
        'key'     => 'furnishing',
        'value'   => $furnishing,
        'compare' => '='
    ];
}

if (!empty($floor)) {
    $args['meta_query'][] = [
        'key'     => 'floor',
        'value'   => $floor,
        'compare' => '='
    ];
}

// Additional fields to filter by (from the update_post_meta fields)
if (!empty($contact)) {
    $args['meta_query'][] = [
        'key'     => 'contact',
        'value'   => $contact,
        'compare' => '='
    ];
}

if (!empty($location)) {
    $args['meta_query'][] = [
        'key'     => 'location',
        'value'   => $location,
        'compare' => '='
    ];
}

if (!empty($lease_type)) {
    $args['meta_query'][] = [
        'key'     => 'lease_type',
        'value'   => $lease_type,
        'compare' => '='
    ];
}

if (!empty($amenities)) {
    $args['meta_query'][] = [
        'key'     => 'amenities',
        'value'   => $amenities,
        'compare' => '='
    ];
}

if (!empty($footfall)) {
    $args['meta_query'][] = [
        'key'     => 'footfall',
        'value'   => $footfall,
        'compare' => '='
    ];
}

if (!empty($visibility)) {
    $args['meta_query'][] = [
        'key'     => 'visibility',
        'value'   => $visibility,
        'compare' => '='
    ];
}

if (!empty($ceilingHeight)) {
    $args['meta_query'][] = [
        'key'     => 'ceilingHeight',
        'value'   => $ceilingHeight,
        'compare' => '='
    ];
}

if (!empty($loadingFacilities)) {
    $args['meta_query'][] = [
        'key'     => 'loadingFacilities',
        'value'   => $loadingFacilities,
        'compare' => '='
    ];
}

if (!empty($house_parking)) {
    $args['meta_query'][] = [
        'key'     => 'house-parking',
        'value'   => $house_parking,
        'compare' => '='
    ];
}

if (!empty($sharing_type)) {
    $args['meta_query'][] = [
        'key'     => 'sharing-type',
        'value'   => $sharing_type,
        'compare' => '='
    ];
}

if (!empty($gender)) {
    $args['meta_query'][] = [
        'key'     => 'gender',
        'value'   => $gender,
        'compare' => '='
    ];
}

if (!empty($food_included)) {
    $args['meta_query'][] = [
        'key'     => 'food-included',
        'value'   => $food_included,
        'compare' => '='
    ];
}

if (!empty($bathroom)) {
    $args['meta_query'][] = [
        'key'     => 'bathroom',
        'value'   => $bathroom,
        'compare' => '='
    ];
}

if (!empty($cabins)) {
    $args['meta_query'][] = [
        'key'     => 'cabins',
        'value'   => $cabins,
        'compare' => '='
    ];
}if (!empty($open_space_option)) {
    $args['meta_query'][] = [
        'key'     => 'open_space_option',
        'value'   => $open_space_option,
        'compare' => '='
    ];
}
//

if (!empty($prefered_floor)) {
    $args['meta_query'][] = [
        'key'     => 'prefered_floor',
        'value'   => $prefered_floor,
        'compare' => '='
    ];
}
if (!empty($seating_capacity)) {
    $args['meta_query'][] = [
        'key'     => 'seating_capacity',
        'value'   => $seating_capacity,
        'compare' => '='
    ];
} 

 /* echo "<pre>";
print_r($args);
die;  */
    // Execute query
    $query = new WP_Query($args);
//echo "<pre>"; print_r($query);die;
if ($query->have_posts()) :
        echo '<div class="row">';
        while ($query->have_posts()) : $query->the_post();
            $product_id = get_the_ID();
			$product = wc_get_product($product_id);
			?>
			<div class="col-md-4 mb-4">
				<div class="custom-product-box border rounded">
					<a href="<?php echo esc_url(home_url('/product-page/?id=' . $product_id)); ?>">
						<?php echo get_the_post_thumbnail($product_id, 'medium'); ?>
						<h3 class="m-2"><?php echo esc_html($product->get_name()); ?></h3>
					</a>
					<div class="price m-2">
						<?php echo $product->get_price_html(); ?>
					</div>
				</div>
			</div>
			<?php endwhile;
        echo '</div>';
        wp_reset_postdata();
    else :
        echo '<p>No products found for your search criteria.</p>';
    endif;
    ?>
</div>

<?php get_footer(); ?>
