<?php
/**
 * Template Name: Service Provider Dashboard
 */
get_header();

// Ensure the user is logged in
if (is_user_logged_in()) {
    $current_user = wp_get_current_user();  // Get the current user object
    $username = $current_user->user_login;   // Get the username of the user

    // Get the staff ID associated with the current user (assuming Bookly staff table)
    global $wpdb;
    $staff_id = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM gOP_bookly_staff WHERE wp_user_id = %d", $current_user->ID)
    );
    //echo "<pre>"; print_r("$staff_id");die;
    if (!$staff_id) {
        echo '<p>You are not registered as a staff member.</p>';
        return;
    }
} else {
	 echo '<div class="mustLog">';
    echo '<p>You must be logged in to access your dashboard.</p>';
    return; // Stop further execution if the user is not logged in
	 echo '</div>';
}
?>

<div class="page-content dokan-dashboard">
    <?php
    if (is_page()) {
        // Display page title with the current user's username
        echo '<h1 class="page-title">Dashboard - ' . esc_html($username) . '</h1>';
    }

    // Display the page content
//     echo "<div class='container'>";
    while ( have_posts() ) : the_post();
        the_content();
    endwhile;
//     echo "</div>";
    ?>
</div>

<?php
get_footer();
?>