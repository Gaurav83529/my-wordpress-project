<?php
/*
Template Name: Custom Product
*/
get_header();

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $product = wc_get_product($product_id);

    if ($product) {
        ?>
        <div class="container my-5">
            <h1><?php echo esc_html($product->get_name()); ?></h1>
            <div class="product-image">
                <?php echo get_the_post_thumbnail($product_id, 'large'); ?>
            </div>
            <div class="price my-2">
                <?php echo $product->get_price_html(); ?>
            </div>
            <div class="description">
                <?php echo $product->get_description(); ?>
            </div>
           
        </div>
        <?php
    } else {
        echo '<p>Invalid product ID.</p>';
    }
} else {
    echo '<p>No product selected.</p>';
}

get_footer();
