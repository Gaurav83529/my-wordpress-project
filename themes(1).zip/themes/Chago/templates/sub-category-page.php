<?php
/**
 * Template Name: Sub-Category Template
 * Description: A custom template to display WooCommerce subcategories based on the selected category.
 */
get_header(); // Include the header
// Start output buffering
ob_start();
?>

<div class="service-content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="headingOther">
                    <h2>Subcategory</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php
            // Get the category ID from the query string
            $category_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;

            // Check if a category ID is provided
            if ($category_id) {
                // Check if this is category 98 or 99 (special handling)
                if ($category_id == 98 || $category_id == 99) {
                    // Redirect to the to-let services page with the category ID
                    $redirect_url = get_permalink(get_page_by_path('to-let-services')) . '?subcat_id=' . $category_id;
                    wp_redirect($redirect_url);
                    exit;
                }
                
                // Fetch subcategories of the specified category
                $args = array(
                    'taxonomy'   => 'product_cat',
                    'orderby'    => 'name',
                    'hide_empty' => false,
                    'parent'     => $category_id,
                );

                $subcategories = get_terms($args);

                if (!empty($subcategories) && !is_wp_error($subcategories)) {
                    foreach ($subcategories as $subcategory) {
                        // Check for grandchild categories
                        $g_child = get_terms(array(
                            'taxonomy' => 'product_cat',
                            'hide_empty'=> false,
                            'parent'   => $subcategory->term_id,
                        ));
                        
                        $subcat_id = $subcategory->term_id;

                        // Get subcategory image
                        $subcategory_image_id = get_term_meta($subcategory->term_id, 'thumbnail_id', true);
                        $subcategory_image_url = $subcategory_image_id
                            ? wp_get_attachment_url($subcategory_image_id)
                            : get_template_directory_uri() . '/images/default.png';

                        // Fetch a product from this subcategory
                        $args = array(
                            'post_type'      => 'product',
                            'posts_per_page' => 1,
                            'tax_query'      => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'id',
                                    'terms'    => $subcategory->term_id,
                                    'operator' => 'IN',
                                ),
                            ),
                        );
                        $products = new WP_Query($args);

                        if ($products->have_posts()) {
                            $product = $products->posts[0];
                            $product_id = $product->ID;

                            // Redirect logic based on subcategory ID
                            if (!empty($g_child) && !is_wp_error($g_child)) {
                                if ($subcat_id == 98 || $subcat_id == 99) {
                                    $service_page_link = get_permalink(get_page_by_path('filter-two-let-services')) . '?subcat_id=' . $subcat_id;
                                } else {
                                    $service_page_link = get_permalink(get_page_by_path('to-let-services')) . '?subcat_id=' . $subcat_id;
                                }
                            } else {
                                $service_page_link = get_permalink(get_page_by_path('book-service')) . '?product_id=' . $product_id;
                            }
                        } else {
                            $service_page_link = '#';
                        }
            ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div class="inner-booked-service inner-booked-service2 subCategoryNew">
                                <a href="<?php echo esc_url($service_page_link); ?>">
                                    <img src="<?php echo esc_url($subcategory_image_url); ?>" class="img-fluid" alt="<?php echo esc_attr($subcategory->name); ?>" />
                                </a>
                                <div class="content-services-about">
                                    <a href="<?php echo esc_url($service_page_link); ?>">
                                        <h4><?php echo esc_html($subcategory->name); ?></h4>
                                    </a>
                                    <?php if (!empty($subcategory->description)) : ?>
                                        <div class="service-description"><?php echo esc_html(wp_strip_all_tags($subcategory->description)); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
            <?php
                    }
                } else {
                    // If no subcategories, display products under the main category
                    $args = array(
                        'post_type' => 'product',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => $category_id,
                            ),
                        ),
                    );
                    $services = new WP_Query($args);

                    if ($services->have_posts()) {
                        while ($services->have_posts()) {
                            $services->the_post();
                            $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                            $price = get_post_meta(get_the_ID(), '_price', true);
                            $product_id = get_the_ID();
                            $product_author = get_the_author();
                            $product_area = get_post_meta($product_id, '_product_area', true);
            ?>
                            <div class="col-xs-12 col-sm-12 col-md-4 mb-4">
                                <div class="inner-booked-service cat_page">
                                    <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>">
                                        <img src="<?php echo esc_url(!empty($service_image) ? $service_image : get_template_directory_uri() . '/images/default.png'); ?>" class="img-fluid" alt="<?php the_title(); ?>" />
                                        <div class="content-services-about">
                                            <h4><?php the_title(); ?><?php if (!empty($product_area)) { echo ' <small>(' . $product_area .' sqft)</small>'; } ?></h4>
                                            <small>(<?php echo esc_html($product_author); ?>)</small>
                                    </a>
                                    <p class="service-description"><?php the_excerpt(); ?></p>
                                    <div class="price-book-now">
                                        <span class="pricebok"><?php echo wc_price($price); ?></span>
                                        <a href="<?php echo esc_url(add_query_arg('product_id', $product_id, esc_url(home_url('/book-service/')))); ?>" class="btn btn-primary">Book Now</a>
                                    </div>
                                </div>
                            </div>
            <?php
                        }
                        wp_reset_postdata();
                    } else {
                        echo '<div class="col-lg-12"><div class="comingMain"><div class="headingOther"><h2>Coming Soon</h2></div></div></div>';
                    }
                }
            } else {
                echo '<p>No category selected.</p>';
            }
            ?>
        </div>
    </div>
</div>

<?php
// End output buffering
$content = ob_get_clean();
echo $content; // Output the content to the page
get_footer(); // Include the footer
?>