<?php
// Load header
get_header();
?>

<div class="index-page-content">
  
    
    <!-- Loop through posts -->
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>">
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div><?php the_excerpt(); ?></div>
            </article>
        <?php endwhile; ?>
    <?php endif; ?>
</div>

<?php
// Load footer
get_footer();