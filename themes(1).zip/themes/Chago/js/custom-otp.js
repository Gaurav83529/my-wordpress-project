document.addEventListener("DOMContentLoaded", function () {
	
	const sendOtpBtn = document.getElementById("sendOtp");
	const verifyOtpBtn = document.getElementById("verifyOtp");
	const phoneInput = document.getElementById("phone");
	const otpInput = document.getElementById("otp");
	const otpSection = document.getElementById("otp-section");
	const requestSection = document.getElementById("request-section");
	const resendCode = document.getElementById("resend_code");
	const otpInputs = document.querySelectorAll(".otp-input");
	// const errorMessageInput = document.querySelectorAll(".error-message");
	const inputNumber = document.getElementById("inputNumber");
	const errorMessage = document.getElementById("error-message");
	if(otpInputs)
	{
		
		otpInputs.forEach((input, index) => {
			input.addEventListener("input", function () {
				if (this.value.length === 1 && index < otpInputs.length - 1) {
					otpInputs[index + 1].focus(); // Move to next input
				}
			});

			input.addEventListener("keydown", function (event) {
				if (event.key === "Backspace" && index > 0 && this.value === "") {
					otpInputs[index - 1].focus(); // Move to previous input
				}
			});
		});
	}

	
	if(sendOtpBtn)
	{
		
		sendOtpBtn.addEventListener("click", function () {
		
			let phone = phoneInput.value;
			errorMessage.innerText = "";
			if(validateInput(phone))
			{
				
				toggleLoader(this,true);

		   
				if (phone === "") {
					alert("Please enter a phone number");
					return;
				}

				fetch(ajax_object.ajax_url, {
					method: "POST",
					headers: {
						"Content-Type": "application/x-www-form-urlencoded",
					},
					body: new URLSearchParams({
						action: "send_otp",
						phone: phone
					})
				})
				.then(response => response.json())
				.then(data => {
					if (data.status === "success") {
						otpSection.style.display = "block";
						requestSection.style.display = "none";
						inputNumber.innerText = phone;
						toggleLoader(this,false);
					} else {
						errorMessage.innerText = "Please enter a valid email or phone";
						toggleLoader(this,false);
					}
				})
				.catch(error => {
					console.error("Error sending OTP:", error);
					errorMessage.innerText = "Please enter a valid email or phone or you have to register first";
					toggleLoader(this,false);
				});
			}
			else{
				errorMessage.innerText = "Please enter a valid email or phone";
			}
		});
	}

	if(resendCode)
	{
		
		resendCode.addEventListener("click", function () {
			let phone = phoneInput.value;
			toggleLoader(this,true);
			const otpContainer = this.closest("#otp-section"); // Find OTP section

			// Ensure errorMessage is properly fetched before using it
			const errorMessage = otpContainer ? otpContainer.querySelector('.error-message') : null;
			errorMessage.innerText = "";
			fetch(ajax_object.ajax_url, {
				method: "POST",
				headers: {
					"Content-Type": "application/x-www-form-urlencoded",
				},
				body: new URLSearchParams({
					action: "resend_otp",
					phone: phone
				})
			})
			.then(response => response.json())
			.then(data => {
				if (data.status === "success") {
					otpSection.style.display = "block";
					requestSection.style.display = "none";
					inputNumber.innerText = phone;
					toggleLoader(this,false);
				} else {
					toggleLoader(this,false);
					errorMessage.innerText = "Error sending OTP";
				}
			})
			.catch(error => {
				
				toggleLoader(this,false);
				errorMessage.innerText = "Error sending OTP";
				// alert("Error sending OTP. Check console.");
			});
		});
	}
	if(verifyOtpBtn)
	{
		
		verifyOtpBtn.addEventListener("click", function () {
			let phone = document.getElementById("phone").value;
			 const otpContainer = this.closest("#otp-section"); // Find OTP section

        // Ensure errorMessage is properly fetched before using it
        const errorMessage2 = otpContainer ? otpContainer.querySelector('.error-message') : null;
			errorMessage2.innerText = "";
			let otp = "";
			otpInputs.forEach(input => otp += input.value);

			if (otp.length !== otpInputs.length) {
				alert("Please enter the full OTP.");
				return;
			}
			if (phone === "" || otp === "") {
				alert("Please enter phone number and OTP");
				return;
			}
			toggleLoader(this,true);
			fetch(ajax_object.ajax_url, {
				method: "POST",
				headers: {
					"Content-Type": "application/x-www-form-urlencoded",
				},
				body: new URLSearchParams({
					action: "verify_otp",
					phone: phone,
					otp: otp
				})
			})
			.then(response => response.json())
			.then(data => {
				
				if (data.status ) {
					toggleLoader(this,false);
					window.location.href = "/";
				}
				else
				{
					toggleLoader(this,false);
					errorMessage2.innerText = "Error verifying OTP";
				}
			})
			.catch(error => {
			   toggleLoader(this,false);
			   errorMessage2.innerText = "Error verifying OTP";
			});

		
		});
	}



    });
	function toggleLoader(button,show) {
	
		 let loader = button.nextElementSibling; // Get the next sibling

		// Check if next sibling is a div with ID "loader"
		if (!loader || loader.id !== "loader") {
	
			// Create loader div if it doesn't exist
			loader = document.createElement("div");
			loader.id = "loader";
			button.insertAdjacentElement("afterend", loader);
			// button.appendChild(loader);
		}

		// Show or hide loader based on parameter
		loader.style.display = show ? "block" : "none";
	}
	function validateInput(input) {
		let phoneRegex = /^[6-9]\d{9}$/;  // Phone number pattern (10 digits, starts with 0-9)
		
		let emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Any valid email format

		if (phoneRegex.test(input)) {
			return true; 
		} else if (emailRegex.test(input)) {
			return true; // Valid email
		} else {
			return false; // Invalid input
		}
	}

