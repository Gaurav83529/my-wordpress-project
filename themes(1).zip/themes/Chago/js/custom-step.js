(function($) {
    $(document).on('bookly.step_render', function(event, step) {
		alert(step);
        if (step === 'custom_step') {
            // Render your custom step's HTML
            $('#bookly-form').html('<div>My Custom Step Content</div>');
        }
    });
})(jQuery);
