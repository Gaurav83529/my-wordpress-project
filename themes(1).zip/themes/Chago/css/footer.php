<footer class="footer">

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-2">
                <?php if (is_active_sidebar('footer-1')) : ?>
                    <?php dynamic_sidebar('footer-1'); ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-2">
                <?php if (is_active_sidebar('footer-2')) : ?>
                    <?php dynamic_sidebar('footer-2'); ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-2">
                <?php if (is_active_sidebar('footer-3')) : ?>
                    <?php dynamic_sidebar('footer-3'); ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
                <h4>Social Links</h4>
					<div class="social-links">
						<a href="<?php echo ( $link = get_theme_mod('facebook_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa fa-facebook" aria-hidden="true"></i>
						</a>
						<a href="<?php echo ( $link = get_theme_mod('twitter_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
						</a>
						<a href="<?php echo ( $link = get_theme_mod('instagram_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa fa-instagram" aria-hidden="true"></i>
						</a>
						<a href="<?php echo ( $link = get_theme_mod('linkedin_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa fa-linkedin" aria-hidden="true"></i>
						</a>
						<a href="<?php echo ( $link = get_theme_mod('whatsapp_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa fa-whatsapp" aria-hidden="true"></i>
						</a>
						<a href="<?php echo ( $link = get_theme_mod('youtube_link') ) ? esc_url($link) : '#'; ?>" target="_blank" rel="noopener noreferrer">
							<i class="fa fa-youtube" aria-hidden="true"></i>
						</a>
					</div>
            </div>
           
            <div class="col-xs-12 col-sm-6 col-md-3">
				   <div class="footerContact">
         <?php if (is_active_sidebar('footer-contact')) : ?>
            
               <?php dynamic_sidebar('footer-contact'); ?>
          
            <?php endif; ?>
            </div>
				</div>
         </div>

            <div class="copyright">
            <?php if (is_active_sidebar('copyright-widget')) : ?>
            <?php else : ?>
                <span>© <?php echo date("Y"); ?> Chago Company. All rights reserved.</span>
            <?php endif; ?>
            </div>
          </div>
</footer>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'/>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<?php

// Get the current user ID
$user_id = get_current_user_id();

if ($user_id) {
    // Get first and last name from user meta
    $first_name = get_user_meta($user_id, 'first_name', true);
    $last_name = get_user_meta($user_id, 'last_name', true);

    $full_name = "Welcome, " . esc_html($first_name) . " " . esc_html($last_name) . "";?>
	<script>jQuery('.user-registration-MyAccount-content__body h2').text('<?= $full_name?>');
	</script>
	
	
	<script>
jQuery(document).on('click','.bookly-hour-icon',function(e) {
	e.preventDefault();
	alert("asdfsdaf");
	jQuery('.bookly-js-full-name').attr('value','<?= $full_name?>');
});
	
	</script>
	<?php
} 


wp_footer();
?>

</body>
</html>